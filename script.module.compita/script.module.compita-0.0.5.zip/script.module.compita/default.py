ooOOOoo = ''
def ttTTtt(i, t1, t2=[]):
 t = ooOOOoo
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0  
 for c in t2:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t

import xbmc , xbmcaddon , xbmcgui , xbmcplugin , os
import shutil
import urllib2 , urllib
import re
import extract
import downloader
import time
import sys , plugintools
import zipfile
import net
net = net . Net ( )
oo000 = xbmcaddon . Addon ( id = 'script.module.compita' )
zip = oo000 . getSetting ( 'zip' )
ii = xbmcgui . Dialog ( )
oOOo = xbmcgui . DialogProgress ( )
O0 = xbmc . translatePath ( os . path . join ( 'special://home/userdata' , '' ) )
o0O = xbmc . translatePath ( os . path . join ( O0 , 'addon_data' ) )
iI11I1II1I1I = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
oooo = xbmc . translatePath ( os . path . join ( O0 , 'guisettings.xml' ) )
iIIii1IIi = xbmc . translatePath ( os . path . join ( O0 , 'favourites.xml' ) )
o0OO00 = xbmc . translatePath ( os . path . join ( O0 , 'sources.xml' ) )
oo = xbmc . translatePath ( os . path . join ( O0 , 'advancedsettings.xml' ) )
i1iII1IiiIiI1 = xbmc . translatePath ( os . path . join ( O0 , 'RssFeeds.xml' ) )
iIiiiI1IiI1I1 = xbmc . translatePath ( os . path . join ( O0 , 'keymaps' , 'keyboard.xml' ) )
o0OoOoOO00 = xbmc . translatePath ( os . path . join ( zip ) )
I11i = xbmc . getSkinDir ( )
O0O = xbmc . translatePath ( 'special://home/' )
Oo = 'script.module.compita' ; I1ii11iIi11i = "compita"
I1IiI = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
o0OOO = xbmc . translatePath ( os . path . join ( ttTTtt(0,[115],[13,100,128,99,58,97,254,114,160,100]) , ttTTtt(0,[46,91,115,243,121,128,115,158,95,71,100,74,101],[30,102,42,97,148,117,7,108,48,116]) , ttTTtt(342,[218,115,28,121],[149,115,174,95,191,52,171,48,67,49,56,46,161,116,52,120,0,116]) ) )
if 13 - 13: ooOo + Ooo0O
if not ( os . path . isfile ( o0OOO ) ) :
 ii . ok ( ttTTtt(0,[91,54,67,151,79,111,76],[201,79,219,82,176,32,109,114,79,101,243,100,59,93,180,89,213,79,150,85,78,82,111,32,80,68,147,69,157,86,180,73,125,67,254,69,50,32,31,73,62,83,202,32,163,78,220,79,48,84,109,32,14,65,192,85,186,84,134,72,139,79,96,82,200,73,1,90,195,69,213,68,158,91,198,47,143,67,209,79,123,76,170,79,188,82,137,93]) , ttTTtt(125,[253,67,23,111,215,110,208,116,59,97,197,99],[200,116,71,32,15,115,150,117,56,112,253,112,136,111,229,114,129,116,145,64,54,105,86,110,250,102,71,105,90,110,238,105,90,116,58,121,129,116,228,118,202,46,105,99,173,97,252,32,247,105,114,109,45,109,151,101,90,100,19,105,4,97,85,116,11,101,238,108,228,121,211,33]) )
 xbmc . executebuiltin ( ttTTtt(0,[81,230,117,30,105,81,116]) )
 if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
