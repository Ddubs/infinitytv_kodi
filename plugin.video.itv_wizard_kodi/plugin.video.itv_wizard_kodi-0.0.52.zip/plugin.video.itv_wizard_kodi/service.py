ooOOOoo = ''
def ttTTtt(i, t1, t2=[]):
 t = ooOOOoo
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0  
 for c in t2:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t

import xbmc , xbmcaddon , xbmcgui , xbmcplugin , os
import shutil
import urllib2 , urllib
import re
import extract
import downloader
import time
import sys , plugintools
import zipfile
import json
#import simplejson
import sys
import fileinput
import DialogITVTerms
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.itv_wizard_kodi'
Oo0Ooo = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
O0O0OO0O0O0 = xbmcaddon . Addon ( id = OO0o )
iiiii = xbmc . getInfoLabel ( "System.BuildVersion" )
iiiii = iiiii . split ( "." ) [ 0 ]
if 64 - 64: iIIi1iI1II111 + ii11i / oOooOoO0Oo0O
zip = O0O0OO0O0O0 . getSetting ( 'zip' )
iI1 = xbmcgui . Dialog ( )
i1I11i = xbmcgui . DialogProgress ( )
OoOoOO00 = xbmc . translatePath ( os . path . join ( 'special://home/userdata' , '' ) )
I11i = xbmc . translatePath ( os . path . join ( OoOoOO00 , 'addon_data' ) )
O0O = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
Oo = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , 'packages' ) )
I1ii11iIi11i = xbmc . translatePath ( os . path . join ( OoOoOO00 , 'guisettings.xml' ) )
I1IiI = xbmc . translatePath ( os . path . join ( OoOoOO00 , 'favourites.xml' ) )
o0OOO = xbmc . translatePath ( os . path . join ( OoOoOO00 , 'favourites2.xml' ) )
iIiiiI = xbmc . translatePath ( os . path . join ( OoOoOO00 , 'sources.xml' ) )
Iii1ii1II11i = xbmc . translatePath ( os . path . join ( OoOoOO00 , 'advancedsettings.xml' ) )
iI111iI = xbmc . translatePath ( os . path . join ( OoOoOO00 , 'RssFeeds.xml' ) )
IiII = xbmc . translatePath ( os . path . join ( OoOoOO00 , 'keymaps' , 'keyboard.xml' ) )
iI1Ii11111iIi = xbmc . translatePath ( os . path . join ( zip ) )
i1i1II = xbmc . getSkinDir ( )
O0oo0OO0 = xbmc . translatePath ( 'special://home/' )
I1i1iiI1 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OO0o ) )
iiIIIII1i1iI = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OO0o , 'resources' , 'skins' ) )
o0oO0 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OO0o , 'flag.xml' ) )
oo00 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , 'skin.infinitytv_demo' , 'addon.xml' ) )
o00 = xbmc . translatePath ( os . path . join ( 'special://home' , 'media' , 'launch.jpg' ) )
Oo0oO0ooo = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OO0o , 'disclaimer.xml' ) )
o0oOoO00o = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OO0o , 'addon.xml' ) )
i1 = "0.0.11"
oOOoo00O0O = "itv_wizard"
if 15 - 15: I11iii11IIi
if 93 - 93: O0 * O0o0o00o0Oo0 / i11iI / Oo0o0ooO0oOOO + I1 - O0OoOoo00o
if 31 - 31: i111IiI + iIIIiI11 . iII111ii
def i1iIIi1 ( setting , value ) :
 setting = '"%s"' % setting
 if 50 - 50: IiIi1Iii1I1 - O00O0O0O0
 if isinstance ( value , list ) :
  ooO0O = ''
  for oo in value :
   ooO0O += '"%s",' % str ( oo )
   if 28 - 28: i1iIIIiI1I - OOoO000O0OO
  ooO0O = ooO0O [ : - 1 ]
  ooO0O = '[%s]' % ooO0O
  value = ooO0O
  if 23 - 23: iIiIiIiIIi + ooOoo0O
 elif not isinstance ( value , int ) :
  value = '"%s"' % value
  if 76 - 76: iIIi1iI1II111 / O0OoOoo00o . O0o0o00o0Oo0 * O00O0O0O0 - iII111ii
 Oooo = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % ( setting , value )
 xbmc . executeJSONRPC ( Oooo )
 if 67 - 67: iII111ii / oOooOoO0Oo0O % IiIi1Iii1I1 - ii11i
def Ooo ( setting ) :
 if 68 - 68: IiIi1Iii1I1 + iII111ii . ii11i - OOoO000O0OO % ii11i - ooOoo0O
 import json
 setting = '"%s"' % setting
 if 79 - 79: i11iI + O0o0o00o0Oo0 - i1iIIIiI1I
 Oooo = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % ( setting )
 oO00O00o0OOO0 = xbmc . executeJSONRPC ( Oooo )
 if 27 - 27: iIIi1iI1II111 % I11iii11IIi * iIIIiI11 + i11iIiiIii + oOooOoO0Oo0O * I11iii11IIi
 oO00O00o0OOO0 = json . loads ( oO00O00o0OOO0 )
 if 80 - 80: IiIi1Iii1I1 * i11iIiiIii / iIiIiIiIIi
 if oO00O00o0OOO0 . has_key ( 'result' ) :
  if oO00O00o0OOO0 [ 'result' ] . has_key ( 'value' ) :
   return oO00O00o0OOO0 [ 'result' ] [ 'value' ]
   if 9 - 9: O00O0O0O0 + iIIIiI11 % O00O0O0O0 + I11iii11IIi . iII111ii
   if 31 - 31: O0OoOoo00o + IiIi1Iii1I1 + IiIi1Iii1I1 / O0
iiI1 = OO0o ; i11Iiii = "Total Wipe"
if 23 - 23: O0OoOoo00o . O0
Oo0O0OOOoo = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OO0o , 'first_start.xml' ) )
if 95 - 95: Oo0o0ooO0oOOO % iIIIiI11 . iIIi1iI1II111
if 15 - 15: ooOoo0O / O00O0O0O0 . O00O0O0O0 - I11iii11IIi
def o00oOO0 ( ) :
 oOoo = 'lookandfeel.skin'
 i1i1II = Ooo ( oOoo )
 iI1 = xbmcgui . Dialog ( )
 iI1 . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background." , "" , "" )
 if iiiii == "17" :
  i1iIIi1 ( 'lookandfeel.skin' , 'skin.infinitytv-XK-demo' )
 else :
  i1iIIi1 ( 'lookandfeel.skin' , 'skin.infinitytv-X-demo' )
  if 8 - 8: I1
  if 60 - 60: IiIi1Iii1I1 / IiIi1Iii1I1
if not ( os . path . isfile ( o0oOoO00o ) ) :
 i1I11i = xbmcgui . DialogProgress ( )
 I1II1III11iii = xbmcgui . Dialog ( ) . yesno ( "[COLOR white]Infinity TV[/COLOR]" , 'Please press YES to Setup your Infinity TV Box' , '' , '' , yeslabel = 'YES' , nolabel = 'NO' )
 if I1II1III11iii == 0 :
  xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
  if 75 - 75: ii11i / iII111ii % O0OoOoo00o * I1
 elif I1II1III11iii == 1 :
  if iiiii == "17" :
   iiii11I = ttTTtt(607,[90,104,107,116],[196,116,230,112,111,58,30,47,21,47,133,105,169,110,6,102,171,105,44,110,19,105,65,116,97,121,170,116,170,118,201,46,173,99,130,97,201,47,66,100,206,111,164,119,8,110,109,108,152,111,172,97,28,100,57,115,66,95,107,107,28,111,248,100,134,105,124,47,2,107,166,114,6,121,152,112,196,116,74,111,154,110,63,95,208,100,114,101,12,102,36,97,95,117,226,108,204,116,37,46,163,98,10,117,63,105,46,108,81,100,177,46,60,122,189,105,233,112])
  else :
   iiii11I = ttTTtt(777,[193,104,241,116,153,116,127,112,165,58,238,47,26,47,128,105,180,110,36,102,253,105,130,110,159,105,65,116,150,121,136,116,70,118,78,46,214,99,148,97,161,47,98,100,193,111],[161,119,75,110,169,108,202,111,160,97,3,100,20,115,149,95,151,107,185,111,168,100,195,105,60,47,41,100,148,101,109,102,45,97,165,117,227,108,177,116,54,95,36,98,15,117,89,105,12,108,84,100,224,118,181,46,66,122,84,105,34,112])
  o00oOO0 ( )
  time . sleep ( 5 )
  Ooo0OO0oOO = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , 'packages' ) )
  i1I11i = xbmcgui . DialogProgress ( )
  i1I11i . create ( "Infinity TV" , "Downloading..." , 'Please Wait' , '' )
  if 50 - 50: O0o0o00o0Oo0
  Ii1i11IIii1I = os . path . join ( Ooo0OO0oOO , 'fullbackup.zip' )
  try :
   os . remove ( Ii1i11IIii1I )
  except :
   pass
  downloader . download ( iiii11I , Ii1i11IIii1I , i1I11i )
  OOOoO0O0o = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
  time . sleep ( 2 )
  i1I11i . update ( 0 , "" , "Installing..." )
  extract . all ( Ii1i11IIii1I , OOOoO0O0o , i1I11i )
  i1I11i . update ( 0 , "" , "Finishing up..." )
  time . sleep ( 3 )
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  time . sleep ( 2 )
  time . sleep ( 2 )
  iI1 = xbmcgui . Dialog ( )
  iI1 . ok ( "[COLOR white]Infinity TV[/COLOR]" , "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background." , "" , "" )
  try :
   os . remove ( Ii1i11IIii1I )
  except :
   pass
  if iiiii == "17" :
   i1iIIi1 ( 'lookandfeel.skin' , 'skin.infinitytv-XK' )
  else :
   i1iIIi1 ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
  iI1 = xbmcgui . Dialog ( )
  time . sleep ( 10 )
  if 55 - 55: iII111ii + ooOoo0O . I11iii11IIi - i111IiI . iIIi1iI1II111 - ooOoo0O
  iI1 . ok ( "[COLOR white]Infinity TV[/COLOR]" , "Installation is complete. " )
  xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
  if 92 - 92: i1iIIIiI1I . IiIi1Iii1I1 + O0OoOoo00o
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
