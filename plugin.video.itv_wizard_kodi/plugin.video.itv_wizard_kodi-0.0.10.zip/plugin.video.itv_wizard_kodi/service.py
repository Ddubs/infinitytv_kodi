import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import sys,plugintools
import zipfile
import net
net=net.Net()

ADDON=xbmcaddon.Addon(id='plugin.video.itv_wizard_kodi')
THESITE = 'Infinitytv.ca'
zip          =  ADDON.getSetting('zip')
dialog       =  xbmcgui.Dialog()
dp           =  xbmcgui.DialogProgress()
USERDATA     =  xbmc.translatePath(os.path.join('special://home/userdata',''))
ADDON_DATA   =  xbmc.translatePath(os.path.join(USERDATA,'addon_data'))
ADDONS       =  xbmc.translatePath(os.path.join('special://home','addons'))
GUI          =  xbmc.translatePath(os.path.join(USERDATA,'guisettings.xml'))
FAVS         =  xbmc.translatePath(os.path.join(USERDATA,'favourites.xml'))
SOURCE       =  xbmc.translatePath(os.path.join(USERDATA,'sources.xml'))
ADVANCED     =  xbmc.translatePath(os.path.join(USERDATA,'advancedsettings.xml'))
RSS          =  xbmc.translatePath(os.path.join(USERDATA,'RssFeeds.xml'))
KEYMAPS      =  xbmc.translatePath(os.path.join(USERDATA,'keymaps','keyboard.xml'))
USB          =  xbmc.translatePath(os.path.join(zip))
skin         =  xbmc.getSkinDir()
HOME         =  xbmc.translatePath('special://home/')
AddonID      ='plugin.video.itv_wizard_kodi'; AddonTitle="Total Wipe"


USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
ADDON=xbmcaddon.Addon(id='plugin.video.itv_wizard_kodi')

android_location = xbmc.translatePath(os.path.join('sdcard','sys_default'))

if not 'sys_401.txt' in android_location:
    dialog.ok('[COLOR red]WRONG DEVICE USED[/COLOR]','Please go to www.infinitytv.ca to see why your purhased device doesn\'t work!')
    print '################ Device Failed 1 ######################################'
    #xbmc.executebuiltin('Quit')

