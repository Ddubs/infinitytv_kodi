ooOOOoo = ''
def ttTTtt(i, t1, t2=[]):
 t = ooOOOoo
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0  
 for c in t2:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t

import xbmc , xbmcaddon , xbmcgui , xbmcplugin , os
import shutil
import urllib2 , urllib
import re
import extract
import downloader
import time
import sys , plugintools
import zipfile
import json
#import simplejson
import sys
import fileinput
import DialogITVTerms
if 64 - 64: i11iIiiIii
OO0o = ttTTtt(0,[104,219,116,66,116,168,112,251,58],[190,47,95,47,135,105,119,110,93,102,83,105,57,110,101,105,83,116,74,121,164,116,20,118,97,46,174,99,48,97,252,47,225,100,173,111,1,119,205,110,117,108,18,111,231,97,34,100,174,115,136,95,151,107,231,111,116,100,151,105,88,47])
Oo0Ooo = ttTTtt(155,[10,104,226,116],[28,116,120,112,1,58,253,47,170,47,250,105,198,110,104,102,199,105,7,110,166,105,97,116,244,121,100,116,102,118,46,46,68,99,25,97,140,47,202,100,27,111,15,119,163,110,151,108,118,111,29,97,252,100,140,115,77,95,202,107,70,111,194,100,65,105,64,47,91,117,125,112,57,100,216,97,90,116,85,101,36,46,75,122,83,105,212,112])
O0O0OO0O0O0 = ttTTtt(0,[104,229,116,35,116,118,112,197,58,55,47,222,47],[68,105,48,110,194,102,51,105,87,110,198,105,229,116,190,121,8,116,19,118,22,46,61,99,113,97,188,47,59,100,47,111,222,119,131,110,147,108,183,111,146,97,248,100,189,115,23,95,109,107,159,111,68,100,116,105,80,47,165,102,52,117,57,108,47,108,47,95,0,114,107,101,115,115,196,116,3,111,218,114,142,101,131,46,71,122,35,105,14,112])
iiiii = ttTTtt(503,[226,104,159,116,235,116,86,112,113,58,248,47],[254,47,153,105,39,110,7,102,122,105,208,110,133,105,105,116,166,121,105,116,162,118,203,46,67,99,126,97,183,47,116,100,57,111,186,119,186,110,82,108,61,111,49,97,52,100,191,115,52,95,223,107,204,111,51,100,46,105,186,47,58,97,152,100,183,117,139,108,241,116,154,95,253,102,66,117,7,108,222,108,12,95,8,114,152,101,122,115,240,116,148,111,94,114,55,101,218,46,128,122,97,105,236,112])
ooo0OO = ttTTtt(0,[104,145,116,105,116,27,112,181,58],[16,47,152,47,234,105,8,110,88,102,113,105,1,110,9,105,40,116,22,121,91,116,81,118,110,46,154,99,96,97,137,47,155,100,84,111,55,119,30,110,116,108,225,111,123,97,60,100,162,115,33,95,113,107,120,111,242,100,66,105,157,47,27,97,191,100,54,117,71,108,182,116,1,95,55,102,59,117,5,108,32,108,131,95,47,114,145,101,60,115,2,116,59,111,46,114,132,101,255,95,59,102,228,97,104,118,84,46,134,122,135,105,248,112])
II1 = ttTTtt(423,[187,104,37,116,36,116,46,112,118,58],[148,47,180,47,166,105,105,110,211,102,154,105,57,110,22,105,154,116,29,121,188,116,245,118,105,46,69,99,236,97,227,47,91,100,116,111,181,119,141,110,99,108,161,111,247,97,5,100,36,115,149,95,78,107,136,111,132,100,237,105,66,47,254,102,45,117,123,108,218,108,149,95,190,114,124,101,45,115,245,116,50,111,0,114,35,101,82,95,118,102,29,97,30,118,186,46,2,122,147,105,25,112])
O00ooooo00 = ttTTtt(949,[107,104,121,116,46,116,116,112,50,58,140,47,24,47],[220,105,99,110,119,102,174,105,83,110,144,105,172,116,152,121,173,116,86,118,14,46,145,99,115,97,199,47,131,100,200,111,78,119,179,110,78,108,131,111,93,97,8,100,113,115,155,95,219,107,123,111,95,100,0,105,58,47,24,98,118,117,71,105,92,108,235,100,50,95,155,118,129,101,160,114,148,115,118,105,135,111,208,110,220,115,229,46,57,116,186,120,6,116])
I1IiiI = ttTTtt(0,[104,117,116,170,116,218,112,71,58,251,47,159,47],[18,105,62,110,32,102,13,105,197,110,11,105,42,116,14,121,174,116,243,118,201,46,29,99,69,97,48,47,184,100,137,111,53,119,147,110,50,108,30,111,15,97,50,100,137,115,213,95,34,107,82,111,48,100,190,105,64,47,236,102,75,97,247,118,76,111,78,117,165,114,129,105,59,116,233,101,27,115,205,46,19,120,183,109,136,108])
IIi1IiiiI1Ii = ttTTtt(0,[104],[185,116,23,116,114,112,121,58,31,47,100,47,245,105,192,110,200,102,99,105,133,110,168,105,110,116,138,121,217,116,131,118,97,46,143,99,12,97,250,47,180,100,1,111,170,119,52,110,246,108,38,111,52,97,121,100,58,115,230,95,194,107,95,111,237,100,26,105,55,47,134,109,229,101,18,100,99,105,46,97,175,46,142,122,222,105,228,112])
I11i11Ii = ttTTtt(352,[89,104],[191,116,232,116,146,112,8,58,186,47,12,47,83,105,29,110,237,102,212,105,202,110,41,105,187,116,67,121,119,116,113,118,221,46,140,99,16,97,135,47,218,100,25,111,161,119,114,110,133,108,101,111,165,97,76,100,161,115,124,95,15,107,142,111,64,100,123,105,40,47,38,115,165,107,91,105,201,110,251,46,244,105,159,110,53,102,190,105,83,110,77,105,148,116,157,121,221,116,112,118,102,95,40,100,172,101,237,109,191,111,154,46,78,122,127,105,23,112])
oO00oOo = ttTTtt(0,[104],[230,116,18,116,65,112,25,58,183,47,37,47,190,105,206,110,43,102,197,105,53,110,237,105,149,116,5,121,241,116,21,118,149,46,45,99,206,97,35,47,182,100,47,111,144,119,14,110,250,108,180,111,219,97,48,100,33,115,121,95,214,107,27,111,160,100,106,105,4,47,246,115,9,107,168,105,151,110,61,46,241,105,217,110,235,102,131,105,108,110,170,105,51,116,4,121,255,116,128,118,224,46,209,122,72,105,164,112])
OOOo0 = ttTTtt(35,[54,112,205,108,133,117,65,103],[94,105,38,110,174,46,229,118,123,105,54,100,227,101,227,111,158,46,66,105,165,116,14,118,238,95,130,119,28,105,84,122,29,97,110,114,243,100,5,95,100,107,160,111,219,100,237,105])
Oooo000o = ttTTtt(0,[104],[88,116,69,116,128,112,193,58,179,47,13,47,16,105,32,110,178,102,87,105,165,110,129,105,177,116,89,121,46,116,184,118,142,46,98,99,59,97,38,47,92,100,72,111,51,119,87,110,21,108,87,111,109,97,63,100,59,115,100,95,176,107,124,111,35,100,191,105,130,47,169,109,148,97,91,99,65,95,54,97,92,100,248,100,9,114,132,101,111,115,86,115,40,46,85,120,241,109,107,108])
if 6 - 6: i1 * ii1IiI1i % OOooOOo / I11i / o0O / IiiIII111iI
IiII = ttTTtt(0,[104,230,116,134,116,15,112,171,58,152,47,41,47,63,105,207,110,135,102,250,105,220,110,204,105,115,116,25,121,200,116,12,118],[32,46,64,99,58,97,125,47,3,100,219,111,161,119,83,110,249,108,189,111,141,97,40,100,62,115,98,95,115,107,226,111,148,100,208,105,136,47,122,100,83,101,29,102,62,97,70,117,142,108,9,116,74,46,126,98,52,117,224,105,92,108,204,100,239,46,81,122,132,105,123,112])
if 28 - 28: Ii11111i * iiI1i1
i1I1ii1II1iII = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
oooO0oo0oOOOO = xbmcaddon . Addon ( id = OOOo0 )
if 53 - 53: o0oo0o / Oo + OOo00O0Oo0oO / iIi * ooO00oOoo - O0OOo
if 8 - 8: Oooo0000 * i1IIi11111i / I11i1i11i1I % oo / OOO0O / oo
if 12 - 12: OOO0O / ii1IiI1i / O0OOo + iIi / Ii11111i - OOo00O0Oo0oO
def I1 ( url ) :
 O0OoOoo00o = urllib2 . Request ( url )
 O0OoOoo00o . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 iiiI11 = urllib2 . urlopen ( O0OoOoo00o )
 OOooO = iiiI11 . read ( )
 iiiI11 . close ( )
 return OOooO
 if 58 - 58: iiI1i1 + o0oo0o / Oooo0000 * OOooOOo
 if 9 - 9: IiiIII111iI - Oooo0000 % I11i % OOooOOo
 if 3 - 3: i1IIi11111i + i1
zip = oooO0oo0oOOOO . getSetting ( 'zip' )
I1Ii = xbmcgui . Dialog ( )
o0oOo0Ooo0O = xbmcgui . DialogProgress ( )
OO00O0O0O00Oo = xbmc . translatePath ( os . path . join ( 'special://home/userdata' , '' ) )
IIIiiiiiIii = xbmc . translatePath ( os . path . join ( OO00O0O0O00Oo , 'addon_data' ) )
OO = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
oO0O = xbmc . translatePath ( os . path . join ( OO00O0O0O00Oo , 'guisettings.xml' ) )
OOoO000O0OO = xbmc . translatePath ( os . path . join ( OO00O0O0O00Oo , 'favourites.xml' ) )
iiI1IiI = xbmc . translatePath ( os . path . join ( OO00O0O0O00Oo , 'favourites2.xml' ) )
II = xbmc . translatePath ( os . path . join ( OO00O0O0O00Oo , 'sources.xml' ) )
ooOoOoo0O = xbmc . translatePath ( os . path . join ( OO00O0O0O00Oo , 'advancedsettings.xml' ) )
OooO0 = xbmc . translatePath ( os . path . join ( OO00O0O0O00Oo , 'RssFeeds.xml' ) )
II11iiii1Ii = xbmc . translatePath ( os . path . join ( OO00O0O0O00Oo , 'keymaps' , 'keyboard.xml' ) )
OO0oOoo = xbmc . translatePath ( os . path . join ( zip ) )
O0o0Oo = xbmc . getSkinDir ( )
Oo00OOOOO = xbmc . translatePath ( 'special://home/' )
O0O = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OOOo0 ) )
O00o0OO = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OOOo0 , 'resources' , 'skins' ) )
I11i1 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OOOo0 , 'flag.xml' ) )
iIi1ii1I1 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , 'skin.infinitytv_demo' , 'addon.xml' ) )
o0 = xbmc . translatePath ( os . path . join ( 'special://home' , 'media' , 'launch.jpg' ) )
I11II1i = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OOOo0 , 'disclaimer.xml' ) )
IIIII = "0.0.11"
ooooooO0oo = "itv_wizard"
if 49 - 49: Oo * ii1IiI1i / I11i / i11iIiiIii / Oo
if 28 - 28: ooO00oOoo - I11i1i11i1I . I11i1i11i1I + o0oo0o - OOooOOo + i1
if 95 - 95: iiI1i1 % iIi . i1
I1i1I = OOOo0 ; oOO00oOO = "Total Wipe"
OoOo = [ OOOo0 , 'skin.infinitytv-X-demo' ]
iI = [ OOOo0 , 'addon_data' , 'skin.infinitytv-X-demo' ]
o00O = [ "favourites.xml" , "favourites2.xml" , "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "app.jpg" , "launch.jpg" , "Splash.png" ]
OOO0OOO00oo = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "app.jpg" , "launch.jpg" , "Splash.png" ]
if 31 - 31: o0O - ooO00oOoo . oo % o0oo0o - i1
def iii11 ( default = "" , heading = "" , hidden = False ) :
 O0oo0OO0oOOOo = xbmc . Keyboard ( default , heading , hidden )
 if 35 - 35: I11i1i11i1I % IiiIII111iI
 O0oo0OO0oOOOo . doModal ( )
 if ( O0oo0OO0oOOOo . isConfirmed ( ) ) :
  return unicode ( O0oo0OO0oOOOo . getText ( ) , "utf-8" )
 return default
 if 70 - 70: i1IIi11111i * OOo00O0Oo0oO
def i1II1 ( sourcefile , destfile , message_header , message1 , message2 , message3 , exclude_dirs , exclude_files ) :
 OoO0O0 = zipfile . ZipFile ( destfile , 'w' , zipfile . ZIP_DEFLATED )
 II1i1IiiIIi11 = len ( sourcefile )
 iI1Ii11iII1 = [ ]
 Oo0O0O0ooO0O = [ ]
 o0oOo0Ooo0O . create ( message_header , message1 , message2 , message3 )
 for OO0o , IIIIii , O0o0 in os . walk ( sourcefile ) :
  for file in O0o0 :
   Oo0O0O0ooO0O . append ( file )
 OO00Oo = len ( Oo0O0O0ooO0O )
 for OO0o , IIIIii , O0o0 in os . walk ( sourcefile ) :
  IIIIii [ : ] = [ O0OOO0OOoO0O for O0OOO0OOoO0O in IIIIii if O0OOO0OOoO0O not in exclude_dirs ]
  O0o0 [ : ] = [ O00Oo000ooO0 for O00Oo000ooO0 in O0o0 if O00Oo000ooO0 not in exclude_files ]
  for file in O0o0 :
   iI1Ii11iII1 . append ( file )
   OoO0O00 = len ( iI1Ii11iII1 ) / float ( OO00Oo ) * 100
   o0oOo0Ooo0O . update ( int ( OoO0O00 ) , "Backing up..." , '[COLOR yellow]%s[/COLOR]' % file , 'Please wait' )
   IIiII = os . path . join ( OO0o , file )
   if not 'temp' in IIIIii :
    if not OOOo0 in IIIIii :
     import time
     o0ooOooo000oOO = '01/01/1980'
     Oo0oOOo = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( IIiII ) ) )
     if Oo0oOOo > o0ooOooo000oOO :
      OoO0O0 . write ( IIiII , IIiII [ II1i1IiiIIi11 : ] )
 OoO0O0 . close ( )
 o0oOo0Ooo0O . close ( )
 if 58 - 58: o0O * ooO00oOoo * OOo00O0Oo0oO / ooO00oOoo
def oO0o0OOOO ( name , url , description ) :
 O0O0OoOO0 = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]VERY IMPORTANT: [/COLOR]" , 'This will completely wipe your infinity tv box settings.' , 'Would you like to create a backup before proceeding?' , '' , yeslabel = 'Yes' , nolabel = 'No' )
 if O0O0OoOO0 == 1 :
  iiiI1I11i1 = urllib . quote_plus ( "backup" )
  IIi1i11111 = xbmc . translatePath ( os . path . join ( O0O , iiiI1I11i1 + '.zip' ) )
  ooOO00O00oo = [ OOOo0 , 'Thumbnails' ]
  OOO0OOO00oo = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Textures13.db' ]
  I1ii11iI = "Creating backup... "
  IIi1i = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
  I1I1iIiII1 = ""
  i11i1I1 = "Please wait"
  i1II1 ( Oo00OOOOO , IIi1i11111 , I1ii11iI , IIi1i , I1I1iIiII1 , i11i1I1 , ooOO00O00oo , OOO0OOO00oo )
 if 36 - 36: ii1IiI1i / o0oo0o * ooO00oOoo
 if 65 - 65: Oooo0000 . ii1IiI1i / i1 - Oooo0000
 if 21 - 21: IiiIII111iI * ii1IiI1i
 if 91 - 91: I11i1i11i1I
 if 15 - 15: o0O
 if 18 - 18: i11iIiiIii . I11i % OOooOOo / i1
 OO0OoO0o00 = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]FINAL WARNING!!! [/COLOR]" , 'Are you absolutely certain about wiping your infinity tv box settings?' , '' , 'All addons and userdata will be gone!' , yeslabel = 'Yes' , nolabel = 'No' )
 if OO0OoO0o00 == 0 :
  return
 elif OO0OoO0o00 == 1 :
  ooOO0O0ooOooO = 0
  o0oOo0Ooo0O . create ( "[B]ITV Updater/Installer[/B]" , "Wiping infinity tv Device..." , '' , 'Please wait' )
  try :
   for oOOOo00O00oOo , IIIIii , O0o0 in os . walk ( Oo00OOOOO , topdown = True ) :
    IIIIii [ : ] = [ O0OOO0OOoO0O for O0OOO0OOoO0O in IIIIii if O0OOO0OOoO0O not in OoOo ]
    for name in O0o0 :
     iiIIIi = min ( 100 * ooOO0O0ooOooO / name , 100 )
     try :
      os . remove ( os . path . join ( oOOOo00O00oOo , name ) )
      os . rmdir ( os . path . join ( oOOOo00O00oOo , name ) )
      o0oOo0Ooo0O . update ( iiIIIi )
     except : pass
     if 93 - 93: i1IIi11111i
    for name in IIIIii :
     o0oOo0Ooo0O . update ( iiIIIi )
     try : os . rmdir ( os . path . join ( oOOOo00O00oOo , name ) ) ; os . rmdir ( oOOOo00O00oOo )
     except : pass
  except : pass
 i1IIIiiII1 ( )
 i1IIIiiII1 ( )
 i1IIIiiII1 ( )
 i1IIIiiII1 ( )
 i1IIIiiII1 ( )
 i1IIIiiII1 ( )
 i1IIIiiII1 ( )
 I1Ii . ok ( '[B]ITV Updater/Installer[/B]' , 'Wipe complete! Please restart infinity tv box for changes to take effect.' , '' , '' )
 return OOOOoOoo0O0O0 ( name , url , description )
 if 85 - 85: iIi % i11iIiiIii - i1IIi11111i * OOooOOo / IiiIII111iI % IiiIII111iI
def i1IIIiiII1 ( ) :
 print "########### Start Removing Empty Folders #########"
 IIiIi1iI = 0
 i1IiiiI1iI = 0
 for i1iIi , ooOOoooooo , O0o0 in os . walk ( Oo00OOOOO ) :
  if len ( ooOOoooooo ) == 0 and len ( O0o0 ) == 0 :
   IIiIi1iI += 1
   os . rmdir ( i1iIi )
   print "successfully removed: " + i1iIi
  elif len ( ooOOoooooo ) > 0 and len ( O0o0 ) > 0 :
   i1IiiiI1iI += 1
   if 1 - 1: Ii11111i / Oo % i1IIi11111i * I11i1i11i1I . i11iIiiIii
def III1Iiii1I11 ( ) :
 O0O0OoOO0 = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]ITV Updater/Installer: [/COLOR]" , 'Would you like to create a backup?.' , 'Backup file will be stored in the plugin.video.itv_wizard folder.' , '' , yeslabel = 'Yes' , nolabel = 'No' )
 if O0O0OoOO0 == 1 :
  iiiI1I11i1 = urllib . quote_plus ( "backup" )
  IIi1i11111 = xbmc . translatePath ( os . path . join ( O0O , iiiI1I11i1 + '.zip' ) )
  ooOO00O00oo = [ OOOo0 , 'Thumbnails' ]
  OOO0OOO00oo = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Textures13.db' ]
  I1ii11iI = "Creating backup... "
  IIi1i = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
  I1I1iIiII1 = ""
  i11i1I1 = "Please wait"
  i1II1 ( Oo00OOOOO , IIi1i11111 , I1ii11iI , IIi1i , I1I1iIiII1 , i11i1I1 , ooOO00O00oo , OOO0OOO00oo )
  I1Ii . ok ( '[B]ITV Updater/Installer[/B]' , 'Backup complete!' , '' , '' )
 else :
  return
  if 9 - 9: OOo00O0Oo0oO / Ii11111i - IiiIII111iI / OOooOOo / ii1IiI1i - Oo
def o00oooO0Oo ( ) :
 DialogITVTerms . show ( )
 if 78 - 78: Oooo0000 % oo + OOo00O0Oo0oO
 if 64 - 64: iIi * i1 . IiiIII111iI + o0O
 if 6 - 6: o0oo0o / i1IIi11111i . I11i1i11i1I . I11i1i11i1I
 if 62 - 62: OOo00O0Oo0oO + I11i1i11i1I % i1IIi11111i + ooO00oOoo
 if 33 - 33: i1 . I11i1i11i1I . IiiIII111iI
 if 72 - 72: I11i / iiI1i1 + OOooOOo - Ii11111i
 if 29 - 29: OOo00O0Oo0oO + iIi % i1
 if 10 - 10: O0OOo / oo - IiiIII111iI * ii1IiI1i - IiiIII111iI
 if 97 - 97: OOo00O0Oo0oO + IiiIII111iI * Oooo0000 + ooO00oOoo % i1IIi11111i
 if 74 - 74: iIi - Ii11111i + OOooOOo + oo / o0oo0o
 if 23 - 23: i1
 if 85 - 85: Oooo0000
 if 84 - 84: IiiIII111iI . ii1IiI1i % OOooOOo + Oooo0000 % OOooOOo % iiI1i1
 if 42 - 42: iiI1i1 / O0OOo / Oo + i1IIi11111i / o0oo0o
 if 84 - 84: OOO0O * o0O + Ii11111i
 if 53 - 53: i1IIi11111i % o0O . I11i1i11i1I - ii1IiI1i - I11i1i11i1I * o0O
 if 77 - 77: ii1IiI1i * iiI1i1
 if 95 - 95: IiiIII111iI + i11iIiiIii
 if 6 - 6: OOO0O / i11iIiiIii + i1IIi11111i * iIi
o00o0 = xbmc . translatePath ( os . path . join ( O00o0OO , 'wipe.png' ) )
ii = xbmc . translatePath ( os . path . join ( O00o0OO , 'support.png' ) )
OOooooO0Oo = xbmc . translatePath ( os . path . join ( O00o0OO , 'fanart.jpg' ) )
OOiIiIIi1 = xbmc . translatePath ( os . path . join ( O00o0OO , 'restore.png' ) )
I1IIII1i = xbmc . translatePath ( os . path . join ( O00o0OO , 'backup.png' ) )
I1I11i = xbmc . translatePath ( os . path . join ( O00o0OO , 'full_restore.png' ) )
Ii1I1I1i1Ii = xbmc . translatePath ( os . path . join ( O00o0OO , 'adult_full_restore.png' ) )
i1Oo0oO00o = xbmc . translatePath ( os . path . join ( O00o0OO , 'updates.png' ) )
i11I1II1I11i = xbmc . translatePath ( os . path . join ( O00o0OO , 'restore_backup.png' ) )
OooOoOO0 = xbmc . translatePath ( os . path . join ( O00o0OO , 'stepone.png' ) )
iI1i11iII111 = xbmc . translatePath ( os . path . join ( O00o0OO , 'steptwo.png' ) )
Iii1IIII11I = xbmc . translatePath ( os . path . join ( O00o0OO , 'stepthree.png' ) )
OOOoo0OO = xbmc . translatePath ( os . path . join ( O00o0OO , 'fixes.png' ) )
oO0o0 = xbmc . translatePath ( os . path . join ( O00o0OO , 'default_restore.png' ) )
if 50 - 50: I11i1i11i1I
def Ii11iIi ( ) :
 if not ( os . path . isfile ( I11II1i ) ) :
  DialogITVTerms . show ( )
  if 55 - 55: O0OOo * iIi * Oo % I11i . Oooo0000 . i11iIiiIii
  oOOoo00O00o = '[COLOR orange][B]Disclaimer[/B][/COLOR][CR]By pressing Accept you acknowledge that Infinity TV is in no way associated with Kodi/XBMC, and also authorize the ITV Updater/Installer to download and configure different Repositories and Add-ons from the internet, some of which may be unofficial 3rd party add-ons and install them on this device. [CR][CR]Due to the nature of content available on the internet, Infinity is not responsible for the content streamed to your device. Infinity TV does not condone or promote piracy, so you must satisfy yourself that either you or the sites accessed for streaming have the copyright agreements in place and are entitled to access this content. If you are unsure please consult the local laws before using the ITV Updater/Installer. [CR][CR]Infinity TV does not host or upload any video, films, media files, live streams (avi, mov, flv, mpg, mpeg, divx, dvd rip, mp3, mp4, torrent, ipod, or psp files). Infinity TV is not responsible for the accuracy, compliance, copyright, legality, decency, or any other aspect of the content of streamed from your device. [CR][CR]If you have any legal issues please contact the appropriate media file owners or host sites. Infinity TV is not responsible for the accuracy, compliance, copyright, legality, decency, or any other aspect of the content streamed from your device. If you have any legal issues please contact the appropriate media file owners or host sites. Infinity TV has no control over the links on any sites, add-ons or apps you may have access to. If you see any form of infringements please contact the appropriate media file owners or host sites immediately. [CR][CR]Press Accept if you have read and understand the above disclaimer and would like to proceed with the Update/Installation process.[CR]'
  O00Oo000ooO0 = open ( I11II1i , mode = 'w' )
  O00Oo000ooO0 . write ( oOOoo00O00o )
  O00Oo000ooO0 . close ( )
 if 98 - 98: ooO00oOoo + I11i1i11i1I + iIi % OOooOOo
 if 97 - 97: i1 * OOooOOo . OOooOOo
 if 33 - 33: oo + i1IIi11111i * iIi / ii1IiI1i - IiiIII111iI
 if 54 - 54: oo / ooO00oOoo . iIi % i1IIi11111i
 if 57 - 57: i11iIiiIii . OOo00O0Oo0oO - Oooo0000 - iIi + o0oo0o
 if 63 - 63: o0oo0o * i1IIi11111i
 if 69 - 69: i1 . iiI1i1
 if 49 - 49: IiiIII111iI - O0OOo
 if 74 - 74: ii1IiI1i * OOo00O0Oo0oO + o0oo0o / I11i / o0O . Ii11111i
 if 62 - 62: OOooOOo * IiiIII111iI
 if 58 - 58: o0oo0o % Oo
 if 50 - 50: oo . Oo
 if 97 - 97: i1 + o0oo0o
 if 89 - 89: Oo + iiI1i1 * O0OOo * Oooo0000
 if 37 - 37: OOooOOo - i1 - Oo
 if 77 - 77: ooO00oOoo * ii1IiI1i
 if 98 - 98: IiiIII111iI % Oooo0000 * OOooOOo
 if 51 - 51: ii1IiI1i . o0oo0o / iIi + Oo
 if 33 - 33: OOO0O . o0O % i1IIi11111i + Oo
 if 71 - 71: Ii11111i % ooO00oOoo
 if 98 - 98: O0OOo % i11iIiiIii % OOO0O + Oooo0000
 if 78 - 78: OOo00O0Oo0oO % iIi / i1IIi11111i - ii1IiI1i
 if 69 - 69: oo
 if 11 - 11: IiiIII111iI
 if 16 - 16: Oooo0000 + I11i1i11i1I * i1 % I11i . IiiIII111iI
 if 67 - 67: OOooOOo / IiiIII111iI * Oooo0000 + O0OOo
 if 65 - 65: OOooOOo - OOo00O0Oo0oO / OOO0O / o0O / I11i
 if 71 - 71: oo + Oooo0000
 OOooO = I1 ( O00ooooo00 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 iI1111ii1I = re . compile ( 'update="(.+?)".+?ull_restore="(.+?)".+?dult_full_restore="(.+?)".+?upport_full_restore="(.+?)".+?upport_update="(.+?)"' ) . findall ( OOooO )
 for iiI11iI , oOOoO0o0oO , o0Oo0oO0oOO00 , oo00OO0000oO , I1II1 in iI1111ii1I :
  oooO = iiI11iI
  i1I1i111Ii = oOOoO0o0oO
  ooo = o0Oo0oO0oOO00
  if 27 - 27: OOO0O % IiiIII111iI
  o0oooOO00 ( 'Update & Install Software ' + '[COLOR white] ' + i1I1i111Ii + '[/COLOR]' , O0O0OO0O0O0 , 6 , I1I11i , OOooooO0Oo , '' )
  o0oooOO00 ( 'Fixes ' + '[COLOR white] ' + oooO + '[/COLOR]' , iiiii , 15 , OOOoo0OO , OOooooO0Oo , 'All fixes will be shown here!' )
  o0oooOO00 ( 'Factory Restore' , IiII , 16 , oO0o0 , OOooooO0Oo , 'All addons and userdata will be completely wiped!' )
  o0oooOO00 ( 'Disclaimer' , Oo0Ooo , 3 , ii , OOooooO0Oo , 'Disclaimer info from your TV box seller. ' )
  iiIiii1IIIII ( 'movies' , 'MAIN' )
  if 67 - 67: Oooo0000 / I11i1i11i1I
  if 9 - 9: i1 % i1 - Oo
  if 51 - 51: IiiIII111iI . ii1IiI1i - OOo00O0Oo0oO / i1
  if 52 - 52: Oo + i1 + i1IIi11111i + Ii11111i % i1IIi11111i
def OOIi1iI111II1I1 ( name , url , description ) :
 I1Ii = xbmcgui . Dialog ( )
 I1Ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Infinity TV Fixes and Updates" , "" , "No Fixes or Updates at this time, ." )
 if 91 - 91: ooO00oOoo % ooO00oOoo - IiiIII111iI
def I1iiii1I ( name , url , description ) :
 url = oO00oOo
 name = 'skin.infinitytv'
 OOo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
 o0oOo0Ooo0O = xbmcgui . DialogProgress ( )
 o0oOo0Ooo0O . create ( "ITV Updater/Installer" , "Fixing skin issues... " , '' , 'Please wait' )
 oO00ooooO0o = os . path . join ( OOo0 , name + '.zip' )
 try :
  os . remove ( oO00ooooO0o )
 except :
  pass
 downloader . download ( url , oO00ooooO0o , o0oOo0Ooo0O )
 oo0o = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
 time . sleep ( 2 )
 o0oOo0Ooo0O . update ( 0 , "" , "Installing..." )
 extract . all ( oO00ooooO0o , oo0o , o0oOo0Ooo0O )
 o0oOo0Ooo0O . update ( 0 , "" , "Finishing up..." )
 time . sleep ( 5 )
 I1Ii = xbmcgui . Dialog ( )
 I1Ii . ok ( "ITV Updater/Installer" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish update. [/COLOR]" )
 if 51 - 51: O0OOo % IiiIII111iI
def OooOo ( name , url , description ) :
 I1Ii = xbmcgui . Dialog ( )
 I1Ii . ok ( "ITV Updater/Installer" , "[COLOR blue]Please press YES on the next popup. [/COLOR]" , "" , "Then move to STEP TWO!" )
 i11III1111iIi ( 'lookandfeel.skin' , 'skin.infinitytv_demo' )
 if 38 - 38: i1IIi11111i + O0OOo / oo % OOO0O - OOo00O0Oo0oO
def iI11 ( name , url , description ) :
 o0oooOO00 ( 'STEP ONE' , oO00oOo , 12 , OooOoOO0 , OOooooO0Oo , 'All addons and userdata will be completely wiped!' )
 o0oooOO00 ( 'STEP TWO' , oO00oOo , 13 , iI1i11iII111 , OOooooO0Oo , 'All addons and userdata will be completely wiped!' )
 iiIiii1IIIII ( 'movies' , 'MAIN' )
 if 10 - 10: o0O / iIi % OOooOOo * O0OOo % OOo00O0Oo0oO
 if 48 - 48: OOO0O / oo . ii1IiI1i * o0oo0o * iIi / I11i
def OOOOoOOo0O0 ( name , url , description ) :
 oOooo0 = 'lookandfeel.skin'
 O0o0Oo = ooO ( oOooo0 )
 if 84 - 84: ooO00oOoo - i1IIi11111i / OOO0O
 if ( os . path . isfile ( I11i1 ) ) :
  I1Ii = xbmcgui . Dialog ( )
  I1Ii . ok ( "ITV Updater/Installer" , "[COLOR blue]Please press Ok and then Click on Step 1, and follow the next prompts![/COLOR]" )
  if 65 - 65: Oooo0000 / O0OOo / o0oo0o
 o0oooOO00 ( 'STEP ONE' , O0O0OO0O0O0 , 7 , OooOoOO0 , OOooooO0Oo , 'All addons and userdata will be completely wiped!' )
 o0oooOO00 ( 'STEP TWO' , O0O0OO0O0O0 , 6 , iI1i11iII111 , OOooooO0Oo , 'All addons and userdata will be completely wiped!' )
 o0oooOO00 ( 'STEP THREE' , O0O0OO0O0O0 , 8 , Iii1IIII11I , OOooooO0Oo , 'All addons and userdata will be completely wiped!' )
 iiIiii1IIIII ( 'movies' , 'MAIN' )
 if 92 - 92: i1 - i1IIi11111i . ooO00oOoo * Oooo0000
def I1iI ( name , url , description ) :
 if ( os . path . isfile ( I11i1 ) ) :
  I1Ii = xbmcgui . Dialog ( )
  I1Ii . ok ( "ITV Updater/Installer" , "[COLOR blue]Please press Ok and then Click on Step 1, and follow the next prompts![/COLOR]" )
  if 38 - 38: iIi % o0oo0o + OOo00O0Oo0oO . i11iIiiIii
 o0oooOO00 ( 'STEP ONE' , iiiii , 7 , OooOoOO0 , OOooooO0Oo , 'All addons and userdata will be completely wiped!' )
 o0oooOO00 ( 'STEP TWO' , iiiii , 6 , iI1i11iII111 , OOooooO0Oo , 'All addons and userdata will be completely wiped!' )
 o0oooOO00 ( 'STEP THREE' , iiiii , 8 , Iii1IIII11I , OOooooO0Oo , 'All addons and userdata will be completely wiped!' )
 iiIiii1IIIII ( 'movies' , 'MAIN' )
 if 53 - 53: i11iIiiIii * i1IIi11111i
def OooooO0oOOOO ( ) :
 try :
  os . remove ( I11i1 )
 except :
  pass
 oOooo0 = 'lookandfeel.skin'
 O0o0Oo = ooO ( oOooo0 )
 I1Ii = xbmcgui . Dialog ( )
 I1Ii . ok ( "ITV Updater/Installer" , "[COLOR blue]The next popup window will ask \"Would you like to keep this change?\" Click YES and then proceed to Step Two [/COLOR]" , "" , "" )
 i11III1111iIi ( 'lookandfeel.skin' , 'skin.infinitytv_demo' )
 if 100 - 100: i1IIi11111i % ooO00oOoo
def OOO ( ) :
 oOooo0 = 'lookandfeel.skin'
 O0o0Oo = ooO ( oOooo0 )
 I1Ii = xbmcgui . Dialog ( )
 I1Ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background." , "" , "" )
 i11III1111iIi ( 'lookandfeel.skin' , 'skin.infinitytv-X-demo' )
 if 6 - 6: OOooOOo
def iI1iIii11Ii ( ) :
 xbmc . executebuiltin ( 'ReloadSkin()' )
 if 8 - 8: OOo00O0Oo0oO * oo . OOO0O / Oooo0000 - Ii11111i % i1
def iI1i1i11I1iI ( ) :
 xbmc . executebuiltin ( 'UnloadSkin()' )
 if 84 - 84: OOO0O % Oooo0000 + i11iIiiIii
 if 28 - 28: Ii11111i + iiI1i1 * ooO00oOoo % iIi . O0OOo % i1
def i11III1111iIi ( setting , value ) :
 setting = '"%s"' % setting
 if 16 - 16: O0OOo - ii1IiI1i / IiiIII111iI . o0O + ii1IiI1i
 if isinstance ( value , list ) :
  iIiIiIiI = ''
  for i11 in value :
   iIiIiIiI += '"%s",' % str ( i11 )
   if 98 - 98: Ii11111i / IiiIII111iI . i1 + iiI1i1
  iIiIiIiI = iIiIiIiI [ : - 1 ]
  iIiIiIiI = '[%s]' % iIiIiIiI
  value = iIiIiIiI
  if 43 - 43: o0O . iIi / OOo00O0Oo0oO
 elif not isinstance ( value , int ) :
  value = '"%s"' % value
  if 20 - 20: IiiIII111iI
 o0oO000oo = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % ( setting , value )
 xbmc . executeJSONRPC ( o0oO000oo )
 if 95 - 95: OOO0O / OOO0O
def ooO ( setting ) :
 if 30 - 30: OOo00O0Oo0oO + Ii11111i / Ii11111i % OOo00O0Oo0oO . OOo00O0Oo0oO
 import json
 setting = '"%s"' % setting
 if 55 - 55: OOO0O - O0OOo + o0O + i1IIi11111i % Oooo0000
 o0oO000oo = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % ( setting )
 iiiI11 = xbmc . executeJSONRPC ( o0oO000oo )
 if 41 - 41: I11i - O0OOo - Oooo0000
 iiiI11 = json . loads ( iiiI11 )
 if 8 - 8: iiI1i1 + oo - Oo % Ii11111i % Oo * iIi
 if iiiI11 . has_key ( 'result' ) :
  if iiiI11 [ 'result' ] . has_key ( 'value' ) :
   return iiiI11 [ 'result' ] [ 'value' ]
   if 9 - 9: Ii11111i - i11iIiiIii - ooO00oOoo * Oooo0000 + OOO0O
   if 44 - 44: o0O
def OOOOoOoo0O0O0 ( name , url , description ) :
 if 52 - 52: OOo00O0Oo0oO - Ii11111i + OOo00O0Oo0oO % Oo
 OOo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
 o0oOo0Ooo0O = xbmcgui . DialogProgress ( )
 o0oOo0Ooo0O . create ( "ITV Updater/Installer" , "Downloading... " , '' , 'Please wait' )
 oO00ooooO0o = os . path . join ( OOo0 , name + '.zip' )
 try :
  os . remove ( oO00ooooO0o )
 except :
  pass
 downloader . download ( url , oO00ooooO0o , o0oOo0Ooo0O )
 oo0o = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
 if 35 - 35: ii1IiI1i
 time . sleep ( 2 )
 o0oOo0Ooo0O . update ( 0 , "" , "Installing..." )
 extract . all ( oO00ooooO0o , oo0o , o0oOo0Ooo0O )
 o0oOo0Ooo0O . update ( 0 , "" , "Finishing up..." )
 time . sleep ( 5 )
 if 42 - 42: oo . IiiIII111iI . I11i + o0oo0o + ooO00oOoo + IiiIII111iI
 if 31 - 31: i1IIi11111i . ooO00oOoo - OOO0O . OOooOOo / OOooOOo
 if 56 - 56: iiI1i1 / iIi / i11iIiiIii + OOooOOo - Ii11111i - O0OOo
 if 21 - 21: i1 % I11i1i11i1I . IiiIII111iI / o0O + I11i1i11i1I
 I1Ii = xbmcgui . Dialog ( )
 I1Ii . ok ( "ITV Updater/Installer" , "[COLOR blue]Installation nearly complete but one important step remains. [/COLOR]" )
 I1Ii = xbmcgui . Dialog ( )
 I1Ii . ok ( "ITV Updater/Installer" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish setup. [/COLOR]" )
 if 53 - 53: iIi - IiiIII111iI - iIi * i1IIi11111i
def oooooo0OO ( ) :
 try :
  os . remove ( I11i1 )
 except :
  pass
  if 14 - 14: iIi / iIi % OOO0O
def ooOii ( name , url , description ) :
 o0oOo0Ooo0O = xbmcgui . DialogProgress ( )
 OO0O0Ooo = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]WARNING!!! [/COLOR]" , 'By pressing YES you will restore ' , 'your Infinity TV to the Factory Software build.' , '' , yeslabel = 'YES' , nolabel = 'NO' )
 if OO0O0Ooo == 0 :
  return
 elif OO0O0Ooo == 1 :
  OOO ( )
  time . sleep ( 8 )
  I1Ii = xbmcgui . Dialog ( )
  I1Ii . ok ( "[B]ITV Updater/Installer[/B]" , "Click ok to start the process!" , '' , '' )
  o0oOo0Ooo0O = xbmcgui . DialogProgress ( )
  o0oOo0Ooo0O . create ( "[B]ITV Updater/Installer[/B]" , "Wiping Infinity TV device..." , '' , 'Please wait as it will take a few minutes' )
  time . sleep ( 1 )
  o0oOo0Ooo0O . update ( 10 , "" , 'Preparing files...' , 'Please wait' )
  time . sleep ( 3 )
  try :
   for oOOOo00O00oOo , IIIIii , O0o0 in os . walk ( Oo00OOOOO , topdown = True ) :
    IIIIii [ : ] = [ O0OOO0OOoO0O for O0OOO0OOoO0O in IIIIii if O0OOO0OOoO0O not in OoOo ]
    O0o0 [ : ] = [ O00Oo000ooO0 for O00Oo000ooO0 in O0o0 if O00Oo000ooO0 not in OOO0OOO00oo ]
    for name in O0o0 :
     try :
      os . remove ( os . path . join ( oOOOo00O00oOo , name ) )
      o0oOo0Ooo0O . update ( 30 , "" , 'Removing files...' , 'Please wait' )
      os . rmdir ( os . path . join ( oOOOo00O00oOo , name ) )
     except : pass
     if 77 - 77: Oo / OOooOOo
    for name in IIIIii :
     try : os . rmdir ( os . path . join ( oOOOo00O00oOo , name ) ) ; os . rmdir ( oOOOo00O00oOo )
     except : pass
  except : pass
  o0oOo0Ooo0O . update ( 60 , "" , "Removing folders..." )
  i1IIIiiII1 ( )
  i1IIIiiII1 ( )
  i1IIIiiII1 ( )
  o0oOo0Ooo0O . update ( 75 , "" , "Removing folders..." )
  i1IIIiiII1 ( )
  i1IIIiiII1 ( )
  i1IIIiiII1 ( )
  i1IIIiiII1 ( )
  if 46 - 46: Oo % ii1IiI1i . i1IIi11111i % i1IIi11111i + i11iIiiIii
  if 72 - 72: ii1IiI1i * Oooo0000 % OOO0O / iiI1i1
  o0oOo0Ooo0O . update ( 99 , "" , "Almost done..." )
  time . sleep ( 3 )
  OOo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
  o0oOo0Ooo0O = xbmcgui . DialogProgress ( )
  o0oOo0Ooo0O . create ( "ITV Updater/Installer" , "Wipe complete!" , 'Now Downloading...' , 'Please wait' )
  if 35 - 35: OOO0O + I11i % OOo00O0Oo0oO % O0OOo + iIi
  oO00ooooO0o = os . path . join ( OOo0 , 'fullbackup.zip' )
  try :
   os . remove ( oO00ooooO0o )
  except :
   pass
  downloader . download ( url , oO00ooooO0o , o0oOo0Ooo0O )
  oo0o = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
  time . sleep ( 2 )
  o0oOo0Ooo0O . update ( 0 , "" , "Installing..." )
  extract . all ( oO00ooooO0o , oo0o , o0oOo0Ooo0O )
  o0oOo0Ooo0O . update ( 0 , "" , "Finishing up..." )
  time . sleep ( 3 )
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  time . sleep ( 2 )
  I1Ii = xbmcgui . Dialog ( )
  I1Ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background." , "" , "" )
  try :
   os . remove ( oO00ooooO0o )
  except :
   pass
  i11III1111iIi ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
  I1Ii = xbmcgui . Dialog ( )
  time . sleep ( 10 )
  if 17 - 17: I11i
  I1Ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Installation is complete. " )
  xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
  if 21 - 21: Ii11111i
  if 29 - 29: O0OOo / o0O / OOO0O * ooO00oOoo
def I111i1i1111 ( name , url , description ) :
 o0oOo0Ooo0O = xbmcgui . DialogProgress ( )
 OO0O0Ooo = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]WARNING!!! [/COLOR]" , 'By pressing YES you will restore ' , 'your Infinity TV to the latest complete build.' , '' , yeslabel = 'YES' , nolabel = 'NO' )
 if OO0O0Ooo == 0 :
  return
 elif OO0O0Ooo == 1 :
  IIII1 = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]Would you like Adult XXX Content? (Must be 18+)[/COLOR]" , 'By pressing YES adult xxx content will be installed to' , 'your device.' , '' , yeslabel = 'YES' , nolabel = 'NO' )
  if IIII1 == 0 :
   url = O0O0OO0O0O0
   I1I1i = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]Would you like to Save your Favorites? [/COLOR]" , '-By pressing YES all your Favorites will be saved. ' , '-If you press NO your Favorites will be wiped' , '-Both options will restore your Infinity TV to the Latest Software Build.' , yeslabel = 'YES' , nolabel = 'NO' )
   if 1 - 1: O0OOo % ooO00oOoo + i1 + I11i - iiI1i1
   if I1I1i == 0 :
    OOO ( )
    time . sleep ( 8 )
    I1Ii = xbmcgui . Dialog ( )
    I1Ii . ok ( "[B]ITV Updater/Installer[/B]" , "Click ok to start the process!" , '' , '' )
    o0oOo0Ooo0O = xbmcgui . DialogProgress ( )
    o0oOo0Ooo0O . create ( "[B]ITV Updater/Installer[/B]" , "Wiping Infinity TV device..." , '' , 'Please wait as it will take a few minutes' )
    time . sleep ( 1 )
    o0oOo0Ooo0O . update ( 10 , "" , 'Preparing files...' , 'Please wait' )
    time . sleep ( 3 )
    try :
     for oOOOo00O00oOo , IIIIii , O0o0 in os . walk ( Oo00OOOOO , topdown = True ) :
      IIIIii [ : ] = [ O0OOO0OOoO0O for O0OOO0OOoO0O in IIIIii if O0OOO0OOoO0O not in OoOo ]
      O0o0 [ : ] = [ O00Oo000ooO0 for O00Oo000ooO0 in O0o0 if O00Oo000ooO0 not in OOO0OOO00oo ]
      for name in O0o0 :
       try :
        os . remove ( os . path . join ( oOOOo00O00oOo , name ) )
        o0oOo0Ooo0O . update ( 30 , "" , 'Removing files...' , 'Please wait' )
        os . rmdir ( os . path . join ( oOOOo00O00oOo , name ) )
       except : pass
       if 22 - 22: IiiIII111iI % OOo00O0Oo0oO
      for name in IIIIii :
       try : os . rmdir ( os . path . join ( oOOOo00O00oOo , name ) ) ; os . rmdir ( oOOOo00O00oOo )
       except : pass
    except : pass
    o0oOo0Ooo0O . update ( 60 , "" , "Removing folders..." )
    i1IIIiiII1 ( )
    i1IIIiiII1 ( )
    i1IIIiiII1 ( )
    o0oOo0Ooo0O . update ( 75 , "" , "Removing folders..." )
    i1IIIiiII1 ( )
    i1IIIiiII1 ( )
    i1IIIiiII1 ( )
    i1IIIiiII1 ( )
    if 57 - 57: ooO00oOoo + i1 . Oooo0000
    if 46 - 46: I11i1i11i1I
    o0oOo0Ooo0O . update ( 99 , "" , "Almost done..." )
    time . sleep ( 3 )
    OOo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
    o0oOo0Ooo0O = xbmcgui . DialogProgress ( )
    o0oOo0Ooo0O . create ( "ITV Updater/Installer" , "Wipe complete!" , 'Now Downloading...' , 'Please wait' )
    if 45 - 45: OOO0O
    oO00ooooO0o = os . path . join ( OOo0 , 'fullbackup.zip' )
    try :
     os . remove ( oO00ooooO0o )
    except :
     pass
    downloader . download ( url , oO00ooooO0o , o0oOo0Ooo0O )
    oo0o = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
    time . sleep ( 2 )
    o0oOo0Ooo0O . update ( 0 , "" , "Installing..." )
    extract . all ( oO00ooooO0o , oo0o , o0oOo0Ooo0O )
    o0oOo0Ooo0O . update ( 0 , "" , "Finishing up..." )
    time . sleep ( 3 )
    xbmc . executebuiltin ( 'UpdateLocalAddons' )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    time . sleep ( 2 )
    I1Ii = xbmcgui . Dialog ( )
    I1Ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background." , "" , "" )
    try :
     os . remove ( oO00ooooO0o )
    except :
     pass
    i11III1111iIi ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
    I1Ii = xbmcgui . Dialog ( )
    time . sleep ( 10 )
    I1Ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Installation is complete. " )
    xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
    if 21 - 21: iIi . oo . ooO00oOoo / Ii11111i / oo
    if 17 - 17: ooO00oOoo / ooO00oOoo / O0OOo
   elif I1I1i == 1 :
    if 1 - 1: I11i . i11iIiiIii % ooO00oOoo
    if 82 - 82: ii1IiI1i + Ii11111i . ii1IiI1i % I11i1i11i1I / Oooo0000 . Oooo0000
    if 14 - 14: Oo . ooO00oOoo . O0OOo + OOooOOo - ooO00oOoo + I11i1i11i1I
    OOO ( )
    if 9 - 9: Oooo0000
    if 59 - 59: IiiIII111iI * o0O . i1
    if 56 - 56: Oooo0000 - i1IIi11111i % IiiIII111iI - Oo
    if 51 - 51: i1 / OOO0O * ii1IiI1i + OOo00O0Oo0oO + Oo
    time . sleep ( 8 )
    I1Ii = xbmcgui . Dialog ( )
    I1Ii . ok ( "[B]ITV Updater/Installer[/B]" , "Click ok to start the process!" , '' , '' )
    o0oOo0Ooo0O = xbmcgui . DialogProgress ( )
    o0oOo0Ooo0O . create ( "[B]ITV Updater/Installer[/B]" , "Wiping Infinity TV device..." , '' , 'Please wait as it will take a few minutes' )
    time . sleep ( 1 )
    o0oOo0Ooo0O . update ( 10 , "" , 'Preparing files...' , 'Please wait' )
    time . sleep ( 3 )
    try :
     for oOOOo00O00oOo , IIIIii , O0o0 in os . walk ( Oo00OOOOO , topdown = True ) :
      IIIIii [ : ] = [ O0OOO0OOoO0O for O0OOO0OOoO0O in IIIIii if O0OOO0OOoO0O not in iI ]
      O0o0 [ : ] = [ O00Oo000ooO0 for O00Oo000ooO0 in O0o0 if O00Oo000ooO0 not in o00O ]
      for name in O0o0 :
       try :
        os . remove ( os . path . join ( oOOOo00O00oOo , name ) )
        o0oOo0Ooo0O . update ( 30 , "" , "Removing folders..." )
        os . rmdir ( os . path . join ( oOOOo00O00oOo , name ) )
       except : pass
       if 98 - 98: ii1IiI1i * OOo00O0Oo0oO * ooO00oOoo + OOO0O % i11iIiiIii % i1
      for name in IIIIii :
       try : os . rmdir ( os . path . join ( oOOOo00O00oOo , name ) ) ; os . rmdir ( oOOOo00O00oOo )
       except : pass
    except : pass
    o0oOo0Ooo0O . update ( 50 , "" , "Removing folders..." )
    i1IIIiiII1 ( )
    i1IIIiiII1 ( )
    i1IIIiiII1 ( )
    o0oOo0Ooo0O . update ( 75 , "" , "Removing folders..." )
    i1IIIiiII1 ( )
    i1IIIiiII1 ( )
    i1IIIiiII1 ( )
    i1IIIiiII1 ( )
    if 27 - 27: i1
    if 79 - 79: Oo - O0OOo + Oo . iIi
    o0oOo0Ooo0O . update ( 99 , "" , "Almost done..." )
    time . sleep ( 3 )
    OOo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
    o0oOo0Ooo0O = xbmcgui . DialogProgress ( )
    o0oOo0Ooo0O . create ( "ITV Updater/Installer" , "Wipe complete!" , 'Now Downloading...' , 'Please wait' )
    if 28 - 28: I11i - i1IIi11111i
    if 54 - 54: i1IIi11111i - i1 % ooO00oOoo
    if 73 - 73: i1 . o0oo0o + IiiIII111iI - O0OOo % O0OOo . O0OOo
    if 17 - 17: Oooo0000 - OOooOOo % Oooo0000 . I11i1i11i1I / i11iIiiIii % i1IIi11111i
    if 28 - 28: O0OOo
    oO00ooooO0o = os . path . join ( OOo0 , 'fullbackup.zip' )
    try :
     os . remove ( oO00ooooO0o )
    except :
     pass
     if 58 - 58: o0oo0o
    url = II1
    downloader . download ( url , oO00ooooO0o , o0oOo0Ooo0O )
    oo0o = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
    time . sleep ( 2 )
    o0oOo0Ooo0O . update ( 0 , "" , "Installing..." )
    extract . all ( oO00ooooO0o , oo0o , o0oOo0Ooo0O )
    o0oOo0Ooo0O . update ( 0 , "" , "Finishing up..." )
    time . sleep ( 3 )
    xbmc . executebuiltin ( 'UpdateLocalAddons' )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    time . sleep ( 2 )
    I1Ii = xbmcgui . Dialog ( )
    I1Ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background." , "" , "" )
    try :
     os . remove ( oO00ooooO0o )
    except :
     pass
    i11III1111iIi ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
    time . sleep ( 10 )
    I1Ii = xbmcgui . Dialog ( )
    I1Ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Installation is complete. " )
    xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
    if 37 - 37: Ii11111i - ii1IiI1i / OOo00O0Oo0oO
    if 73 - 73: i11iIiiIii - I11i1i11i1I
  elif IIII1 == 1 :
   url = iiiii
   I1I1i = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]Would you like to Save your Favorites? [/COLOR]" , '-By pressing YES all your Favorites will be saved. ' , '-If you press NO your Favorites will be wiped' , '-Both options will restore your Infinity TV to the Latest Software Build.' , yeslabel = 'YES' , nolabel = 'NO' )
   if 25 - 25: OOooOOo + I11i1i11i1I * OOo00O0Oo0oO
   if I1I1i == 0 :
    OOO ( )
    time . sleep ( 8 )
    I1Ii = xbmcgui . Dialog ( )
    I1Ii . ok ( "[B]ITV Updater/Installer[/B]" , "Click ok to start the process!" , '' , '' )
    o0oOo0Ooo0O = xbmcgui . DialogProgress ( )
    o0oOo0Ooo0O . create ( "[B]ITV Updater/Installer[/B]" , "Wiping Infinity TV device..." , '' , 'Please wait as it will take a few minutes' )
    time . sleep ( 1 )
    o0oOo0Ooo0O . update ( 10 , "" , 'Preparing files...' , 'Please wait' )
    time . sleep ( 3 )
    try :
     for oOOOo00O00oOo , IIIIii , O0o0 in os . walk ( Oo00OOOOO , topdown = True ) :
      IIIIii [ : ] = [ O0OOO0OOoO0O for O0OOO0OOoO0O in IIIIii if O0OOO0OOoO0O not in OoOo ]
      O0o0 [ : ] = [ O00Oo000ooO0 for O00Oo000ooO0 in O0o0 if O00Oo000ooO0 not in OOO0OOO00oo ]
      for name in O0o0 :
       try :
        os . remove ( os . path . join ( oOOOo00O00oOo , name ) )
        o0oOo0Ooo0O . update ( 30 , "" , 'Removing files...' , 'Please wait' )
        os . rmdir ( os . path . join ( oOOOo00O00oOo , name ) )
       except : pass
       if 92 - 92: IiiIII111iI + O0OOo + i1 / Oo + oo
      for name in IIIIii :
       try : os . rmdir ( os . path . join ( oOOOo00O00oOo , name ) ) ; os . rmdir ( oOOOo00O00oOo )
       except : pass
    except : pass
    o0oOo0Ooo0O . update ( 60 , "" , "Removing folders..." )
    i1IIIiiII1 ( )
    i1IIIiiII1 ( )
    i1IIIiiII1 ( )
    o0oOo0Ooo0O . update ( 75 , "" , "Removing folders..." )
    i1IIIiiII1 ( )
    i1IIIiiII1 ( )
    i1IIIiiII1 ( )
    i1IIIiiII1 ( )
    if 18 - 18: OOO0O * o0oo0o . i1IIi11111i / OOo00O0Oo0oO / i11iIiiIii
    if 21 - 21: iIi / OOo00O0Oo0oO + Oooo0000 + OOooOOo
    o0oOo0Ooo0O . update ( 99 , "" , "Almost done..." )
    time . sleep ( 3 )
    OOo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
    o0oOo0Ooo0O = xbmcgui . DialogProgress ( )
    o0oOo0Ooo0O . create ( "ITV Updater/Installer" , "Wipe complete!" , 'Now Downloading...' , 'Please wait' )
    if 91 - 91: i11iIiiIii / I11i + i1IIi11111i + OOO0O * i11iIiiIii
    oO00ooooO0o = os . path . join ( OOo0 , 'fullbackup.zip' )
    try :
     os . remove ( oO00ooooO0o )
    except :
     pass
    downloader . download ( url , oO00ooooO0o , o0oOo0Ooo0O )
    oo0o = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
    time . sleep ( 2 )
    o0oOo0Ooo0O . update ( 0 , "" , "Installing..." )
    extract . all ( oO00ooooO0o , oo0o , o0oOo0Ooo0O )
    o0oOo0Ooo0O . update ( 0 , "" , "Finishing up..." )
    time . sleep ( 3 )
    xbmc . executebuiltin ( 'UpdateLocalAddons' )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    time . sleep ( 2 )
    I1Ii = xbmcgui . Dialog ( )
    I1Ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background." , "" , "" )
    try :
     os . remove ( oO00ooooO0o )
    except :
     pass
    i11III1111iIi ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
    time . sleep ( 10 )
    I1Ii = xbmcgui . Dialog ( )
    I1Ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Installation is complete. " )
    xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
    if 66 - 66: ii1IiI1i % I11i - i1 + O0OOo * oo . I11i1i11i1I
    if 52 - 52: OOO0O + i1 . i1IIi11111i . OOo00O0Oo0oO . iiI1i1
   elif I1I1i == 1 :
    if 97 - 97: IiiIII111iI / i1IIi11111i
    if 71 - 71: o0O / I11i . OOo00O0Oo0oO % OOooOOo . o0oo0o
    if 41 - 41: I11i * o0O / OOooOOo . ooO00oOoo
    OOO ( )
    if 83 - 83: i1IIi11111i . i1 / Ii11111i / ooO00oOoo - o0O
    if 100 - 100: iiI1i1
    if 46 - 46: o0oo0o / ii1IiI1i % i1IIi11111i . ii1IiI1i * i1IIi11111i
    if 38 - 38: OOo00O0Oo0oO - i1IIi11111i / i1 . oo
    time . sleep ( 8 )
    I1Ii = xbmcgui . Dialog ( )
    I1Ii . ok ( "[B]ITV Updater/Installer[/B]" , "Click ok to start the process!" , '' , '' )
    o0oOo0Ooo0O = xbmcgui . DialogProgress ( )
    o0oOo0Ooo0O . create ( "[B]ITV Updater/Installer[/B]" , "Wiping Infinity TV device..." , '' , 'Please wait as it will take a few minutes' )
    time . sleep ( 1 )
    o0oOo0Ooo0O . update ( 10 , "" , 'Preparing files...' , 'Please wait' )
    time . sleep ( 3 )
    try :
     for oOOOo00O00oOo , IIIIii , O0o0 in os . walk ( Oo00OOOOO , topdown = True ) :
      IIIIii [ : ] = [ O0OOO0OOoO0O for O0OOO0OOoO0O in IIIIii if O0OOO0OOoO0O not in iI ]
      O0o0 [ : ] = [ O00Oo000ooO0 for O00Oo000ooO0 in O0o0 if O00Oo000ooO0 not in o00O ]
      for name in O0o0 :
       try :
        os . remove ( os . path . join ( oOOOo00O00oOo , name ) )
        o0oOo0Ooo0O . update ( 30 , "" , "Removing folders..." )
        os . rmdir ( os . path . join ( oOOOo00O00oOo , name ) )
       except : pass
       if 45 - 45: oo
      for name in IIIIii :
       try : os . rmdir ( os . path . join ( oOOOo00O00oOo , name ) ) ; os . rmdir ( oOOOo00O00oOo )
       except : pass
    except : pass
    o0oOo0Ooo0O . update ( 50 , "" , "Removing folders..." )
    i1IIIiiII1 ( )
    i1IIIiiII1 ( )
    i1IIIiiII1 ( )
    o0oOo0Ooo0O . update ( 75 , "" , "Removing folders..." )
    i1IIIiiII1 ( )
    i1IIIiiII1 ( )
    i1IIIiiII1 ( )
    i1IIIiiII1 ( )
    if 83 - 83: o0oo0o . OOooOOo
    if 58 - 58: i11iIiiIii + OOooOOo % OOooOOo / I11i1i11i1I / i11iIiiIii
    o0oOo0Ooo0O . update ( 99 , "" , "Almost done..." )
    time . sleep ( 3 )
    OOo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
    o0oOo0Ooo0O = xbmcgui . DialogProgress ( )
    o0oOo0Ooo0O . create ( "ITV Updater/Installer" , "Wipe complete!" , 'Now Downloading...' , 'Please wait' )
    if 62 - 62: iiI1i1 / OOo00O0Oo0oO
    if 7 - 7: OOooOOo . I11i1i11i1I
    if 53 - 53: Oooo0000 % Oooo0000 * Oo + o0oo0o
    if 92 - 92: OOooOOo + I11i / Oooo0000 * i1
    if 100 - 100: OOO0O % ii1IiI1i * o0O - i1IIi11111i
    oO00ooooO0o = os . path . join ( OOo0 , 'fullbackup.zip' )
    try :
     os . remove ( oO00ooooO0o )
    except :
     pass
     if 92 - 92: OOO0O
    url = ooo0OO
    downloader . download ( url , oO00ooooO0o , o0oOo0Ooo0O )
    oo0o = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
    time . sleep ( 2 )
    o0oOo0Ooo0O . update ( 0 , "" , "Installing..." )
    extract . all ( oO00ooooO0o , oo0o , o0oOo0Ooo0O )
    o0oOo0Ooo0O . update ( 0 , "" , "Finishing up..." )
    time . sleep ( 3 )
    xbmc . executebuiltin ( 'UpdateLocalAddons' )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    time . sleep ( 2 )
    I1Ii = xbmcgui . Dialog ( )
    I1Ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background." , "" , "" )
    try :
     os . remove ( oO00ooooO0o )
    except :
     pass
    i11III1111iIi ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
    time . sleep ( 10 )
    I1Ii = xbmcgui . Dialog ( )
    I1Ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Installation is complete. " )
    xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
    if 22 - 22: Ii11111i % i1IIi11111i * OOo00O0Oo0oO / ooO00oOoo % i11iIiiIii * O0OOo
    if 95 - 95: OOooOOo - I11i1i11i1I * IiiIII111iI + o0oo0o
def iIi1 ( ) :
 i11iiI1111 = [ ]
 oOoooo000Oo00 = xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.GetFavourites", "params": {"type": null, "properties": ["path", "thumbnail", "window", "windowparameter"]}, "id": 1}' )
 oOoooo000Oo00 = unicode ( oOoooo000Oo00 , 'utf-8' , errors = 'ignore' )
 oOoooo000Oo00 = simplejson . loads ( oOoooo000Oo00 )
 if oOoooo000Oo00 [ "result" ] [ "limits" ] [ "total" ] > 0 :
  for OOoo in oOoooo000Oo00 [ "result" ] [ "favourites" ] :
   OOo0 = o00O00oO00 ( OOoo )
   Ii1i1i1i1I1Ii = { 'Label' : OOoo [ "title" ] ,
 'Thumb' : OOoo [ "thumbnail" ] ,
 'Type' : OOoo [ "type" ] ,
 'Builtin' : OOo0 ,
 'Path' : "plugin://script.extendedinfo/?info=action&&id=" + OOo0 }
   i11iiI1111 . append ( Ii1i1i1i1I1Ii )
 print "ITEMS ################################################"
 print i11iiI1111
 return i11iiI1111
 if 25 - 25: o0O
def o00O00oO00 ( fav ) :
 if fav [ "type" ] == "media" :
  OOo0 = "PlayMedia(%s)" % ( fav [ "path" ] )
 elif fav [ "type" ] == "script" :
  OOo0 = "RunScript(%s)" % ( fav [ "path" ] )
 else :
  OOo0 = "ActivateWindow(%s,%s)" % (
 fav [ "window" ] , fav [ "windowparameter" ] )
 return OOo0
 if 11 - 11: Ii11111i
def OOOOoO0O0oo0 ( favtype ) :
 iiiI1I1iIIIi1 = iIi1 ( )
 Iii = [ ]
 for OOoo in iiiI1I1iIIIi1 :
  if OOoo [ "Type" ] == favtype :
   Iii . append ( OOoo )
 return Iii
 if 19 - 19: O0OOo % o0O / i11iIiiIii / i1IIi11111i - OOooOOo
def iIIii ( ) :
 from t0mm0 . common . net import Net
 import socket
 import time
 if 18 - 18: i1IIi11111i . IiiIII111iI
 iiIi1IIiI = Net ( )
 if 23 - 23: Oooo0000 . ooO00oOoo
 OOo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
 oO00ooooO0o = os . path . join ( OOo0 , 'fullbackup.zip' )
 import zipfile
 if 9 - 9: OOO0O - OOo00O0Oo0oO - i1IIi11111i
 o0O0Oo00 = zipfile . ZipFile ( oO00ooooO0o , "r" )
 for O0Oo0o000oO in o0O0Oo00 . namelist ( ) :
  if 'favourites.xml' in O0Oo0o000oO :
   oO0o00oOOooO0 = o0O0Oo00 . read ( O0Oo0o000oO )
   OOOoO000 = '<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
   if 57 - 57: o0O
   iI1111ii1I = re . compile ( OOOoO000 ) . findall ( oO0o00oOOooO0 )
   print iI1111ii1I
   for oOOOoo , Ii1ii111i1 , i1i1i1I in iI1111ii1I :
    if 83 - 83: iIi + OOooOOo
    Ii1ii111i1 = Ii1ii111i1 . replace ( 'thumb://None' , '/mnt/internal_sd/Android/data/org.xbmc.xbmc/files/.xbmc/addons/script.1channel.themepak/art/themes/Glossy_Black/favourites.png' )
    i1i1i1I = i1i1i1I . replace ( '&quot;' , '' ) . replace ( '&amp;' , '&' )
    json . loads ( xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % ( oOOOoo , i1i1i1I , Ii1ii111i1 ) ) )
    for I111IiiIi1 , o00o in enumerate ( fileinput . input ( OOoO000O0OO , inplace = 1 ) ) :
     sys . stdout . write ( o00o . replace ( 'RunScript(&quot;' , '' ) . replace ( '&quot;)' , '' ) )
  if 46 - 46: o0O % Oo % ii1IiI1i - Ii11111i . OOooOOo - I11i1i11i1I
  if 59 - 59: I11i1i11i1I . ooO00oOoo % o0O
  if 39 - 39: OOo00O0Oo0oO
  if 97 - 97: ooO00oOoo - iiI1i1 / Oooo0000 . i11iIiiIii % iIi * iIi
  if 1 - 1: IiiIII111iI % OOO0O
  if 65 - 65: IiiIII111iI + o0oo0o / ooO00oOoo
  if 83 - 83: Oo . i1IIi11111i - Ii11111i
  if 65 - 65: ii1IiI1i / OOO0O . I11i1i11i1I - o0O
  if 72 - 72: ii1IiI1i / I11i1i11i1I % i1IIi11111i % ooO00oOoo - O0OOo % ooO00oOoo
  if 100 - 100: Ii11111i + i11iIiiIii
  if 71 - 71: O0OOo / Oo / oo % ooO00oOoo
  if 51 - 51: I11i1i11i1I * i1 / o0O . Oooo0000 % ooO00oOoo / IiiIII111iI
  if 9 - 9: IiiIII111iI % IiiIII111iI % o0O
def I1I1i1I ( ) :
 from t0mm0 . common . net import Net
 import socket
 import time
 if 87 - 87: i1 / ii1IiI1i * I11i
 if ( os . path . isfile ( iiI1IiI ) ) :
  iiIi1IIiI = Net ( )
  oOOoo00O00o = ''
  O00Oo000ooO0 = open ( OOoO000O0OO , mode = 'w' )
  O00Oo000ooO0 . write ( oOOoo00O00o )
  O00Oo000ooO0 . close ( )
  if 41 - 41: o0oo0o * O0OOo / o0oo0o % iIi
  oO0o00oOOooO0 = open ( iiI1IiI ) . read ( )
  OOOoO000 = '<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
  iI1111ii1I = re . compile ( OOOoO000 ) . findall ( oO0o00oOOooO0 )
  for Ii , oO0oOOO0Ooo , i1i1I in iI1111ii1I :
   json . loads ( xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % ( Ii , i1i1I , oO0oOOO0Ooo ) ) )
   for I111IiiIi1 , o00o in enumerate ( fileinput . input ( OOoO000O0OO , inplace = 1 ) ) :
    sys . stdout . write ( o00o . replace ( 'RunScript(&quot;' , '' ) . replace ( '&quot;)' , '' ) . replace ( '&amp;' , '&' ) )
    if 25 - 25: ii1IiI1i + OOo00O0Oo0oO + i1IIi11111i / o0O / O0OOo
  OOo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
  o0O0Oo00Oo0o = os . path . join ( OOo0 , 'favourites.xml' )
  downloader . download ( I1IiiI , o0O0Oo00Oo0o )
  time . sleep ( 2 )
  O0Oo0o000oO = o0O0Oo00Oo0o
  if 74 - 74: Ii11111i / i11iIiiIii - o0O * Oo
  OOOoO000 = '<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
  if 5 - 5: ooO00oOoo - ooO00oOoo . Ii11111i + o0oo0o - ooO00oOoo . iIi
  IiIi1i1ii = re . compile ( OOOoO000 ) . findall ( oO0o00oOOooO0 )
  for oOOOoo , Ii1ii111i1 , i1i1i1I in IiIi1i1ii :
   oO0o00oOOooO0 = open ( OOoO000O0OO ) . read ( )
   if oOOOoo in oO0o00oOOooO0 : break
   if 11 - 11: o0O / Oo
   if 21 - 21: i11iIiiIii / I11i + IiiIII111iI * ooO00oOoo . oo
   if 84 - 84: i1 . O0OOo - o0O . OOO0O / o0O
   Ii1ii111i1 = Ii1ii111i1 . replace ( 'thumb://None' , '/mnt/internal_sd/Android/data/org.xbmc.xbmc/files/.xbmc/addons/script.1channel.themepak/art/themes/Glossy_Black/favourites.png' )
   i1i1i1I = i1i1i1I . replace ( '&quot;' , '' )
   if 47 - 47: OOooOOo
   json . loads ( xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % ( oOOOoo , i1i1i1I , Ii1ii111i1 ) ) )
   for I111IiiIi1 , o00o in enumerate ( fileinput . input ( OOoO000O0OO , inplace = 1 ) ) :
    sys . stdout . write ( o00o . replace ( 'RunScript(&quot;' , '' ) . replace ( '&quot;)' , '' ) )
 else :
  pass
  if 4 - 4: IiiIII111iI % O0OOo
  if 10 - 10: I11i1i11i1I . OOooOOo - iiI1i1 + I11i1i11i1I - i1
def o0oO00 ( ) :
 if 65 - 65: ooO00oOoo . oo . iiI1i1 . i1IIi11111i - ooO00oOoo
 import time
 if 19 - 19: i11iIiiIii + i1IIi11111i % OOO0O
 try :
  o0oOo0Ooo0O = xbmcgui . DialogProgress ( )
  o0oOo0Ooo0O . create ( "ITV Updater/Installer" , "Retrieving backup file... " , '' , 'Please wait' )
  oO00ooooO0o = xbmc . translatePath ( os . path . join ( O0O , 'backup.zip' ) )
  oo0o = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
  time . sleep ( 2 )
  o0oOo0Ooo0O . update ( 0 , "" , "Installing..." )
  extract . all ( oO00ooooO0o , oo0o , o0oOo0Ooo0O )
  o0oOo0Ooo0O . update ( 0 , "" , "Finishing up..." )
  time . sleep ( 5 )
  I1Ii = xbmcgui . Dialog ( )
  I1Ii . ok ( "ITV Updater/Installer" , "[COLOR yellow]Installation nearly complete but one important step remains. [/COLOR]" )
  I1Ii = xbmcgui . Dialog ( )
  I1Ii . ok ( "ITV Updater/Installer" , "[COLOR red]URGENT: Please unplug or power off your device immediately and then reboot to finish setup. [/COLOR]" )
  if 14 - 14: iiI1i1 . o0O . O0OOo / Oooo0000 % OOo00O0Oo0oO - OOO0O
 except :
  I1Ii = xbmcgui . Dialog ( )
  I1Ii . ok ( 'ITV Updater/Installer' , 'You need to backup your build first.\nTo backup your box press backup on main menu.' , '' , '' )
  if 67 - 67: O0OOo - ooO00oOoo . I11i
  if 35 - 35: i1IIi11111i + OOO0O - iIi . i1IIi11111i . I11i1i11i1I
  if 87 - 87: o0oo0o
def o0oooOO00 ( name , url , mode , iconimage , fanart , description ) :
 IioO0O = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 oOO = True
 iiiIIiIi = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iiiIIiIi . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 iiiIIiIi . setProperty ( "Fanart_Image" , fanart )
 oOO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IioO0O , listitem = iiiIIiIi , isFolder = False )
 return oOO
 if 68 - 68: i1 + o0oo0o / iIi - ooO00oOoo + ii1IiI1i % Oooo0000
def i1iI1iii11i ( name , url , mode , iconimage , fanart , description ) :
 IioO0O = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 oOO = True
 iiiIIiIi = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iiiIIiIi . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 iiiIIiIi . setProperty ( "Fanart_Image" , fanart )
 oOO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IioO0O , listitem = iiiIIiIi , isFolder = True )
 return oOO
 if 62 - 62: Ii11111i * o0oo0o
 if 79 - 79: iiI1i1 . i1IIi11111i * Oooo0000 - ooO00oOoo + OOO0O
 if 14 - 14: i11iIiiIii - i1IIi11111i * o0oo0o
def OO0oIII111i11IiI ( ) :
 O0000 = [ ]
 ooO00O0O0 = sys . argv [ 2 ]
 if len ( ooO00O0O0 ) >= 2 :
  iII1I1 = sys . argv [ 2 ]
  o0Ooo0o0ooo0 = iII1I1 . replace ( '?' , '' )
  if ( iII1I1 [ len ( iII1I1 ) - 1 ] == '/' ) :
   iII1I1 = iII1I1 [ 0 : len ( iII1I1 ) - 2 ]
  oo0o0000Oo0 = o0Ooo0o0ooo0 . split ( '&' )
  O0000 = { }
  for I111IiiIi1 in range ( len ( oo0o0000Oo0 ) ) :
   o0O00oOoo = { }
   o0O00oOoo = oo0o0000Oo0 [ I111IiiIi1 ] . split ( '=' )
   if ( len ( o0O00oOoo ) ) == 2 :
    O0000 [ o0O00oOoo [ 0 ] ] = o0O00oOoo [ 1 ]
    if 63 - 63: i1IIi11111i * O0OOo * Oooo0000 - iIi - Oooo0000
 return O0000
 if 97 - 97: ooO00oOoo / OOooOOo
 if 18 - 18: iiI1i1 + ii1IiI1i - o0O - IiiIII111iI
iII1I1 = OO0oIII111i11IiI ( )
oooOOOO0oooo = None
oOOOoo = None
oooooOo0 = None
O0o0O0OO00o = None
OOo00O = None
o0Ii1Iii111IiI1 = None
if 98 - 98: oo - OOooOOo % IiiIII111iI + i1 . Oooo0000
if 56 - 56: o0O / iIi + i11iIiiIii + ooO00oOoo
try :
 oooOOOO0oooo = urllib . unquote_plus ( iII1I1 [ "url" ] )
except :
 pass
try :
 oOOOoo = urllib . unquote_plus ( iII1I1 [ "name" ] )
except :
 pass
try :
 O0o0O0OO00o = urllib . unquote_plus ( iII1I1 [ "iconimage" ] )
except :
 pass
try :
 oooooOo0 = int ( iII1I1 [ "mode" ] )
except :
 pass
try :
 OOo00O = urllib . unquote_plus ( iII1I1 [ "fanart" ] )
except :
 pass
try :
 o0Ii1Iii111IiI1 = urllib . unquote_plus ( iII1I1 [ "description" ] )
except :
 pass
 if 54 - 54: Oooo0000 - O0OOo - oo . ii1IiI1i
 if 79 - 79: Oooo0000 . iiI1i1
print str ( ooooooO0oo ) + ': ' + str ( IIIII )
print "Mode: " + str ( oooooOo0 )
print "URL: " + str ( oooOOOO0oooo )
print "Name: " + str ( oOOOoo )
print "IconImage: " + str ( O0o0O0OO00o )
if 40 - 40: Oo + Ii11111i . Oo % OOO0O
if 15 - 15: Oooo0000 * Ii11111i % OOo00O0Oo0oO * ii1IiI1i - i11iIiiIii
def iiIiii1IIIII ( content , viewType ) :
 if 60 - 60: IiiIII111iI * oo % iiI1i1 + iIi
 if content :
  xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , content )
 if oooO0oo0oOOOO . getSetting ( 'auto-view' ) == 'true' :
  xbmc . executebuiltin ( "Container.SetViewMode(%s)" % oooO0oo0oOOOO . getSetting ( viewType ) )
  if 52 - 52: I11i
  if 84 - 84: Oooo0000 / I11i1i11i1I
if oooooOo0 == None or oooOOOO0oooo == None or len ( oooOOOO0oooo ) < 1 :
 Ii11iIi ( )
 if 86 - 86: o0oo0o * o0O - i1 . o0oo0o % ii1IiI1i / ooO00oOoo
elif oooooOo0 == 1 :
 OOOOoOoo0O0O0 ( oOOOoo , oooOOOO0oooo , o0Ii1Iii111IiI1 )
 if 11 - 11: IiiIII111iI * iIi + OOo00O0Oo0oO / OOo00O0Oo0oO
elif oooooOo0 == 2 :
 oO0o0OOOO ( oOOOoo , oooOOOO0oooo , o0Ii1Iii111IiI1 )
 if 37 - 37: i11iIiiIii + I11i
elif oooooOo0 == 3 :
 o00oooO0Oo ( )
 if 23 - 23: i1IIi11111i + O0OOo . o0oo0o * IiiIII111iI + OOo00O0Oo0oO
elif oooooOo0 == 4 :
 o0oO00 ( )
 if 18 - 18: I11i1i11i1I * Oo . I11i1i11i1I / i1
elif oooooOo0 == 5 :
 III1Iiii1I11 ( )
 if 8 - 8: Oo
elif oooooOo0 == 6 :
 I111i1i1111 ( oOOOoo , oooOOOO0oooo , o0Ii1Iii111IiI1 )
 if 4 - 4: OOo00O0Oo0oO + OOo00O0Oo0oO * OOO0O - o0oo0o
elif oooooOo0 == 7 :
 OooooO0oOOOO ( )
 if 78 - 78: Oooo0000 / o0O % o0oo0o
elif oooooOo0 == 8 :
 I1Ii = xbmcgui . Dialog ( )
 I1Ii . ok ( "ITV Updater/Installer" , "[COLOR yellow]Important![/COLOR]" , "" , "Please POWER DOWN your Infinity TV, and then turn it back ON for the changes to take place." )
 try :
  os . remove ( lib )
 except :
  pass
 I1I1i1I ( )
 if 52 - 52: ooO00oOoo - i1IIi11111i * iIi
 if 17 - 17: OOooOOo + ooO00oOoo * O0OOo * o0oo0o
 if 36 - 36: i1 + Ii11111i
 if 5 - 5: Ii11111i * o0oo0o
 if 46 - 46: OOO0O
 try :
  os . remove ( iiI1IiI )
 except :
  pass
  if 33 - 33: i1IIi11111i - o0O * OOooOOo - Ii11111i - ooO00oOoo
elif oooooOo0 == 9 :
 OOOOoOOo0O0 ( oOOOoo , oooOOOO0oooo , o0Ii1Iii111IiI1 )
 if 84 - 84: oo + Ii11111i - o0oo0o * o0oo0o
elif oooooOo0 == 10 :
 I1iI ( oOOOoo , oooOOOO0oooo , o0Ii1Iii111IiI1 )
 if 61 - 61: OOooOOo . iIi . OOooOOo / Ii11111i
elif oooooOo0 == 11 :
 iI11 ( oOOOoo , oooOOOO0oooo , o0Ii1Iii111IiI1 )
 if 72 - 72: I11i
elif oooooOo0 == 12 :
 OooOo ( oOOOoo , oooOOOO0oooo , o0Ii1Iii111IiI1 )
 if 82 - 82: o0oo0o + OOooOOo / i11iIiiIii * OOo00O0Oo0oO . OOooOOo
elif oooooOo0 == 13 :
 I1iiii1I ( oOOOoo , oooOOOO0oooo , o0Ii1Iii111IiI1 )
 if 63 - 63: OOo00O0Oo0oO
elif oooooOo0 == 15 :
 OOIi1iI111II1I1 ( oOOOoo , oooOOOO0oooo , o0Ii1Iii111IiI1 )
 if 6 - 6: OOO0O / OOo00O0Oo0oO
elif oooooOo0 == 16 :
 ooOii ( oOOOoo , oooOOOO0oooo , o0Ii1Iii111IiI1 )
 if 57 - 57: O0OOo
 if 67 - 67: iiI1i1 . OOO0O
 if 87 - 87: iIi % Oooo0000
 if 83 - 83: o0O - O0OOo
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
if 35 - 35: I11i - ii1IiI1i + I11i
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
