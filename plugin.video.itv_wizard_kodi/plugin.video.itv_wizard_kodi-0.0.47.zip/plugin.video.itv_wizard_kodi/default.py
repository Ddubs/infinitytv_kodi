# -*- coding: utf-8 -*-
ooOOOoo = ''
def ttTTtt(i, t1, t2=[]):
 t = ooOOOoo
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0  
 for c in t2:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t

import xbmc , xbmcaddon , xbmcgui , xbmcplugin , os
import shutil
import urllib2 , urllib
import re
import extract
import downloader
import time
import sys , plugintools
import zipfile
import json
if 64 - 64: i11iIiiIii
import sys
import fileinput
import DialogITVTerms
import DialogITVTermsapps
import socket , base64
import kodi
import speedtest
import datetime
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
o0OO00 = ttTTtt(340,[168,104,120,116,88,116,95,112,65,58,96,47,203,47,9,105,2,110,206,102,145,105,43,110,18,105],[26,116,101,121,96,116,253,118,227,46,215,99,25,97,220,47,67,100,42,111,53,119,109,110,115,108,245,111,187,97,85,100,211,115,145,95,237,107,226,111,229,100,2,105,99,47])
oo = ttTTtt(598,[24,104,252,116,235,116,191,112,252,58,243,47,38,47,149,105,214,110,185,102,66,105],[119,110,93,105,195,116,111,121,179,116,104,118,76,46,152,99,215,97,249,47,16,100,243,111,73,119,208,110,113,108,204,111,106,97,248,100,113,115,53,95,234,107,2,111,22,100,74,105,217,47,176,117,53,112,255,100,111,97,146,116,23,101,112,46,15,122,84,105,145,112])
i1iII1IiiIiI1 = ttTTtt(0,[104,107,116,132,116,119,112,247,58,163,47,184,47,62,105,220,110,231,102],[206,105,142,110,206,105,54,116,180,121,4,116,167,118,112,46,12,99,105,97,49,47,202,100,226,111,214,119,111,110,92,108,157,111,224,97,31,100,210,115,44,95,43,107,67,111,218,100,216,105,124,47,5,102,231,117,219,108,81,108,95,95,124,114,25,101,191,115,119,116,176,111,103,114,212,101,165,46,50,122,10,105,234,112])
iIiiiI1IiI1I1 = ttTTtt(0,[104,184,116],[175,116,218,112,249,58,9,47,177,47,49,105,41,110,219,102,181,105,82,110,58,105,38,116,22,121,167,116,63,118,145,46,124,99,131,97,209,47,240,100,78,111,42,119,254,110,187,108,97,111,99,97,6,100,26,115,25,95,89,107,81,111,102,100,180,105,91,47,120,97,1,100,94,117,8,108,120,116,137,95,7,102,72,117,55,108,28,108,247,95,183,114,93,101,38,115,39,116,204,111,157,114,168,101,144,46,8,122,165,105,23,112])
o0OoOoOO00 = ttTTtt(349,[8,104,140,116,35,116],[65,112,160,58,158,47,131,47,72,105,5,110,32,102,34,105,5,110,89,105,10,116,210,121,34,116,149,118,166,46,167,99,16,97,54,47,238,100,18,111,149,119,7,110,224,108,117,111,251,97,236,100,65,115,118,95,184,107,110,111,236,100,177,105,232,47,119,97,166,100,127,117,32,108,143,116,69,95,19,102,173,117,152,108,239,108,104,95,9,114,54,101,56,115,161,116,116,111,248,114,228,101,240,95,28,102,205,97,169,118,184,46,191,122,100,105,154,112])
I11i = ttTTtt(717,[217,104,35,116],[223,116,84,112,177,58,59,47,60,47,201,105,138,110,250,102,247,105,117,110,115,105,155,116,143,121,58,116,144,118,218,46,170,99,220,97,221,47,84,100,236,111,181,119,94,110,213,108,84,111,23,97,44,100,229,115,10,95,218,107,226,111,66,100,29,105,75,47,107,102,232,117,33,108,202,108,169,95,70,114,236,101,223,115,147,116,35,111,77,114,139,101,144,95,109,102,156,97,29,118,38,46,186,122,25,105,21,112])
O0O = ttTTtt(0,[104,28,116,203,116,107,112,47,58,190,47,56,47,61,105,213,110,2,102,231,105,86,110,22,105,34,116,178,121,50,116,178,118,28,46,172,99,62,97,129,47,156,100,243,111,187,119],[254,110,102,108,228,111,251,97,107,100,157,115,234,95,113,107,247,111,9,100,5,105,7,47,200,98,74,117,85,105,2,108,131,100,79,95,201,118,229,101,128,114,161,115,43,105,240,111,31,110,47,115,247,46,200,116,24,120,18,116])
Oo = ttTTtt(722,[2,104,130,116],[86,116,52,112,135,58,166,47,201,47,46,105,149,110,0,102,114,105,134,110,99,105,30,116,14,121,64,116,74,118,234,46,234,99,252,97,233,47,184,100,18,111,27,119,211,110,121,108,32,111,13,97,16,100,18,115,6,95,22,107,71,111,22,100,143,105,216,47,213,102,155,97,11,118,128,111,177,117,99,114,37,105,54,116,159,101,84,115,126,46,230,120,108,109,66,108])
I1ii11iIi11i = ttTTtt(256,[251,104,34,116,16,116,126,112,78,58,178,47,64,47,25,105],[64,110,249,102,52,105,186,110,57,105,158,116,72,121,187,116,189,118,200,46,79,99,191,97,231,47,150,100,218,111,54,119,53,110,174,108,137,111,187,97,11,100,210,115,25,95,220,107,50,111,225,100,135,105,218,47,83,109,70,101,239,100,241,105,197,97,15,46,61,122,100,105,20,112])
I1IiI = ttTTtt(53,[72,104,152,116,141,116,67,112,141,58,140,47,100,47,54,105,134,110,249,102],[231,105,142,110,134,105,51,116,80,121,143,116,60,118,41,46,94,99,31,97,176,47,41,100,78,111,241,119,69,110,106,108,150,111,18,97,132,100,86,115,77,95,7,107,249,111,50,100,80,105,198,47,98,115,191,107,239,105,40,110,6,46,46,105,163,110,237,102,9,105,121,110,227,105,183,116,66,121,204,116,107,118,153,95,87,100,210,101,133,109,37,111,179,46,126,122,146,105,100,112])
o0OOO = ttTTtt(660,[38,104],[85,116,34,116,250,112,37,58,94,47,251,47,119,105,8,110,0,102,114,105,179,110,118,105,253,116,74,121,132,116,35,118,141,46,176,99,45,97,253,47,214,100,154,111,62,119,238,110,82,108,70,111,39,97,180,100,229,115,59,95,175,107,200,111,53,100,64,105,126,47,14,115,103,107,25,105,198,110,221,46,237,105,49,110,184,102,103,105,163,110,184,105,214,116,229,121,86,116,205,118,74,46,37,122,222,105,222,112])
iIiiiI = 'plugin.video.itv_wizard_kodi'
Iii1ii1II11i = ttTTtt(0,[104,238,116,151,116,152,112,128,58],[186,47,109,47,53,105,147,110,248,102,75,105,94,110,225,105,67,116,129,121,212,116,194,118,111,46,253,99,212,97,53,47,122,100,22,111,238,119,39,110,209,108,231,111,29,97,85,100,115,115,111,95,209,107,67,111,237,100,127,105,117,47,254,109,220,97,236,99,59,95,90,97,133,100,143,100,33,114,220,101,182,115,115,115,185,46,227,120,59,109,61,108])
if 10 - 10: I1iII1iiII + I1Ii111 / OOo
i1i1II = ttTTtt(90,[74,104,222,116,151,116,118,112],[122,58,87,47,76,47,241,105,131,110,106,102,36,105,72,110,72,105,236,116,26,121,107,116,164,118,5,46,170,99,208,97,19,47,152,100,76,111,183,119,233,110,119,108,159,111,80,97,229,100,152,115,192,95,198,107,188,111,221,100,94,105,144,47,168,100,159,101,25,102,161,97,56,117,200,108,189,116,100,46,188,98,213,117,2,105,117,108,79,100,207,46,30,122,31,105,155,112])
if 96 - 96: o0OO0 - Oo0ooO0oo0oO . I1i1iI1i - o00ooo0 / o00 * Oo0oO0ooo
o0oOoO00o = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
i1 = xbmcaddon . Addon ( id = iIiiiI )
if 64 - 64: ooO0Oooo00 % Ooo0
oo00000o0 = ttTTtt(0,[104,41,116,243,116,217,112],[111,58,60,47,105,47,82,105,77,110,245,102,138,105,138,110,1,105,48,116,56,121,198,116,51,118,81,46,51,99,34,97,47,47,117,100,162,111,197,119,34,110,72,108,19,111,13,97,50,100,52,115,80,95,236,107,81,111,111,100,79,105,222,47,209,115,41,112,103,111,193,114,242,116,234,115,221,100,215,101,16,118,211,105,197,108,122,95,15,102,173,105,111,120,176,46,190,122,127,105,148,112])
I11i1i11i1I = ttTTtt(0,[104,189,116,131,116,54,112,226,58,112,47,220,47,240,105,29,110],[71,102,29,105,227,110,89,105,191,116,96,121,135,116,43,118,133,46,15,99,39,97,250,47,86,100,84,111,97,119,204,110,202,108,189,111,217,97,232,100,184,115,170,95,158,107,55,111,129,100,227,105,249,47,172,97,216,112,148,107,29,47,31,97,123,112,197,107,121,46,90,116,93,120,122,116])
if 45 - 45: I1 + Ooo0
if 17 - 17: I1i1iI1i
if 64 - 64: Ooo0 % i1IIi % OoooooooOO
def i1iIIi1 ( url ) :
 ii11iIi1I = urllib2 . Request ( url )
 ii11iIi1I . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 iI111I11I1I1 = urllib2 . urlopen ( ii11iIi1I )
 OOooO0OOoo = iI111I11I1I1 . read ( )
 iI111I11I1I1 . close ( )
 return OOooO0OOoo
 if 29 - 29: I1i1iI1i / iIii1I11I1II1
 if 24 - 24: O0 % I1i1iI1i + i1IIi + I1 + o00ooo0
 if 70 - 70: OOo % OOo . Oo0o0ooO0oOOO % o0OO0 * I1i1iI1i % o00
iiI1IiI = kodi . addon_id
i1 = xbmcaddon . Addon ( id = iiI1IiI )
if 13 - 13: OOo . i11iIiiIii - iIii1I11I1II1 - Oo0ooO0oo0oO
ii1I = "Speed Test"
OooO0 = "Infinity TV"
if 35 - 35: Oo0oO0ooo % I1 % i11iIiiIii / OoooooooOO
Ii11iI1i = 0.0
Ooo = 0.0
if 68 - 68: ooO0Oooo00 + Oo0oO0ooo . iIii1I11I1II1 - Oo0o0ooO0oOOO % iIii1I11I1II1 - OOoOoo00oo
if 79 - 79: OOo + I1Ii111 - i11iI
def oO00O00o0OOO0 ( url , dest , dp = None ) :
 if not dp :
  dp = xbmcgui . DialogProgress ( )
  dp . create ( OooO0 , "Connecting to server" , '[COLOR orange][I]Testing your network speed...[/I][/COLOR]' , 'Please wait...' )
 dp . update ( 0 )
 Ii1iIIIi1ii = time . time ( )
 try :
  urllib . urlretrieve ( url , dest , lambda o0oo0o0O00OO , o0oO , I1i1iii : i1iiI11I ( o0oo0o0O00OO , o0oO , I1i1iii , dp , Ii1iIIIi1ii ) )
 except :
  pass
 return ( time . time ( ) - Ii1iIIIi1ii )
 if 29 - 29: OoooooooOO
def i1iiI11I ( numblocks , blocksize , filesize , dp , start_time ) :
 global Ii11iI1i
 global Ooo
 if 23 - 23: I1i1iI1i . I1iII1iiII
 try :
  Oo0O0OOOoo = min ( numblocks * blocksize * 100 / filesize , 100 )
  Ooo = float ( numblocks ) * blocksize
  oOoOooOo0o0 = Ooo / ( 1024 * 1024 )
  OOOO = Ooo / ( time . time ( ) - start_time )
  if OOOO > 0 :
   OOO00 = ( filesize - numblocks * blocksize ) / OOOO
   if OOOO > Ii11iI1i : Ii11iI1i = OOOO
  else :
   OOO00 = 0
  iiiiiIIii = OOOO * 8 / 1024
  O000OO0 = iiiiiIIii / 1024
  I11iii1Ii = float ( filesize ) / ( 1024 * 1024 )
  I1IIiiIiii = '%.02f MB of %.02f MB' % ( oOoOooOo0o0 , I11iii1Ii )
  dp . update ( Oo0O0OOOoo )
 except :
  Ooo = float ( filesize )
  Oo0O0OOOoo = 100
  dp . update ( Oo0O0OOOoo )
 if dp . iscanceled ( ) :
  dp . close ( )
  raise Exception ( "Cancelled" )
  if 97 - 97: OOoOoo00oo - Oo0oO0ooo * i11iIiiIii / Oo0ooO0oo0oO % I1 - OoooooooOO
def OoOo00o ( mypath , dirname ) :
 import xbmcvfs
 if 70 - 70: i11iI * o00ooo0
 if 46 - 46: OOoOoo00oo / o0OO0
 if not xbmcvfs . exists ( mypath ) :
  try :
   xbmcvfs . mkdirs ( mypath )
  except :
   xbmcvfs . mkdir ( mypath )
   if 52 - 52: I1i1iI1i - OoooooooOO + Ooo0 + Ooo0 - I1i1iI1i / I1
 I1I = os . path . join ( mypath , dirname )
 if 24 - 24: o00ooo0
 if not xbmcvfs . exists ( I1I ) :
  try :
   xbmcvfs . mkdirs ( I1I )
  except :
   xbmcvfs . mkdir ( I1I )
   if 56 - 56: OOoOoo00oo
 return I1I
 if 92 - 92: i11iI . ooO0Oooo00 + I1i1iI1i
def IiII1I11i1I1I ( ) :
 oO0Oo = datetime . datetime . now ( )
 oOOoo0Oo = time . mktime ( oO0Oo . timetuple ( ) ) + ( oO0Oo . microsecond / 1000000. )
 o00OO00OoO = str ( '%f' % oOOoo0Oo )
 o00OO00OoO = o00OO00OoO . replace ( '.' , '' )
 o00OO00OoO = o00OO00OoO [ : - 3 ]
 return o00OO00OoO
 if 60 - 60: o0OO0 * Oo0ooO0oo0oO - o0OO0 % OoooooooOO - OOoOoo00oo + I1Ii111
def O00Oo000ooO0 ( url ) :
 OoO0O00 = xbmc . translatePath ( i1 . getAddonInfo ( 'profile' ) )
 IIiII = OoOo00o ( OoO0O00 , 'speedtestfiles' )
 o0 = os . path . join ( IIiII , IiII1I11i1I1I ( ) + '.speedtest' )
 ooOooo000oOO = oO00O00o0OOO0 ( url , o0 )
 os . remove ( o0 )
 Oo0oOOo = ( ( Ooo / ooOooo000oOO ) * 8 / ( 1024 * 1024 ) )
 Oo0OoO00oOO0o = ( Ii11iI1i * 8 / ( 1024 * 1024 ) )
 if Oo0oOOo < 2 :
  OOO00O = 'Very low quality streams might work.'
  OOoOO0oo0ooO = 'Expect buffering, do not try HD.'
  O0o0O00Oo0o0 = '[COLOR ghostwhite][B] Verdict: [I]Very Poor[/I]   | Score: [COLOR slategray][I]1/10[/I][/B][/COLOR]'
 elif Oo0oOOo < 2.5 :
  OOO00O = 'You should be ok for SD content only.'
  OOoOO0oo0ooO = 'SD/DVD quality should be ok.'
  O0o0O00Oo0o0 = '[COLOR ghostwhite][B][I]Poor[/I]   | Score: [COLOR slategray][I]2/10[/I][/B][/COLOR]'
 elif Oo0oOOo < 5 :
  OOO00O = 'Some HD streams might struggle, SD should be fine.'
  OOoOO0oo0ooO = '720p will be fine but some 1080p may struggle.'
  O0o0O00Oo0o0 = '[COLOR ghostwhite][B][I]OK[/I]   | Score: [COLOR slategray][I]4/10[/I][/B][/COLOR]'
 elif Oo0oOOo < 9 :
  OOO00O = 'All streams including HD should stream fine.'
  OOoOO0oo0ooO = 'Movies (720p & 1080p) will stream fine but 3D and 4K will not.'
  O0o0O00Oo0o0 = '[COLOR ghostwhite][B][I]Good[/I]   | Score: [COLOR slategray][I]6/10[/I][/B][/COLOR]'
 elif Oo0oOOo < 15 :
  OOO00O = 'All streams including HD should stream fine'
  OOoOO0oo0ooO = 'Movies (720p & 1080p and 3D) will stream fine but 4K may not.'
  O0o0O00Oo0o0 = '[COLOR ghostwhite][B][I]Very good[/I]   | Score: [COLOR slategray][I]8/10[/I][/B][/COLOR]'
 else :
  OOO00O = 'All streams including HD should stream fine'
  OOoOO0oo0ooO = 'You can play all movies (720p, 1080p, 3D and 4K)'
  O0o0O00Oo0o0 = '[COLOR ghostwhite][B][I]Excellent[/I]   | Score: [COLOR slategray][I]10/10[/I][/B][/COLOR]'
 print "Average Speed: " + str ( Oo0oOOo )
 print "Max. Speed: " + str ( Oo0OoO00oOO0o )
 O00O0oOO00O00 = xbmcgui . Dialog ( )
 i1Oo00 = O00O0oOO00O00 . ok (
 '[COLOR lightsteelblue][B]Your Result:[/COLOR][/B] ' + O0o0O00Oo0o0 ,
 '[COLOR lightsteelblue][B]Live Streams:[/COLOR][/B] ' + OOO00O ,
 '[COLOR lightsteelblue][B]Movie Streams:[/COLOR][/B] ' + OOoOO0oo0ooO ,
 '[COLOR lightsteelblue][B]Duration:[/COLOR][/B] %.02f secs ' % ooOooo000oOO + '[COLOR lightsteelblue][B]Average Speed:[/B][/COLOR] %.02f Mb/s ' % Oo0oOOo + '[COLOR lightsteelblue][B]Max Speed:[/B][/COLOR] %.02f Mb/s ' % Oo0OoO00oOO0o ,
 )
 if 31 - 31: I1 . Oo0ooO0oo0oO / O0
 if 89 - 89: Oo0ooO0oo0oO
 if 68 - 68: o0OO0 * OoooooooOO % O0 + o0OO0 + OOoOoo00oo
 if 4 - 4: OOoOoo00oo + O0 * Oo0oO0ooo
 if 55 - 55: OOo + iIii1I11I1II1 / Oo0ooO0oo0oO * o00 - i11iIiiIii - Ooo0
zip = i1 . getSetting ( 'zip' )
O00O0oOO00O00 = xbmcgui . Dialog ( )
ii1ii1ii = xbmcgui . DialogProgress ( )
oooooOoo0ooo = xbmc . translatePath ( os . path . join ( 'special://home/userdata' , '' ) )
I1I1IiI1 = xbmc . translatePath ( os . path . join ( oooooOoo0ooo , 'addon_data' ) )
III1iII1I1ii = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
oOOo0 = xbmc . translatePath ( os . path . join ( oooooOoo0ooo , 'guisettings.xml' ) )
oo00O00oO = xbmc . translatePath ( os . path . join ( oooooOoo0ooo , 'favourites.xml' ) )
iIiIIIi = xbmc . translatePath ( os . path . join ( oooooOoo0ooo , 'favourites2.xml' ) )
ooo00OOOooO = xbmc . translatePath ( os . path . join ( oooooOoo0ooo , 'sources.xml' ) )
O00OOOoOoo0O = xbmc . translatePath ( os . path . join ( oooooOoo0ooo , 'advancedsettings.xml' ) )
O000OOo00oo = xbmc . translatePath ( os . path . join ( oooooOoo0ooo , 'RssFeeds.xml' ) )
oo0OOo = xbmc . translatePath ( os . path . join ( oooooOoo0ooo , 'keymaps' , 'keyboard.xml' ) )
ooOOO00Ooo = xbmc . translatePath ( os . path . join ( zip ) )
IiIIIi1iIi = xbmc . getSkinDir ( )
ooOOoooooo = xbmc . translatePath ( 'special://home/' )
II1I = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , iIiiiI ) )
O0i1II1Iiii1I11 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , iIiiiI , 'resources' , 'skins' ) )
IIII = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , iIiiiI , 'flag.xml' ) )
iiIiI = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , 'skin.infinitytv_demo' , 'addon.xml' ) )
o00oooO0Oo = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , 'script.startec.pairwith' , 'addon.xml' ) )
o0O0OOO0Ooo = xbmc . translatePath ( os . path . join ( 'special://home' , 'media' , 'launch.jpg' ) )
iiIiII1 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , iIiiiI , 'disclaimer.xml' ) )
OOO00O0O = xbmc . translatePath ( os . path . join ( oooooOoo0ooo , 'addon_data' , 'skin.infinitytv-XK' , 'settings.xml' ) )
iii = "0.0.11"
oOooOOOoOo = "itv_wizard"
i1Iii1i1I = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , iIiiiI , 'icon.png' ) )
if 91 - 91: o00ooo0 + I1Ii111 . Oo0oO0ooo * o00ooo0 + I1Ii111 * OOo
if 80 - 80: i11iI % Oo0oO0ooo % o00 - OOo + OOo
if 19 - 19: Oo0ooO0oo0oO * i1IIi
if 14 - 14: i11iI
if 11 - 11: Oo0o0ooO0oOOO * I1Ii111 . iIii1I11I1II1 % OoooooooOO + i11iI
if 78 - 78: o0OO0 . Oo0oO0ooo + o0OO0 / ooO0Oooo00 / o0OO0
def oO0O00OoOO0 ( ) :
 kodi . log ( 'CLEAR CACHE ACTIVATED' )
 OoO = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
 O00 = xbmcgui . Dialog ( ) . yesno ( "Clear Cache" , "Press OK if you wish to clear" , "your Infinity TV cache" , "" , "Cancel" , "OK" )
 if O00 :
  if os . path . exists ( OoO ) == True :
   for I1iI1 , iiiIi1 , i1I1ii11i1Iii in os . walk ( OoO ) :
    I1IiiiiI = 0
    I1IiiiiI += len ( i1I1ii11i1Iii )
    if I1IiiiiI > 0 :
     if 80 - 80: I1 . i11iIiiIii - I1i1iI1i
     if 25 - 25: o0OO0
     for oOo0oO in i1I1ii11i1Iii :
      try :
       os . unlink ( os . path . join ( I1iI1 , oOo0oO ) )
      except :
       pass
     for OOOO0oo0 in iiiIi1 :
      try :
       shutil . rmtree ( os . path . join ( I1iI1 , OOOO0oo0 ) )
      except :
       pass
       if 35 - 35: Ooo0 - I1Ii111 % I1i1iI1i . OoooooooOO % Ooo0
       if 47 - 47: i11iI - Ooo0 . I1iII1iiII + OoooooooOO . i11iIiiIii
  O00O0oOO00O00 = xbmcgui . Dialog ( )
  O00O0oOO00O00 . ok ( '' , "Cache Cleared Successfully!" )
  xbmc . executebuiltin ( "Container.Refresh()" )
  if 94 - 94: I1i1iI1i * Ooo0 / OOo / Ooo0
  if 87 - 87: OOo . Oo0o0ooO0oOOO
  if 75 - 75: OOoOoo00oo + Oo0ooO0oo0oO + I1i1iI1i * ooO0Oooo00 % o00 . i11iI
  if 55 - 55: Oo0oO0ooo . I1Ii111
  if 61 - 61: OOo % Oo0o0ooO0oOOO . OOo
  if 100 - 100: I1 * O0
def o00oO0oo0OO ( ) :
 O0O0OOOOoo = xbmc . translatePath ( os . path . join ( 'special://home/addons/packages' , '' ) )
 O00 = xbmcgui . Dialog ( ) . yesno ( "Purge Packages" , "This will remove old zip files from your device that are no longer needed. " , "" , "Press OK to begin" , "Cancel" , "OK" )
 if O00 :
  try :
   for I1iI1 , iiiIi1 , i1I1ii11i1Iii in os . walk ( O0O0OOOOoo , topdown = False ) :
    for oOooO0 in i1I1ii11i1Iii :
     os . remove ( os . path . join ( I1iI1 , oOooO0 ) )
    O00O0oOO00O00 = xbmcgui . Dialog ( )
    O00O0oOO00O00 . ok ( "Purge Packages" , "Old Zip Files Successfully Removed!" )
    xbmc . executebuiltin ( "Container.Refresh()" )
  except :
   O00O0oOO00O00 = xbmcgui . Dialog ( )
   O00O0oOO00O00 . ok ( OooO0 , "Error Deleting old zip files please visit Infinitytv.ca" )
   if 29 - 29: iIii1I11I1II1 + Oo0ooO0oo0oO * o0OO0 * Oo0oO0ooo . I1Ii111 * I1Ii111
   if 7 - 7: Oo0o0ooO0oOOO * I1 % Ooo0 - I1i1iI1i
i1i = iIiiiI ; OooO0 = "Infinity TV: Network Speed Test"
oOOoo00O00o = [ iIiiiI , 'skin.infinitytv-X-demo' ]
O0O00Oo = [ iIiiiI , 'addon_data' , 'skin.infinitytv-X-demo' ]
oooooo0O000o = [ "favourites.xml" , "favourites2.xml" , "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "app.jpg" , "launch.jpg" , "Splash.png" ]
OoOooO0O0O0ooOOO = [ "favourites.xml" , "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "app.jpg" , "launch.jpg" , "Splash.png" ]
if 77 - 77: Oo0ooO0oo0oO - I1iII1iiII - OOoOoo00oo
def IiiiIIiIi1 ( default = "" , heading = "" , hidden = False ) :
 OoOOoOooooOOo = xbmc . Keyboard ( default , heading , hidden )
 if 87 - 87: I1Ii111
 OoOOoOooooOOo . doModal ( )
 if ( OoOOoOooooOOo . isConfirmed ( ) ) :
  return unicode ( OoOOoOooooOOo . getText ( ) , "utf-8" )
 return default
 if 58 - 58: Oo0ooO0oo0oO % I1i1iI1i
def i1OOoO ( sourcefile , destfile , message_header , message1 , message2 , message3 , exclude_dirs , exclude_files ) :
 OO0O000 = zipfile . ZipFile ( destfile , 'w' , zipfile . ZIP_DEFLATED )
 iiIiI1i1 = len ( sourcefile )
 oO0O00oOOoooO = [ ]
 IiIi11iI = [ ]
 ii1ii1ii . create ( message_header , message1 , message2 , message3 )
 for o0OO00 , iiiIi1 , i1I1ii11i1Iii in os . walk ( sourcefile ) :
  for file in i1I1ii11i1Iii :
   IiIi11iI . append ( file )
 Oo0O00O000 = len ( IiIi11iI )
 for o0OO00 , iiiIi1 , i1I1ii11i1Iii in os . walk ( sourcefile ) :
  iiiIi1 [ : ] = [ OOOO0oo0 for OOOO0oo0 in iiiIi1 if OOOO0oo0 not in exclude_dirs ]
  i1I1ii11i1Iii [ : ] = [ oOo0oO for oOo0oO in i1I1ii11i1Iii if oOo0oO not in exclude_files ]
  for file in i1I1ii11i1Iii :
   oO0O00oOOoooO . append ( file )
   i11I1IiII1i1i = len ( oO0O00oOOoooO ) / float ( Oo0O00O000 ) * 100
   ii1ii1ii . update ( int ( i11I1IiII1i1i ) , "Backing up..." , '[COLOR yellow]%s[/COLOR]' % file , 'Please wait' )
   ooI1111i = os . path . join ( o0OO00 , file )
   if not 'temp' in iiiIi1 :
    if not iIiiiI in iiiIi1 :
     import time
     iIIii = '01/01/1980'
     o00O0O = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( ooI1111i ) ) )
     if o00O0O > iIIii :
      OO0O000 . write ( ooI1111i , ooI1111i [ iiIiI1i1 : ] )
 OO0O000 . close ( )
 ii1ii1ii . close ( )
 if 20 - 20: i1IIi - OOoOoo00oo
def i1iI ( name , url , description ) :
 Oo0O0 = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]VERY IMPORTANT: [/COLOR]" , 'This will completely wipe your infinity tv box settings.' , 'Would you like to create a backup before proceeding?' , '' , yeslabel = 'Yes' , nolabel = 'No' )
 if Oo0O0 == 1 :
  Ooo0OOoOoO0 = urllib . quote_plus ( "backup" )
  oOo0OOoO0 = xbmc . translatePath ( os . path . join ( II1I , Ooo0OOoOoO0 + '.zip' ) )
  II = [ iIiiiI , 'Thumbnails' ]
  OoOooO0O0O0ooOOO = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Textures13.db' ]
  o0Oo0oO0oOO00 = "Creating backup... "
  oo00OO0000oO = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
  I1II1 = ""
  oooO = "Please wait"
  i1OOoO ( ooOOoooooo , oOo0OOoO0 , o0Oo0oO0oOO00 , oo00OO0000oO , I1II1 , oooO , II , OoOooO0O0O0ooOOO )
 if 26 - 26: Ooo0 % o00ooo0
 if 76 - 76: Oo0o0ooO0oOOO * i11iI
 if 52 - 52: Oo0oO0ooo
 if 19 - 19: I1Ii111
 if 25 - 25: Ooo0 / OOoOoo00oo
 if 31 - 31: Oo0oO0ooo . O0 % I1Ii111 . I1i1iI1i + Oo0o0ooO0oOOO
 o0o = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]FINAL WARNING!!! [/COLOR]" , 'Are you absolutely certain about wiping your infinity tv box settings?' , '' , 'All addons and userdata will be gone!' , yeslabel = 'Yes' , nolabel = 'No' )
 if o0o == 0 :
  return
 elif o0o == 1 :
  I11iii1Ii = 0
  ii1ii1ii . create ( "[B]ITV Updater/Installer[/B]" , "Wiping infinity tv Device..." , '' , 'Please wait' )
  try :
   for I1iI1 , iiiIi1 , i1I1ii11i1Iii in os . walk ( ooOOoooooo , topdown = True ) :
    iiiIi1 [ : ] = [ OOOO0oo0 for OOOO0oo0 in iiiIi1 if OOOO0oo0 not in oOOoo00O00o ]
    for name in i1I1ii11i1Iii :
     Oo0O0OOOoo = min ( 100 * I11iii1Ii / name , 100 )
     try :
      os . remove ( os . path . join ( I1iI1 , name ) )
      os . rmdir ( os . path . join ( I1iI1 , name ) )
      ii1ii1ii . update ( Oo0O0OOOoo )
     except : pass
     if 62 - 62: OoooooooOO . ooO0Oooo00
    for name in iiiIi1 :
     ii1ii1ii . update ( Oo0O0OOOoo )
     try : os . rmdir ( os . path . join ( I1iI1 , name ) ) ; os . rmdir ( I1iI1 )
     except : pass
  except : pass
 oOOOoo00 ( )
 oOOOoo00 ( )
 oOOOoo00 ( )
 oOOOoo00 ( )
 oOOOoo00 ( )
 oOOOoo00 ( )
 oOOOoo00 ( )
 O00O0oOO00O00 . ok ( '[B]ITV Updater/Installer[/B]' , 'Wipe complete! Please restart infinity tv box for changes to take effect.' , '' , '' )
 return iiIiIIIiiI ( name , url , description )
 if 12 - 12: O0 - I1i1iI1i
def oOOOoo00 ( ) :
 print "########### Start Removing Empty Folders #########"
 oOoO00O0 = 0
 OO = 0
 for Ii1iI111II1I1 , oOOOOoOO0o , i1I1ii11i1Iii in os . walk ( ooOOoooooo ) :
  if len ( oOOOOoOO0o ) == 0 and len ( i1I1ii11i1Iii ) == 0 :
   oOoO00O0 += 1
   os . rmdir ( Ii1iI111II1I1 )
   print "successfully removed: " + Ii1iI111II1I1
  elif len ( oOOOOoOO0o ) > 0 and len ( i1I1ii11i1Iii ) > 0 :
   OO += 1
   if 1 - 1: I1iII1iiII
def O0oOo00o ( ) :
 Oo0O0 = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]ITV Updater/Installer: [/COLOR]" , 'Would you like to create a backup?.' , 'Backup file will be stored in the plugin.video.itv_wizard folder.' , '' , yeslabel = 'Yes' , nolabel = 'No' )
 if Oo0O0 == 1 :
  Ooo0OOoOoO0 = urllib . quote_plus ( "backup" )
  oOo0OOoO0 = xbmc . translatePath ( os . path . join ( II1I , Ooo0OOoOoO0 + '.zip' ) )
  II = [ iIiiiI , 'Thumbnails' ]
  OoOooO0O0O0ooOOO = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Textures13.db' ]
  o0Oo0oO0oOO00 = "Creating backup... "
  oo00OO0000oO = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
  I1II1 = ""
  oooO = "Please wait"
  i1OOoO ( ooOOoooooo , oOo0OOoO0 , o0Oo0oO0oOO00 , oo00OO0000oO , I1II1 , oooO , II , OoOooO0O0O0ooOOO )
  O00O0oOO00O00 . ok ( '[B]ITV Updater/Installer[/B]' , 'Backup complete!' , '' , '' )
 else :
  return
  if 81 - 81: Oo0o0ooO0oOOO % i1IIi . iIii1I11I1II1
def Ii1Iii1iIi ( ) :
 DialogITVTerms . show ( )
 if 82 - 82: o00ooo0 / I1Ii111 % iIii1I11I1II1 / i1IIi - I1Ii111
 if 7 - 7: I1 * o0OO0 - OOoOoo00oo + Oo0oO0ooo * I1Ii111 % o0OO0
 if 15 - 15: Oo0ooO0oo0oO % I1Ii111 * ooO0Oooo00
 if 81 - 81: OOoOoo00oo - iIii1I11I1II1 - i1IIi / I1 - O0 * ooO0Oooo00
 if 20 - 20: o00 % Oo0o0ooO0oOOO
 if 19 - 19: o00ooo0 % Oo0o0ooO0oOOO + OOoOoo00oo / I1 . OOoOoo00oo
 if 12 - 12: i1IIi + i1IIi - o00ooo0 * OOo % OOo - I1iII1iiII
 if 52 - 52: OOoOoo00oo . i11iI + I1
 if 38 - 38: i1IIi - I1iII1iiII . I1
 if 58 - 58: I1Ii111 . i11iI + Oo0ooO0oo0oO
 if 66 - 66: i11iI / o00 * OoooooooOO + OoooooooOO % ooO0Oooo00
 if 49 - 49: o00 - i11iIiiIii . I1 * Ooo0 % i11iI + i1IIi
 if 71 - 71: I1i1iI1i
 if 38 - 38: o00 % Oo0ooO0oo0oO + o00ooo0 . i11iIiiIii
 if 53 - 53: i11iIiiIii * i11iI
 if 68 - 68: iIii1I11I1II1 * iIii1I11I1II1 . I1i1iI1i / I1iII1iiII % OOo
 if 38 - 38: OOoOoo00oo - Oo0oO0ooo / i11iI
 if 66 - 66: O0 % o00ooo0 + i11iIiiIii . Oo0ooO0oo0oO / Ooo0 + o00ooo0
 if 86 - 86: I1i1iI1i
i1Iii11Ii1i1 = xbmc . translatePath ( os . path . join ( O0i1II1Iiii1I11 , 'wipe.png' ) )
OOooo0O0o0 = xbmc . translatePath ( os . path . join ( O0i1II1Iiii1I11 , 'support.png' ) )
II1iI1I11I = xbmc . translatePath ( os . path . join ( O0i1II1Iiii1I11 , 'fanart.jpg' ) )
o0OO0IiI11ii1I = xbmc . translatePath ( os . path . join ( O0i1II1Iiii1I11 , 'restore.png' ) )
ooo = xbmc . translatePath ( os . path . join ( O0i1II1Iiii1I11 , 'backup.png' ) )
iiI = xbmc . translatePath ( os . path . join ( O0i1II1Iiii1I11 , 'full_restore.png' ) )
oO = xbmc . translatePath ( os . path . join ( O0i1II1Iiii1I11 , 'adult_full_restore.png' ) )
IIiIi = xbmc . translatePath ( os . path . join ( O0i1II1Iiii1I11 , 'updates.png' ) )
OOoOooOoOOOoo = xbmc . translatePath ( os . path . join ( O0i1II1Iiii1I11 , 'restore_backup.png' ) )
Iiii1iI1i = xbmc . translatePath ( os . path . join ( O0i1II1Iiii1I11 , 'stepone.png' ) )
I1ii1ii11i1I = xbmc . translatePath ( os . path . join ( O0i1II1Iiii1I11 , 'steptwo.png' ) )
o0OoOO = xbmc . translatePath ( os . path . join ( O0i1II1Iiii1I11 , 'stepthree.png' ) )
O0O0Oo00 = xbmc . translatePath ( os . path . join ( O0i1II1Iiii1I11 , 'fixes.png' ) )
oOoO00o = xbmc . translatePath ( os . path . join ( O0i1II1Iiii1I11 , 'default_restore.png' ) )
oO00O0 = xbmc . translatePath ( os . path . join ( O0i1II1Iiii1I11 , 'maintool.png' ) )
IIi1IIIi = xbmc . translatePath ( os . path . join ( O0i1II1Iiii1I11 , 'network.png' ) )
O00Ooo = xbmc . translatePath ( os . path . join ( O0i1II1Iiii1I11 , 'clear_cache.png' ) )
OOOO0OOO = xbmc . translatePath ( os . path . join ( O0i1II1Iiii1I11 , 'update_addons.png' ) )
i1i1ii = xbmc . translatePath ( os . path . join ( O0i1II1Iiii1I11 , 'term.png' ) )
iII1ii1 = xbmc . translatePath ( os . path . join ( O0i1II1Iiii1I11 , 'purge.png' ) )
I1i1iiiI1 = xbmc . translatePath ( os . path . join ( O0i1II1Iiii1I11 , 'apk.png' ) )
iIIi = xbmc . translatePath ( os . path . join ( O0i1II1Iiii1I11 , 'pair.png' ) )
if 62 - 62: OOo - ooO0Oooo00
def Iii1iiIi1II ( ) :
 OO0O00oOo = xbmc . getInfoLabel ( "System.BuildVersion" )
 print OO0O00oOo
 print "###############################################################################################################################################"
 if 14 - 14: I1Ii111
 if 19 - 19: o0OO0 - OOo . o00 / o00 % OOoOoo00oo
 if 56 - 56: I1Ii111 . O0 + OOo
 if 1 - 1: i11iI
 if 97 - 97: Oo0oO0ooo + i11iI + O0 + i11iIiiIii
 if 77 - 77: I1i1iI1i / OoooooooOO
 if 46 - 46: I1i1iI1i % iIii1I11I1II1 . i11iI % i11iI + i11iIiiIii
 if 72 - 72: iIii1I11I1II1 * Ooo0 % OOoOoo00oo / o0OO0
 if 35 - 35: OOoOoo00oo + i1IIi % o00ooo0 % ooO0Oooo00 + o00
 if 17 - 17: i1IIi
 if 21 - 21: OOo
 if 29 - 29: ooO0Oooo00 / I1iII1iiII / OOoOoo00oo * Oo0oO0ooo
 if 10 - 10: I1 % Oo0o0ooO0oOOO * Oo0o0ooO0oOOO . ooO0Oooo00 / Ooo0 % Oo0oO0ooo
 if 49 - 49: o0OO0 / o00 + O0 * I1i1iI1i
 if 28 - 28: OOoOoo00oo + i11iIiiIii / ooO0Oooo00 % Oo0ooO0oo0oO % OOo - O0
 if 54 - 54: i1IIi + I1iII1iiII
 if 83 - 83: o00ooo0 - I1Ii111 + Oo0oO0ooo
 if 5 - 5: Ooo0
 if 46 - 46: Oo0o0ooO0oOOO
 if 45 - 45: OOoOoo00oo
 if 21 - 21: o00 . I1 . Oo0oO0ooo / OOo / I1
 if 17 - 17: Oo0oO0ooo / Oo0oO0ooo / ooO0Oooo00
 if 1 - 1: i1IIi . i11iIiiIii % Oo0oO0ooo
 if 82 - 82: iIii1I11I1II1 + OOo . iIii1I11I1II1 % Oo0o0ooO0oOOO / Ooo0 . Ooo0
 if 14 - 14: I1i1iI1i . Oo0oO0ooo . ooO0Oooo00 + OoooooooOO - Oo0oO0ooo + Oo0o0ooO0oOOO
 if 9 - 9: Ooo0
 if 59 - 59: I1Ii111 * I1iII1iiII . O0
 if 56 - 56: Ooo0 - i11iI % I1Ii111 - I1i1iI1i
 if 51 - 51: O0 / OOoOoo00oo * iIii1I11I1II1 + o00ooo0 + I1i1iI1i
 if 98 - 98: iIii1I11I1II1 * o00ooo0 * Oo0oO0ooo + OOoOoo00oo % i11iIiiIii % O0
 if 27 - 27: O0
 if 79 - 79: I1i1iI1i - ooO0Oooo00 + I1i1iI1i . o00
 if 28 - 28: i1IIi - i11iI
 if 54 - 54: i11iI - O0 % Oo0oO0ooo
 if 73 - 73: O0 . Oo0ooO0oo0oO + I1Ii111 - ooO0Oooo00 % ooO0Oooo00 . ooO0Oooo00
 OOooO0OOoo = i1iIIi1 ( O0O ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 I11ii1i1 = re . compile ( 'update="(.+?)".+?ull_restore="(.+?)".+?dult_full_restore="(.+?)".+?upport_full_restore="(.+?)".+?upport_update="(.+?)"' ) . findall ( OOooO0OOoo )
 for ooo0OoOOOOO , i1iIi1iI , i1I11IiI1iiII , o00oOo0oOoo , oOOO0o00o in I11ii1i1 :
  iI11 = ooo0OoOOOOO
  o00oOoOo0 = i1iIi1iI
  o0O0O0ooo0oOO = i1I11IiI1iiII
  if 97 - 97: I1Ii111 / i11iI
  Oooo0 ( 'Update & Install Software ' + '[COLOR white] ' + o00oOoOo0 + '[/COLOR]' , i1iII1IiiIiI1 , 6 , iiI , II1iI1I11I , '' )
  Oooo0 ( 'Fixes - ' + '[COLOR white] ' + iI11 + '[/COLOR]' , iIiiiI1IiI1I1 , 15 , O0O0Oo00 , II1iI1I11I , 'All fixes will be shown here!' )
  oOO ( 'APK App Installer' , I11i1i11i1I , 80 , I1i1iiiI1 , II1iI1I11I , 'Insatall Anrdoid Apps. ' )
  Oooo0 ( 'Factory Restore' , i1i1II , 16 , oOoO00o , II1iI1I11I , 'All addons and userdata will be completely wiped!' )
  if 54 - 54: I1Ii111 / iIii1I11I1II1 / Oo0oO0ooo . Oo0oO0ooo % i11iI . I1Ii111
  Oooo0 ( 'Terms & Conditions' , oo , 3 , i1i1ii , II1iI1I11I , 'Terms & Conditions info from your TV box seller. ' )
  iI1i1i ( 'movies' , 'MAIN' )
  if 41 - 41: i1IIi % i11iI + iIii1I11I1II1
  if 2 - 2: iIii1I11I1II1 * OOo % o00 - I1iII1iiII - i11iI
  if 3 - 3: I1
  if 45 - 45: I1
def oOIIi1iiii1iI ( ) :
 oOO ( 'Network Speed Test' , i1i1II , 98 , IIi1IIIi , II1iI1I11I , 'Test your network speed on your Infinity TV' )
 Oooo0 ( 'Clear Cache' , i1i1II , 96 , O00Ooo , II1iI1I11I , '' )
 Oooo0 ( 'Update Add-ons' , i1i1II , 95 , OOOO0OOO , II1iI1I11I , '' )
 Oooo0 ( 'Purge Packages (use once or twice a month)' , i1i1II , 90 , iII1ii1 , II1iI1I11I , '' )
 if ( os . path . isfile ( o00oooO0Oo ) ) :
  Oooo0 ( 'Easy To Pair' , i1i1II , 83 , iIIi , II1iI1I11I , '' )
  if 25 - 25: o00ooo0 + O0
  if 28 - 28: OoooooooOO
def speedtest ( ) :
 O0000OOO0 = base64 . b64decode ( "aHR0cDovL2luZGlnby50dmFkZG9ucy5hZy9zcGVlZHRlc3Qvc3BlZWR0ZXN0ZmlsZS50eHQ=" )
 OOooO0OOoo = i1iIIi1 ( O0000OOO0 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 I11ii1i1 = re . compile ( 'name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?ersion="(.+?)"' ) . findall ( OOooO0OOoo )
 for oOooO0 , ooo0 , oO000oOo00o0o , O00oO0 , O0Oo00OoOo in I11ii1i1 :
  Oooo0 ( '[COLOR ghostwhite]' + oOooO0 + " | " + O0Oo00OoOo + '[/COLOR]' , ooo0 , 97 , i1Iii1i1I , II1iI1I11I , '' )
  if 24 - 24: i11iIiiIii - I1
  if 21 - 21: ooO0Oooo00
def OoO00 ( name , url , description ) :
 if 85 - 85: OOo * OOo * I1Ii111 . OoooooooOO . Ooo0 * OOoOoo00oo
 if 65 - 65: Oo0oO0ooo * I1
 url = oo00000o0
 name = 'skin.infinitytv'
 ooo0o000O = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
 ii1ii1ii = xbmcgui . DialogProgress ( )
 ii1ii1ii . create ( "ITV Updater/Installer" , "Applying update... " , '' , 'Please wait' )
 OOOO0o = os . path . join ( ooo0o000O , name + '.zip' )
 try :
  os . remove ( OOOO0o )
 except :
  pass
 downloader . download ( url , OOOO0o , ii1ii1ii )
 oo0o0O0Oooooo = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
 time . sleep ( 2 )
 ii1ii1ii . update ( 0 , "" , "Installing..." )
 extract . all ( OOOO0o , oo0o0O0Oooooo , ii1ii1ii )
 ii1ii1ii . update ( 0 , "" , "Finishing up..." )
 time . sleep ( 5 )
 O00O0oOO00O00 = xbmcgui . Dialog ( )
 O00O0oOO00O00 . ok ( "ITV Updater/Installer" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish update. [/COLOR]" )
 if 1 - 1: OOoOoo00oo % Oo0ooO0oo0oO * OOo
 if 55 - 55: Oo0ooO0oo0oO
 if 87 - 87: OoooooooOO % i11iI . I1Ii111 / OOoOoo00oo
def i1I1iI ( name , url , description ) :
 DialogITVTermsapps . show ( )
 OOooO0OOoo = i1iIIi1 ( url ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 I11ii1i1 = re . compile ( 'name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"' ) . findall ( OOooO0OOoo )
 for name , o0Iii , url , I1iiiiI1iI , O00oO0 , iIiiiii1i , description in I11ii1i1 :
  Oooo0 ( '[COLOR white]' + name + '[/COLOR]' , url , 81 , I1iiiiI1iI , O00oO0 , description )
  if 40 - 40: O0 - OoooooooOO - Oo0o0ooO0oOOO
def iIiii ( name , url , description ) :
 ii1ii1ii = xbmcgui . DialogProgress ( )
 OOO = xbmcgui . Dialog ( ) . yesno ( "[COLOR white]Would you like to download and install: [/COLOR]" , name , '' , '' , yeslabel = 'YES' , nolabel = 'NO' )
 if OOO == 0 :
  return
 elif OOO == 1 :
  if 98 - 98: i11iI - o0OO0 % Oo0o0ooO0oOOO - Oo0ooO0oo0oO
  if 89 - 89: I1 . I1i1iI1i % I1
  ooo0o000O = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI + "/apk" ) )
  ii1ii1ii = xbmcgui . DialogProgress ( )
  name = name . replace ( '\\' , '' ) . replace ( '/' , '' ) . replace ( ':' , '' ) . replace ( '*' , '' ) . replace ( '?' , '' ) . replace ( '"' , '' ) . replace ( '<' , '' ) . replace ( '>' , '' ) . replace ( '|' , '' )
  ii1ii1ii . create ( "APK App Installer" , "Downloading... " , '' , 'Please wait' )
  OOOO0o = os . path . join ( ooo0o000O , name + '.apk' )
  try :
   os . remove ( OOOO0o )
  except :
   pass
  downloader . download ( url , OOOO0o , ii1ii1ii )
  oo0o0O0Oooooo = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
  time . sleep ( 2 )
  ii1ii1ii . update ( 0 , "" , "Installing..." )
  Oo0o000oO ( name )
  xbmc . executebuiltin ( 'StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:' + OOOO0o + '")' )
  xbmc . sleep ( 10 )
  oO0o00oOOooO0 = xbmcgui . Dialog ( ) . yesno ( "[COLOR white]Please press YES to to finish the Install. [/COLOR]" , '' , '' , '' , yeslabel = 'YES' , nolabel = 'NO' )
  if oO0o00oOOooO0 == 0 :
   return
  elif oO0o00oOOooO0 == 1 :
   try :
    os . remove ( OOOO0o )
   except :
    pass
    if 79 - 79: o0OO0 - iIii1I11I1II1 + Ooo0 - I1
def Oo0o000oO ( name ) :
 class OoOiIIiii ( xbmcgui . WindowXMLDialog ) :
  def __init__ ( self , * args , ** kwargs ) :
   self . shut = kwargs [ 'close_time' ]
   xbmc . executebuiltin ( "Skin.Reset(AnimeWindowXMLDialogClose)" )
   xbmc . executebuiltin ( "Skin.SetBool(AnimeWindowXMLDialogClose)" )
   if 61 - 61: Oo0o0ooO0oOOO . i1IIi / I1 % i11iIiiIii * i11iI
  def onClick ( self , controlID ) : self . CloseWindow ( )
  if 31 - 31: Oo0oO0ooo + O0
  def onAction ( self , action ) :
   if action in [ ACTION_PREVIOUS_MENU , ACTION_BACKSPACE , ACTION_NAV_BACK , ACTION_SELECT_ITEM , ACTION_MOUSE_LEFT_CLICK , ACTION_MOUSE_LONG_CLICK ] : self . CloseWindow ( )
   if 87 - 87: OOoOoo00oo
  def CloseWindow ( self ) :
   xbmc . executebuiltin ( "Skin.Reset(AnimeWindowXMLDialogClose)" )
   xbmc . sleep ( 400 )
   self . close ( )
   if 45 - 45: o0OO0 / OoooooooOO - i11iI / Ooo0 % Oo0o0ooO0oOOO
   if 83 - 83: I1Ii111 . iIii1I11I1II1 - Oo0o0ooO0oOOO * i11iIiiIii
   if 20 - 20: i1IIi * I1 + I1iII1iiII % I1i1iI1i % o00
   if 13 - 13: OOo
   if 60 - 60: o00ooo0 * I1Ii111
   if 17 - 17: Oo0oO0ooo % OOo / o00ooo0 . Oo0o0ooO0oOOO * Oo0oO0ooo - I1iII1iiII
   if 41 - 41: Ooo0
   if 77 - 77: I1
def OooOOOOoO00OoOO ( name , url , description ) :
 url = o0OOO
 name = 'skin.infinitytv'
 ooo0o000O = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
 ii1ii1ii = xbmcgui . DialogProgress ( )
 ii1ii1ii . create ( "ITV Updater/Installer" , "Fixing skin issues... " , '' , 'Please wait' )
 OOOO0o = os . path . join ( ooo0o000O , name + '.zip' )
 try :
  os . remove ( OOOO0o )
 except :
  pass
 downloader . download ( url , OOOO0o , ii1ii1ii )
 oo0o0O0Oooooo = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
 time . sleep ( 2 )
 ii1ii1ii . update ( 0 , "" , "Installing..." )
 extract . all ( OOOO0o , oo0o0O0Oooooo , ii1ii1ii )
 ii1ii1ii . update ( 0 , "" , "Finishing up..." )
 time . sleep ( 5 )
 O00O0oOO00O00 = xbmcgui . Dialog ( )
 O00O0oOO00O00 . ok ( "ITV Updater/Installer" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish update. [/COLOR]" )
 if 85 - 85: o00 - iIii1I11I1II1 / O0
def Oo00oo0000OO ( name , url , description ) :
 O00O0oOO00O00 = xbmcgui . Dialog ( )
 O00O0oOO00O00 . ok ( "ITV Updater/Installer" , "[COLOR blue]Please press YES on the next popup. [/COLOR]" , "" , "Then move to STEP TWO!" )
 O0oOOo0Oo ( 'lookandfeel.skin' , 'skin.infinitytv_demo' )
 if 73 - 73: Ooo0 - I1
def O00oooo00o0O ( name , url , description ) :
 Oooo0 ( 'STEP ONE' , o0OOO , 12 , Iiii1iI1i , II1iI1I11I , 'All addons and userdata will be completely wiped!' )
 Oooo0 ( 'STEP TWO' , o0OOO , 13 , I1ii1ii11i1I , II1iI1I11I , 'All addons and userdata will be completely wiped!' )
 iI1i1i ( 'movies' , 'MAIN' )
 if 9 - 9: I1Ii111 % I1Ii111 % I1iII1iiII
 if 30 - 30: Oo0o0ooO0oOOO + I1 - Oo0o0ooO0oOOO . Oo0o0ooO0oOOO - I1iII1iiII + O0
def oOO0 ( name , url , description ) :
 i1IIiIii1i = 'lookandfeel.skin'
 IiIIIi1iIi = ooOOO0OooOo ( i1IIiIii1i )
 if 33 - 33: Oo0oO0ooo / i1IIi - I1Ii111 % OOo . o00ooo0
 if ( os . path . isfile ( IIII ) ) :
  O00O0oOO00O00 = xbmcgui . Dialog ( )
  O00O0oOO00O00 . ok ( "ITV Updater/Installer" , "[COLOR blue]Please press Ok and then Click on Step 1, and follow the next prompts![/COLOR]" )
  if 17 - 17: I1iII1iiII / o00ooo0 % Oo0o0ooO0oOOO + I1Ii111 * I1
 Oooo0 ( 'STEP ONE' , i1iII1IiiIiI1 , 7 , Iiii1iI1i , II1iI1I11I , 'All addons and userdata will be completely wiped!' )
 Oooo0 ( 'STEP TWO' , i1iII1IiiIiI1 , 6 , I1ii1ii11i1I , II1iI1I11I , 'All addons and userdata will be completely wiped!' )
 Oooo0 ( 'STEP THREE' , i1iII1IiiIiI1 , 8 , o0OoOO , II1iI1I11I , 'All addons and userdata will be completely wiped!' )
 iI1i1i ( 'movies' , 'MAIN' )
 if 36 - 36: I1 * o0OO0
def I1Iii1iIi1II ( name , url , description ) :
 if ( os . path . isfile ( IIII ) ) :
  O00O0oOO00O00 = xbmcgui . Dialog ( )
  O00O0oOO00O00 . ok ( "ITV Updater/Installer" , "[COLOR blue]Please press Ok and then Click on Step 1, and follow the next prompts![/COLOR]" )
  if 2 - 2: OOo + Oo0ooO0oo0oO - Oo0oO0ooo . I1Ii111 - Oo0oO0ooo
 Oooo0 ( 'STEP ONE' , iIiiiI1IiI1I1 , 7 , Iiii1iI1i , II1iI1I11I , 'All addons and userdata will be completely wiped!' )
 Oooo0 ( 'STEP TWO' , iIiiiI1IiI1I1 , 6 , I1ii1ii11i1I , II1iI1I11I , 'All addons and userdata will be completely wiped!' )
 Oooo0 ( 'STEP THREE' , iIiiiI1IiI1I1 , 8 , o0OoOO , II1iI1I11I , 'All addons and userdata will be completely wiped!' )
 iI1i1i ( 'movies' , 'MAIN' )
 if 67 - 67: iIii1I11I1II1 - i11iI
def Iii ( ) :
 try :
  os . remove ( IIII )
 except :
  pass
 i1IIiIii1i = 'lookandfeel.skin'
 IiIIIi1iIi = ooOOO0OooOo ( i1IIiIii1i )
 O00O0oOO00O00 = xbmcgui . Dialog ( )
 O00O0oOO00O00 . ok ( "ITV Updater/Installer" , "[COLOR blue]The next popup window will ask \"Would you like to keep this change?\" Click YES and then proceed to Step Two [/COLOR]" , "" , "" )
 O0oOOo0Oo ( 'lookandfeel.skin' , 'skin.infinitytv_demo' )
 if 20 - 20: I1i1iI1i / i1IIi
def oOIi111 ( ) :
 i1IIiIii1i = 'lookandfeel.skin'
 IiIIIi1iIi = ooOOO0OooOo ( i1IIiIii1i )
 O00O0oOO00O00 = xbmcgui . Dialog ( )
 O00O0oOO00O00 . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next pop-up window after you click OK below, will ask you if you want to \"Keep Skin?\". Always click YES to this." , "" , "Please note: If you take to long, it will automatically​ press YES for you as a fail safe." )
 OO0O00oOo = xbmc . getInfoLabel ( "System.BuildVersion" )
 if OO0O00oOo == "17.3 Git:20170524-147cec4" :
  O0oOOo0Oo ( 'lookandfeel.skin' , 'skin.infinitytv-XK-demo' )
 else :
  O0oOOo0Oo ( 'lookandfeel.skin' , 'skin.infinitytv-X-demo' )
  if 67 - 67: O0
def Oooooooo0o ( ) :
 xbmc . executebuiltin ( 'ReloadSkin()' )
 if 74 - 74: Ooo0
def IiIII1i1i ( ) :
 xbmc . executebuiltin ( 'UnloadSkin()' )
 if 41 - 41: OOo / Ooo0 * Ooo0 - Oo0oO0ooo . I1 . OoooooooOO
 if 42 - 42: Oo0oO0ooo % OOo / i11iIiiIii + Oo0oO0ooo
def O0oOOo0Oo ( setting , value ) :
 setting = '"%s"' % setting
 if 84 - 84: I1 . o0OO0 . I1iII1iiII . ooO0Oooo00 / Ooo0 % o00ooo0
 if isinstance ( value , list ) :
  OOO0oOoO0O = ''
  for OoOo000oOo0oo in value :
   OOO0oOoO0O += '"%s",' % str ( OoOo000oOo0oo )
   if 65 - 65: Oo0ooO0oo0oO / o0OO0 % Oo0o0ooO0oOOO
  OOO0oOoO0O = OOO0oOoO0O [ : - 1 ]
  OOO0oOoO0O = '[%s]' % OOO0oOoO0O
  value = OOO0oOoO0O
  if 45 - 45: Oo0ooO0oo0oO
 elif not isinstance ( value , int ) :
  value = '"%s"' % value
  if 66 - 66: o0OO0
 oOOI11I = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % ( setting , value )
 xbmc . executeJSONRPC ( oOOI11I )
 if 6 - 6: o00ooo0 + o00
def ooOOO0OooOo ( setting ) :
 if 48 - 48: iIii1I11I1II1 % i1IIi % i11iI + OOoOoo00oo
 import json
 setting = '"%s"' % setting
 if 30 - 30: i11iIiiIii % iIii1I11I1II1 . ooO0Oooo00 % iIii1I11I1II1
 oOOI11I = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % ( setting )
 iI111I11I1I1 = xbmc . executeJSONRPC ( oOOI11I )
 if 62 - 62: OOo * Oo0ooO0oo0oO
 iI111I11I1I1 = json . loads ( iI111I11I1I1 )
 if 79 - 79: o0OO0 . i11iI * Ooo0 - Oo0oO0ooo + OOoOoo00oo
 if iI111I11I1I1 . has_key ( 'result' ) :
  if iI111I11I1I1 [ 'result' ] . has_key ( 'value' ) :
   return iI111I11I1I1 [ 'result' ] [ 'value' ]
   if 14 - 14: i11iIiiIii - i11iI * Oo0ooO0oo0oO
   if 51 - 51: o00ooo0 / iIii1I11I1II1 % o00 + I1i1iI1i * OOoOoo00oo + I1
def iiIiIIIiiI ( name , url , description ) :
 if 77 - 77: OOoOoo00oo * Oo0ooO0oo0oO
 ooo0o000O = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
 ii1ii1ii = xbmcgui . DialogProgress ( )
 ii1ii1ii . create ( "ITV Updater/Installer" , "Downloading... " , '' , 'Please wait' )
 OOOO0o = os . path . join ( ooo0o000O , name + '.zip' )
 try :
  os . remove ( OOOO0o )
 except :
  pass
 downloader . download ( url , OOOO0o , ii1ii1ii )
 oo0o0O0Oooooo = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
 if 14 - 14: ooO0Oooo00 % ooO0Oooo00 / Oo0o0ooO0oOOO
 time . sleep ( 2 )
 ii1ii1ii . update ( 0 , "" , "Installing..." )
 extract . all ( OOOO0o , oo0o0O0Oooooo , ii1ii1ii )
 ii1ii1ii . update ( 0 , "" , "Finishing up..." )
 time . sleep ( 5 )
 if 72 - 72: i1IIi - I1iII1iiII - Oo0oO0ooo + Oo0oO0ooo * I1i1iI1i * Oo0oO0ooo
 if 33 - 33: OOo
 if 49 - 49: o0OO0 % i11iI % i11iI / i11iI
 if 53 - 53: iIii1I11I1II1
 O00O0oOO00O00 = xbmcgui . Dialog ( )
 O00O0oOO00O00 . ok ( "ITV Updater/Installer" , "[COLOR blue]Installation nearly complete but one important step remains. [/COLOR]" )
 O00O0oOO00O00 = xbmcgui . Dialog ( )
 O00O0oOO00O00 . ok ( "ITV Updater/Installer" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish setup. [/COLOR]" )
 if 68 - 68: OoooooooOO % I1iII1iiII
def Ii1i1i1111 ( ) :
 try :
  os . remove ( IIII )
 except :
  pass
  if 57 - 57: Ooo0 % I1iII1iiII
def O00oOo ( name , url , description ) :
 ii1ii1ii = xbmcgui . DialogProgress ( )
 OOO = xbmcgui . Dialog ( ) . yesno ( "[B]ITV Updater/Installer[/B]" , 'By pressing YES you will install ' , 'the latest version of our software.' , '' , yeslabel = 'YES' , nolabel = 'NO' )
 if OOO == 0 :
  return
 elif OOO == 1 :
  oOIi111 ( )
  time . sleep ( 10 )
  xbmc . executebuiltin ( 'SendClick(11)' )
  O00O0oOO00O00 = xbmcgui . Dialog ( )
  O00O0oOO00O00 . ok ( "[B]ITV Updater/Installer[/B]" , "Click ok to start the process!" , '' , '' )
  ii1ii1ii = xbmcgui . DialogProgress ( )
  ii1ii1ii . create ( "[B]ITV Updater/Installer[/B]" , "Wiping Infinity TV device..." , '' , 'Please wait as it will take a few minutes' )
  time . sleep ( 1 )
  ii1ii1ii . update ( 10 , "" , 'Preparing files...' , 'Please wait' )
  time . sleep ( 3 )
  try :
   for I1iI1 , iiiIi1 , i1I1ii11i1Iii in os . walk ( ooOOoooooo , topdown = True ) :
    iiiIi1 [ : ] = [ OOOO0oo0 for OOOO0oo0 in iiiIi1 if OOOO0oo0 not in oOOoo00O00o ]
    i1I1ii11i1Iii [ : ] = [ oOo0oO for oOo0oO in i1I1ii11i1Iii if oOo0oO not in OoOooO0O0O0ooOOO ]
    for name in i1I1ii11i1Iii :
     try :
      os . remove ( os . path . join ( I1iI1 , name ) )
      ii1ii1ii . update ( 30 , "" , 'Removing files...' , 'Please wait' )
      os . rmdir ( os . path . join ( I1iI1 , name ) )
     except : pass
     if 26 - 26: Oo0o0ooO0oOOO % I1 % o00 % Ooo0
    for name in iiiIi1 :
     try : os . rmdir ( os . path . join ( I1iI1 , name ) ) ; os . rmdir ( I1iI1 )
     except : pass
  except : pass
  ii1ii1ii . update ( 60 , "" , "Removing folders..." )
  oOOOoo00 ( )
  oOOOoo00 ( )
  oOOOoo00 ( )
  ii1ii1ii . update ( 75 , "" , "Removing folders..." )
  oOOOoo00 ( )
  oOOOoo00 ( )
  oOOOoo00 ( )
  oOOOoo00 ( )
  if 55 - 55: OOoOoo00oo % OoooooooOO / OoooooooOO % OoooooooOO
  if 52 - 52: o00ooo0 + o00ooo0 . I1iII1iiII
  ii1ii1ii . update ( 99 , "" , "Almost done..." )
  time . sleep ( 3 )
  ooo0o000O = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
  ii1ii1ii = xbmcgui . DialogProgress ( )
  ii1ii1ii . create ( "ITV Updater/Installer" , "Wipe complete!" , 'Now Downloading...' , 'Please wait' )
  if 34 - 34: OoooooooOO . O0 / o00 * Oo0ooO0oo0oO - o00ooo0
  OOOO0o = os . path . join ( ooo0o000O , 'fullbackup.zip' )
  try :
   os . remove ( OOOO0o )
  except :
   pass
  downloader . download ( url , OOOO0o , ii1ii1ii )
  oo0o0O0Oooooo = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
  time . sleep ( 2 )
  ii1ii1ii . update ( 0 , "" , "Installing..." )
  extract . all ( OOOO0o , oo0o0O0Oooooo , ii1ii1ii )
  ii1ii1ii . update ( 0 , "" , "Finishing up..." )
  time . sleep ( 3 )
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  time . sleep ( 2 )
  O00O0oOO00O00 = xbmcgui . Dialog ( )
  O00O0oOO00O00 . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next pop-up window after you click OK below, will ask you if you want to \"Keep Skin?\". Always click YES to this." , "" , "Please note: If you take to long, it will automatically​ press YES for you as a fail safe." )
  try :
   os . remove ( OOOO0o )
  except :
   pass
  if xbmc_version == "17.3 Git:20170524-147cec4" :
   O0oOOo0Oo ( 'lookandfeel.skin' , 'skin.infinitytv-XK' )
  else :
   O0oOOo0Oo ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
  O00O0oOO00O00 = xbmcgui . Dialog ( )
  time . sleep ( 10 )
  xbmc . executebuiltin ( 'SendClick(11)' )
  if 36 - 36: i1IIi / O0 / o0OO0 - O0 - i1IIi
  try :
   os . remove ( iiIiII1 )
  except :
   pass
  O00O0oOO00O00 . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Installation is complete. " )
  xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
  if 22 - 22: i1IIi + Ooo0
  if 54 - 54: OOoOoo00oo % Oo0oO0ooo . I1 + o00 - Oo0oO0ooo * I1Ii111
  if 92 - 92: I1i1iI1i + I1 / OOo % o0OO0 % Oo0o0ooO0oOOO . OoooooooOO
def O0Oo ( name , url , description ) :
 DialogITVTerms . show ( )
 ii1ii1ii = xbmcgui . DialogProgress ( )
 OOO = xbmcgui . Dialog ( ) . yesno ( "[B]ITV Updater/Installer[/B]" , 'By pressing YES you will install ' , 'the latest version of our software.' , '' , yeslabel = 'YES' , nolabel = 'NO' )
 if OOO == 0 :
  return
 elif OOO == 1 :
  I1IiI111I11 = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]Would you like Adult XXX Content? (Must be 18+)[/COLOR]" , 'By pressing YES adult xxx content will be installed to' , 'your device.' , '' , yeslabel = 'YES' , nolabel = 'NO' )
  if I1IiI111I11 == 0 :
   if xbmc_version == "17.3 Git:20170524-147cec4" :
    url = iI1
   else :
    url = i1iII1IiiIiI1
    if 16 - 16: O0 / Ooo0 . o00ooo0
   oOIi111 ( )
   time . sleep ( 10 )
   xbmc . executebuiltin ( 'SendClick(11)' )
   O00O0oOO00O00 = xbmcgui . Dialog ( )
   O00O0oOO00O00 . ok ( "[B]ITV Updater/Installer[/B]" , "Click ok to start the process!" , '' , '' )
   ii1ii1ii = xbmcgui . DialogProgress ( )
   ii1ii1ii . create ( "[B]ITV Updater/Installer[/B]" , "Wiping Infinity TV device..." , '' , 'Please wait as it will take a few minutes' )
   time . sleep ( 1 )
   ii1ii1ii . update ( 10 , "" , 'Preparing files...' , 'Please wait' )
   time . sleep ( 3 )
   try :
    for I1iI1 , iiiIi1 , i1I1ii11i1Iii in os . walk ( ooOOoooooo , topdown = True ) :
     iiiIi1 [ : ] = [ OOOO0oo0 for OOOO0oo0 in iiiIi1 if OOOO0oo0 not in oOOoo00O00o ]
     i1I1ii11i1Iii [ : ] = [ oOo0oO for oOo0oO in i1I1ii11i1Iii if oOo0oO not in OoOooO0O0O0ooOOO ]
     for name in i1I1ii11i1Iii :
      try :
       os . remove ( os . path . join ( I1iI1 , name ) )
       ii1ii1ii . update ( 30 , "" , 'Removing files...' , 'Please wait' )
       os . rmdir ( os . path . join ( I1iI1 , name ) )
      except : pass
      if 58 - 58: OOo / o00
     for name in iiiIi1 :
      try : os . rmdir ( os . path . join ( I1iI1 , name ) ) ; os . rmdir ( I1iI1 )
      except : pass
   except : pass
   ii1ii1ii . update ( 60 , "" , "Removing folders..." )
   oOOOoo00 ( )
   oOOOoo00 ( )
   oOOOoo00 ( )
   ii1ii1ii . update ( 75 , "" , "Removing folders..." )
   oOOOoo00 ( )
   oOOOoo00 ( )
   oOOOoo00 ( )
   oOOOoo00 ( )
   if 44 - 44: Oo0oO0ooo
   if 54 - 54: Ooo0 - ooO0Oooo00 - I1 . iIii1I11I1II1
   ii1ii1ii . update ( 99 , "" , "Almost done..." )
   time . sleep ( 3 )
   ooo0o000O = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
   ii1ii1ii = xbmcgui . DialogProgress ( )
   ii1ii1ii . create ( "ITV Updater/Installer" , "Wipe complete!" , 'Now Downloading...' , 'Please wait' )
   if 79 - 79: Ooo0 . o0OO0
   OOOO0o = os . path . join ( ooo0o000O , 'fullbackup.zip' )
   try :
    os . remove ( OOOO0o )
   except :
    pass
   downloader . download ( url , OOOO0o , ii1ii1ii )
   oo0o0O0Oooooo = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
   time . sleep ( 2 )
   ii1ii1ii . update ( 0 , "" , "Installing..." )
   extract . all ( OOOO0o , oo0o0O0Oooooo , ii1ii1ii )
   ii1ii1ii . update ( 0 , "" , "Finishing up..." )
   time . sleep ( 3 )
   xbmc . executebuiltin ( 'UpdateLocalAddons' )
   xbmc . executebuiltin ( "UpdateAddonRepos" )
   time . sleep ( 2 )
   O00O0oOO00O00 = xbmcgui . Dialog ( )
   O00O0oOO00O00 . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next pop-up window after you click OK below, will ask you if you want to \"Keep Skin?\". Always click YES to this." , "" , "Please note: If you take to long, it will automatically​ press YES for you as a fail safe." )
   try :
    os . remove ( OOOO0o )
   except :
    pass
   if xbmc_version == "17.3 Git:20170524-147cec4" :
    O0oOOo0Oo ( 'lookandfeel.skin' , 'skin.infinitytv-XK' )
   else :
    O0oOOo0Oo ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
   O00O0oOO00O00 = xbmcgui . Dialog ( )
   time . sleep ( 10 )
   xbmc . executebuiltin ( 'SendClick(11)' )
   O00O0oOO00O00 . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Installation is complete. " )
   try :
    os . remove ( iiIiII1 )
   except :
    pass
   xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
   if 40 - 40: I1i1iI1i + OOo . I1i1iI1i % OOoOoo00oo
  elif I1IiI111I11 == 1 :
   if xbmc_version == "17.3 Git:20170524-147cec4" :
    url = OoOooOOOO
   else :
    url = iIiiiI1IiI1I1
    if 15 - 15: Ooo0 * OOo % o00ooo0 * iIii1I11I1II1 - i11iIiiIii
   oOIi111 ( )
   time . sleep ( 10 )
   xbmc . executebuiltin ( 'SendClick(11)' )
   O00O0oOO00O00 = xbmcgui . Dialog ( )
   O00O0oOO00O00 . ok ( "[B]ITV Updater/Installer[/B]" , "Click ok to start the process!" , '' , '' )
   ii1ii1ii = xbmcgui . DialogProgress ( )
   ii1ii1ii . create ( "[B]ITV Updater/Installer[/B]" , "Wiping Infinity TV device..." , '' , 'Please wait as it will take a few minutes' )
   time . sleep ( 1 )
   ii1ii1ii . update ( 10 , "" , 'Preparing files...' , 'Please wait' )
   time . sleep ( 3 )
   try :
    for I1iI1 , iiiIi1 , i1I1ii11i1Iii in os . walk ( ooOOoooooo , topdown = True ) :
     iiiIi1 [ : ] = [ OOOO0oo0 for OOOO0oo0 in iiiIi1 if OOOO0oo0 not in oOOoo00O00o ]
     i1I1ii11i1Iii [ : ] = [ oOo0oO for oOo0oO in i1I1ii11i1Iii if oOo0oO not in OoOooO0O0O0ooOOO ]
     for name in i1I1ii11i1Iii :
      try :
       os . remove ( os . path . join ( I1iI1 , name ) )
       ii1ii1ii . update ( 30 , "" , 'Removing files...' , 'Please wait' )
       os . rmdir ( os . path . join ( I1iI1 , name ) )
      except : pass
      if 60 - 60: I1Ii111 * I1 % o0OO0 + o00
     for name in iiiIi1 :
      try : os . rmdir ( os . path . join ( I1iI1 , name ) ) ; os . rmdir ( I1iI1 )
      except : pass
   except : pass
   ii1ii1ii . update ( 60 , "" , "Removing folders..." )
   oOOOoo00 ( )
   oOOOoo00 ( )
   oOOOoo00 ( )
   ii1ii1ii . update ( 75 , "" , "Removing folders..." )
   oOOOoo00 ( )
   oOOOoo00 ( )
   oOOOoo00 ( )
   oOOOoo00 ( )
   if 52 - 52: i1IIi
   if 84 - 84: Ooo0 / Oo0o0ooO0oOOO
   ii1ii1ii . update ( 99 , "" , "Almost done..." )
   time . sleep ( 3 )
   ooo0o000O = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
   ii1ii1ii = xbmcgui . DialogProgress ( )
   ii1ii1ii . create ( "ITV Updater/Installer" , "Wipe complete!" , 'Now Downloading...' , 'Please wait' )
   if 86 - 86: Oo0ooO0oo0oO * I1iII1iiII - O0 . Oo0ooO0oo0oO % iIii1I11I1II1 / Oo0oO0ooo
   OOOO0o = os . path . join ( ooo0o000O , 'fullbackup.zip' )
   try :
    os . remove ( OOOO0o )
   except :
    pass
   downloader . download ( url , OOOO0o , ii1ii1ii )
   oo0o0O0Oooooo = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
   time . sleep ( 2 )
   ii1ii1ii . update ( 0 , "" , "Installing..." )
   extract . all ( OOOO0o , oo0o0O0Oooooo , ii1ii1ii )
   ii1ii1ii . update ( 0 , "" , "Finishing up..." )
   time . sleep ( 3 )
   xbmc . executebuiltin ( 'UpdateLocalAddons' )
   xbmc . executebuiltin ( "UpdateAddonRepos" )
   time . sleep ( 2 )
   O00O0oOO00O00 = xbmcgui . Dialog ( )
   O00O0oOO00O00 . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next pop-up window after you click OK below, will ask you if you want to \"Keep Skin?\". Always click YES to this." , "" , "Please note: If you take to long, it will automatically​ press YES for you as a fail safe." )
   try :
    os . remove ( OOOO0o )
   except :
    pass
   if xbmc_version == "17.3 Git:20170524-147cec4" :
    O0oOOo0Oo ( 'lookandfeel.skin' , 'skin.infinitytv-XK' )
   else :
    O0oOOo0Oo ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
   time . sleep ( 10 )
   xbmc . executebuiltin ( 'SendClick(11)' )
   O00O0oOO00O00 = xbmcgui . Dialog ( )
   O00O0oOO00O00 . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Installation is complete. " )
   try :
    os . remove ( iiIiII1 )
   except :
    pass
   xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
   if 11 - 11: I1Ii111 * o00 + o00ooo0 / o00ooo0
   if 37 - 37: i11iIiiIii + i1IIi
def I1i11II ( ) :
 II11 = [ ]
 I1iii = xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.GetFavourites", "params": {"type": null, "properties": ["path", "thumbnail", "window", "windowparameter"]}, "id": 1}' )
 I1iii = unicode ( I1iii , 'utf-8' , errors = 'ignore' )
 I1iii = simplejson . loads ( I1iii )
 if I1iii [ "result" ] [ "limits" ] [ "total" ] > 0 :
  for oOO0OO0O in I1iii [ "result" ] [ "favourites" ] :
   ooo0o000O = o00o ( oOO0OO0O )
   III11I = { 'Label' : oOO0OO0O [ "title" ] ,
 'Thumb' : oOO0OO0O [ "thumbnail" ] ,
 'Type' : oOO0OO0O [ "type" ] ,
 'Builtin' : ooo0o000O ,
 'Path' : "plugin://script.extendedinfo/?info=action&&id=" + ooo0o000O }
   II11 . append ( III11I )
 print "ITEMS ################################################"
 print II11
 return II11
 if 17 - 17: OoooooooOO + Oo0oO0ooo * ooO0Oooo00 * Oo0ooO0oo0oO
def o00o ( fav ) :
 if fav [ "type" ] == "media" :
  ooo0o000O = "PlayMedia(%s)" % ( fav [ "path" ] )
 elif fav [ "type" ] == "script" :
  ooo0o000O = "RunScript(%s)" % ( fav [ "path" ] )
 else :
  ooo0o000O = "ActivateWindow(%s,%s)" % (
 fav [ "window" ] , fav [ "windowparameter" ] )
 return ooo0o000O
 if 36 - 36: O0 + OOo
def iIIIi1i1I11i ( favtype ) :
 oOO0OO0OO = I1i11II ( )
 oOOoooO = [ ]
 for oOO0OO0O in oOO0OO0OO :
  if oOO0OO0O [ "Type" ] == favtype :
   oOOoooO . append ( oOO0OO0O )
 return oOOoooO
 if 22 - 22: ooO0Oooo00 + iIii1I11I1II1
def IIIii1iiIi ( ) :
 from t0mm0 . common . net import Net
 import socket
 import time
 if 63 - 63: o00ooo0
 i1II = Net ( )
 if 2 - 2: I1iII1iiII - o0OO0 . Oo0o0ooO0oOOO * i11iI / o00
 ooo0o000O = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
 OOOO0o = os . path . join ( ooo0o000O , 'fullbackup.zip' )
 import zipfile
 if 80 - 80: Oo0oO0ooo / ooO0Oooo00 / Oo0ooO0oo0oO + i1IIi - OOo
 iIIiiIIi1IiI = zipfile . ZipFile ( OOOO0o , "r" )
 for I11IIIiIi11 in iIIiiIIi1IiI . namelist ( ) :
  if 'favourites.xml' in I11IIIiIi11 :
   I11iiIi1i1 = iIIiiIIi1IiI . read ( I11IIIiIi11 )
   i1IiiI1iIi = '<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
   if 66 - 66: o0OO0 * OOo
   I11ii1i1 = re . compile ( i1IiiI1iIi ) . findall ( I11iiIi1i1 )
   print I11ii1i1
   for oOooO0 , II1IIIiiI11 , OO0ooOOO00 in I11ii1i1 :
    if 17 - 17: O0 . I1 . O0 + O0 / OOo . OOoOoo00oo
    II1IIIiiI11 = II1IIIiiI11 . replace ( 'thumb://None' , '/mnt/internal_sd/Android/data/org.xbmc.xbmc/files/.xbmc/addons/script.1channel.themepak/art/themes/Glossy_Black/favourites.png' )
    OO0ooOOO00 = OO0ooOOO00 . replace ( '&quot;' , '' ) . replace ( '&amp;' , '&' )
    json . loads ( xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % ( oOooO0 , OO0ooOOO00 , II1IIIiiI11 ) ) )
    for OO00OOoO0o , Iiiiiii1 in enumerate ( fileinput . input ( oo00O00oO , inplace = 1 ) ) :
     sys . stdout . write ( Iiiiiii1 . replace ( 'RunScript(&quot;' , '' ) . replace ( '&quot;)' , '' ) )
  if 78 - 78: o00ooo0 + ooO0Oooo00 - O0
  if 10 - 10: I1 % I1Ii111
  if 97 - 97: OoooooooOO - I1
  if 58 - 58: iIii1I11I1II1 + O0
  if 30 - 30: OOoOoo00oo % i11iI * Oo0oO0ooo - o00ooo0 * Ooo0 % OOoOoo00oo
  if 46 - 46: i11iIiiIii - O0 . o00
  if 100 - 100: I1Ii111 / I1i1iI1i * i11iI . O0 / Oo0oO0ooo
  if 83 - 83: I1
  if 48 - 48: I1iII1iiII * Oo0oO0ooo * I1
  if 50 - 50: Oo0o0ooO0oOOO % i1IIi
  if 21 - 21: OoooooooOO - iIii1I11I1II1
  if 93 - 93: o00 - I1i1iI1i % Oo0ooO0oo0oO . Oo0ooO0oo0oO - OOoOoo00oo
  if 90 - 90: OOoOoo00oo + I1iII1iiII * o00ooo0 / Ooo0 . I1i1iI1i + I1i1iI1i
def I11I ( ) :
 from t0mm0 . common . net import Net
 import socket
 import time
 if 69 - 69: i1IIi
 if ( os . path . isfile ( iIiIIIi ) ) :
  i1II = Net ( )
  ooOoOOOOo = ''
  oOo0oO = open ( oo00O00oO , mode = 'w' )
  oOo0oO . write ( ooOoOOOOo )
  oOo0oO . close ( )
  if 71 - 71: I1iII1iiII * iIii1I11I1II1 / o00ooo0
  I11iiIi1i1 = open ( iIiIIIi ) . read ( )
  i1IiiI1iIi = '<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
  I11ii1i1 = re . compile ( i1IiiI1iIi ) . findall ( I11iiIi1i1 )
  for iiIIi , ooO00O00oOO , I1IIII1ii in I11ii1i1 :
   json . loads ( xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % ( iiIIi , I1IIII1ii , ooO00O00oOO ) ) )
   for OO00OOoO0o , Iiiiiii1 in enumerate ( fileinput . input ( oo00O00oO , inplace = 1 ) ) :
    sys . stdout . write ( Iiiiiii1 . replace ( 'RunScript(&quot;' , '' ) . replace ( '&quot;)' , '' ) . replace ( '&amp;' , '&' ) )
    if 13 - 13: OoooooooOO * o00 - Ooo0 / Oo0oO0ooo + ooO0Oooo00 + Oo0o0ooO0oOOO
  ooo0o000O = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
  iii1III1i = os . path . join ( ooo0o000O , 'favourites.xml' )
  downloader . download ( Oo , iii1III1i )
  time . sleep ( 2 )
  I11IIIiIi11 = iii1III1i
  if 17 - 17: I1iII1iiII / I1iII1iiII
  i1IiiI1iIi = '<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
  if 65 - 65: Oo0o0ooO0oOOO + OOo
  Ooo0O0 = re . compile ( i1IiiI1iIi ) . findall ( I11iiIi1i1 )
  for oOooO0 , II1IIIiiI11 , OO0ooOOO00 in Ooo0O0 :
   I11iiIi1i1 = open ( oo00O00oO ) . read ( )
   if oOooO0 in I11iiIi1i1 : break
   if 71 - 71: OoooooooOO
   if 11 - 11: Oo0o0ooO0oOOO
   if 55 - 55: OOo
   II1IIIiiI11 = II1IIIiiI11 . replace ( 'thumb://None' , '/mnt/internal_sd/Android/data/org.xbmc.xbmc/files/.xbmc/addons/script.1channel.themepak/art/themes/Glossy_Black/favourites.png' )
   OO0ooOOO00 = OO0ooOOO00 . replace ( '&quot;' , '' )
   if 77 - 77: I1iII1iiII
   json . loads ( xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % ( oOooO0 , OO0ooOOO00 , II1IIIiiI11 ) ) )
   for OO00OOoO0o , Iiiiiii1 in enumerate ( fileinput . input ( oo00O00oO , inplace = 1 ) ) :
    sys . stdout . write ( Iiiiiii1 . replace ( 'RunScript(&quot;' , '' ) . replace ( '&quot;)' , '' ) )
 else :
  pass
  if 16 - 16: I1Ii111 * I1iII1iiII / iIii1I11I1II1 - i11iI
  if 3 - 3: I1Ii111 * OOoOoo00oo + I1iII1iiII - o0OO0
def OOOOOoOO0OOoo ( ) :
 if 1 - 1: I1Ii111 * i11iIiiIii + I1 * i11iIiiIii + o0OO0
 import time
 if 30 - 30: OOo . o0OO0
 try :
  ii1ii1ii = xbmcgui . DialogProgress ( )
  ii1ii1ii . create ( "ITV Updater/Installer" , "Retrieving backup file... " , '' , 'Please wait' )
  OOOO0o = xbmc . translatePath ( os . path . join ( II1I , 'backup.zip' ) )
  oo0o0O0Oooooo = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
  time . sleep ( 2 )
  ii1ii1ii . update ( 0 , "" , "Installing..." )
  extract . all ( OOOO0o , oo0o0O0Oooooo , ii1ii1ii )
  ii1ii1ii . update ( 0 , "" , "Finishing up..." )
  time . sleep ( 5 )
  O00O0oOO00O00 = xbmcgui . Dialog ( )
  O00O0oOO00O00 . ok ( "ITV Updater/Installer" , "[COLOR yellow]Installation nearly complete but one important step remains. [/COLOR]" )
  O00O0oOO00O00 = xbmcgui . Dialog ( )
  O00O0oOO00O00 . ok ( "ITV Updater/Installer" , "[COLOR red]URGENT: Please unplug or power off your device immediately and then reboot to finish setup. [/COLOR]" )
  if 57 - 57: ooO0Oooo00 . OOo + I1iII1iiII
 except :
  O00O0oOO00O00 = xbmcgui . Dialog ( )
  O00O0oOO00O00 . ok ( 'ITV Updater/Installer' , 'You need to backup your build first.\nTo backup your box press backup on main menu.' , '' , '' )
  if 43 - 43: I1 % i11iI
  if 69 - 69: i11iI % o0OO0
  if 86 - 86: o00 / o00
def Oooo0 ( name , url , mode , iconimage , fanart , description ) :
 IiiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 i1Oo00 = True
 i11ii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i11ii . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i11ii . setProperty ( "Fanart_Image" , fanart )
 i1Oo00 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IiiI , listitem = i11ii , isFolder = False )
 return i1Oo00
 if 50 - 50: Ooo0 / Oo0ooO0oo0oO * Ooo0
def oOO ( name , url , mode , iconimage , fanart , description ) :
 IiiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 i1Oo00 = True
 i11ii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i11ii . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i11ii . setProperty ( "Fanart_Image" , fanart )
 i1Oo00 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IiiI , listitem = i11ii , isFolder = True )
 return i1Oo00
 if 34 - 34: O0 * O0 % OoooooooOO + i11iI * iIii1I11I1II1 % Ooo0
 if 25 - 25: ooO0Oooo00 + Oo0ooO0oo0oO . I1i1iI1i % Oo0ooO0oo0oO * Oo0oO0ooo
 if 32 - 32: i11iIiiIii - I1
def oo00ooOoo ( ) :
 iii1IIIiiiI = [ ]
 OoO00oo00 = sys . argv [ 2 ]
 if len ( OoO00oo00 ) >= 2 :
  Oo0Oo0O = sys . argv [ 2 ]
  iiiI1i11Ii = Oo0Oo0O . replace ( '?' , '' )
  if ( Oo0Oo0O [ len ( Oo0Oo0O ) - 1 ] == '/' ) :
   Oo0Oo0O = Oo0Oo0O [ 0 : len ( Oo0Oo0O ) - 2 ]
  iIiII = iiiI1i11Ii . split ( '&' )
  iii1IIIiiiI = { }
  for OO00OOoO0o in range ( len ( iIiII ) ) :
   i1i1IIIIIIIi = { }
   i1i1IIIIIIIi = iIiII [ OO00OOoO0o ] . split ( '=' )
   if ( len ( i1i1IIIIIIIi ) ) == 2 :
    iii1IIIiiiI [ i1i1IIIIIIIi [ 0 ] ] = i1i1IIIIIIIi [ 1 ]
    if 65 - 65: I1i1iI1i
 return iii1IIIiiiI
 if 7 - 7: Oo0o0ooO0oOOO . Oo0ooO0oo0oO / o00ooo0 . Oo0oO0ooo * ooO0Oooo00 - I1iII1iiII
 if 37 - 37: I1 . Oo0ooO0oo0oO / O0 * i11iI
Oo0Oo0O = oo00ooOoo ( )
ooo0 = None
oOooO0 = None
III11iiii11i1 = None
oO000oOo00o0o = None
O00oO0 = None
O0Oo00OoOo = None
if 54 - 54: i1IIi - o00
if 18 - 18: iIii1I11I1II1 + OOo - Oo0oO0ooo + OoooooooOO * OoooooooOO
try :
 ooo0 = urllib . unquote_plus ( Oo0Oo0O [ "url" ] )
except :
 pass
try :
 oOooO0 = urllib . unquote_plus ( Oo0Oo0O [ "name" ] )
except :
 pass
try :
 oO000oOo00o0o = urllib . unquote_plus ( Oo0Oo0O [ "iconimage" ] )
except :
 pass
try :
 III11iiii11i1 = int ( Oo0Oo0O [ "mode" ] )
except :
 pass
try :
 O00oO0 = urllib . unquote_plus ( Oo0Oo0O [ "fanart" ] )
except :
 pass
try :
 O0Oo00OoOo = urllib . unquote_plus ( Oo0Oo0O [ "description" ] )
except :
 pass
 if 41 - 41: OOoOoo00oo . OOo + I1Ii111
 if 100 - 100: Ooo0 + o0OO0
print str ( oOooOOOoOo ) + ': ' + str ( iii )
print "Mode: " + str ( III11iiii11i1 )
print "URL: " + str ( ooo0 )
print "Name: " + str ( oOooO0 )
print "IconImage: " + str ( oO000oOo00o0o )
if 73 - 73: i1IIi - I1 % OOoOoo00oo / o0OO0
if 40 - 40: o00ooo0 * OOoOoo00oo - I1Ii111 / Oo0o0ooO0oOOO / i11iIiiIii
def iI1i1i ( content , viewType ) :
 if 83 - 83: o00ooo0 / I1 - i11iIiiIii . iIii1I11I1II1 + OOo
 if content :
  xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , content )
 if i1 . getSetting ( 'auto-view' ) == 'true' :
  xbmc . executebuiltin ( "Container.SetViewMode(%s)" % i1 . getSetting ( viewType ) )
  if 59 - 59: O0 % OOo
  if 92 - 92: Ooo0 % i11iI / o00ooo0 % o00ooo0 * I1Ii111
if III11iiii11i1 == None or ooo0 == None or len ( ooo0 ) < 1 :
 Iii1iiIi1II ( )
 if 74 - 74: O0 . I1Ii111 % o0OO0 % Oo0o0ooO0oOOO
elif III11iiii11i1 == 1 :
 iiIiIIIiiI ( oOooO0 , ooo0 , O0Oo00OoOo )
 if 87 - 87: o00 - i11iIiiIii
elif III11iiii11i1 == 2 :
 i1iI ( oOooO0 , ooo0 , O0Oo00OoOo )
 if 78 - 78: i11iIiiIii / iIii1I11I1II1 - I1i1iI1i
elif III11iiii11i1 == 3 :
 Ii1Iii1iIi ( )
 if 23 - 23: ooO0Oooo00
elif III11iiii11i1 == 4 :
 OOOOOoOO0OOoo ( )
 if 40 - 40: I1i1iI1i - I1iII1iiII / OOo
elif III11iiii11i1 == 5 :
 O0oOo00o ( )
 if 14 - 14: o00ooo0
elif III11iiii11i1 == 6 :
 O0Oo ( oOooO0 , ooo0 , O0Oo00OoOo )
 if 5 - 5: I1i1iI1i . iIii1I11I1II1 % iIii1I11I1II1
elif III11iiii11i1 == 7 :
 Iii ( )
 if 56 - 56: OoooooooOO - ooO0Oooo00 - i1IIi
elif III11iiii11i1 == 8 :
 O00O0oOO00O00 = xbmcgui . Dialog ( )
 O00O0oOO00O00 . ok ( "ITV Updater/Installer" , "[COLOR yellow]Important![/COLOR]" , "" , "Please POWER DOWN your Infinity TV, and then turn it back ON for the changes to take place." )
 try :
  os . remove ( lib )
 except :
  pass
 I11I ( )
 if 8 - 8: I1 / Oo0oO0ooo . I1Ii111 + o00ooo0 / i11iIiiIii
 if 31 - 31: OOoOoo00oo - iIii1I11I1II1 + i11iI . OOo / Oo0o0ooO0oOOO % iIii1I11I1II1
 if 6 - 6: Oo0o0ooO0oOOO * i11iIiiIii % iIii1I11I1II1 % i11iIiiIii + I1i1iI1i / i1IIi
 if 53 - 53: ooO0Oooo00 + iIii1I11I1II1
 if 70 - 70: o00ooo0
 try :
  os . remove ( iIiIIIi )
 except :
  pass
  if 67 - 67: OoooooooOO
elif III11iiii11i1 == 9 :
 oOO0 ( oOooO0 , ooo0 , O0Oo00OoOo )
 if 29 - 29: O0 - i11iIiiIii - I1iII1iiII + Oo0oO0ooo * Oo0o0ooO0oOOO
elif III11iiii11i1 == 10 :
 I1Iii1iIi1II ( oOooO0 , ooo0 , O0Oo00OoOo )
 if 2 - 2: i1IIi - OOoOoo00oo + I1Ii111 . I1i1iI1i * I1i1iI1i / Oo0ooO0oo0oO
elif III11iiii11i1 == 11 :
 O00oooo00o0O ( oOooO0 , ooo0 , O0Oo00OoOo )
 if 93 - 93: i1IIi
elif III11iiii11i1 == 12 :
 Oo00oo0000OO ( oOooO0 , ooo0 , O0Oo00OoOo )
 if 53 - 53: OoooooooOO + OOo + o00
elif III11iiii11i1 == 13 :
 OooOOOOoO00OoOO ( oOooO0 , ooo0 , O0Oo00OoOo )
 if 24 - 24: i11iI - Oo0o0ooO0oOOO - i11iI * o00ooo0 . OoooooooOO / Oo0o0ooO0oOOO
elif III11iiii11i1 == 15 :
 OoO00 ( oOooO0 , ooo0 , O0Oo00OoOo )
 if 66 - 66: OOo
elif III11iiii11i1 == 16 :
 O00oOo ( oOooO0 , ooo0 , O0Oo00OoOo )
 if 97 - 97: i1IIi - OoooooooOO / I1 * I1Ii111
elif III11iiii11i1 == 99 :
 oOIIi1iiii1iI ( )
 if 55 - 55: I1i1iI1i . i11iI
 if 87 - 87: I1i1iI1i % iIii1I11I1II1
 if 100 - 100: I1 . I1Ii111 * I1 - I1Ii111 . ooO0Oooo00 * Ooo0
 if 89 - 89: o0OO0 + Oo0o0ooO0oOOO * I1
 if 28 - 28: OoooooooOO . o00 % o00ooo0 / i1IIi / Oo0oO0ooo
 if 36 - 36: I1i1iI1i + ooO0Oooo00 - Oo0o0ooO0oOOO + iIii1I11I1II1 + OoooooooOO
 if 4 - 4: I1iII1iiII . ooO0Oooo00 + Ooo0 * I1 . OOoOoo00oo
 if 87 - 87: Oo0ooO0oo0oO / o0OO0 / i11iIiiIii
 if 74 - 74: o00 / o00ooo0 % I1i1iI1i
elif III11iiii11i1 == 98 :
 xbmc . executebuiltin ( "RunScript(script.speedtestnet)" )
 if 88 - 88: Oo0ooO0oo0oO - i11iIiiIii % I1i1iI1i * ooO0Oooo00 + o00ooo0
 if 52 - 52: I1iII1iiII . I1Ii111 + Oo0ooO0oo0oO % o0OO0
elif III11iiii11i1 == 97 :
 O00Oo000ooO0 ( ooo0 )
 if 62 - 62: I1i1iI1i
elif III11iiii11i1 == 96 :
 oO0O00OoOO0 ( )
 if 15 - 15: ooO0Oooo00 + Ooo0 . Oo0oO0ooo * o0OO0 . Oo0ooO0oo0oO
elif III11iiii11i1 == 95 :
 O00O0oOO00O00 = xbmcgui . Dialog ( )
 O00O0oOO00O00 . ok ( "Update Add-ons" , "Press OK to make sure all your add-ons apps are up-to-date." , "" , "" )
 xbmc . executebuiltin ( 'UpdateLocalAddons' )
 xbmc . executebuiltin ( "UpdateAddonRepos" )
 if 18 - 18: i1IIi % I1iII1iiII + I1 % Ooo0
elif III11iiii11i1 == 90 :
 o00oO0oo0OO ( )
 if 72 - 72: iIii1I11I1II1
elif III11iiii11i1 == 80 :
 i1I1iI ( oOooO0 , ooo0 , O0Oo00OoOo )
 if 45 - 45: OOo - I1i1iI1i % I1
elif III11iiii11i1 == 81 :
 iIiii ( oOooO0 , ooo0 , O0Oo00OoOo )
 if 38 - 38: I1 % Oo0oO0ooo - OoooooooOO
elif III11iiii11i1 == 82 :
 Oo0o000oO ( oOooO0 )
 if 87 - 87: o0OO0 % I1Ii111
elif III11iiii11i1 == 83 :
 xbmc . executebuiltin ( "RunScript(script.startec.pairwith)" )
 if 77 - 77: iIii1I11I1II1 - i1IIi . o00
 if 26 - 26: I1i1iI1i * Oo0o0ooO0oOOO . i1IIi
 if 59 - 59: O0 + i1IIi - I1i1iI1i
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
if 62 - 62: i11iIiiIii % Oo0oO0ooo . Oo0o0ooO0oOOO . Oo0oO0ooo
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
