import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import sys,plugintools
import zipfile
import net
net=net.Net()

ADDON=xbmcaddon.Addon(id='plugin.video.itv_wizard_kodi')
THESITE = 'Infinitytv.ca'
zip          =  ADDON.getSetting('zip')
dialog       =  xbmcgui.Dialog()
dp           =  xbmcgui.DialogProgress()
USERDATA     =  xbmc.translatePath(os.path.join('special://home/userdata',''))
ADDON_DATA   =  xbmc.translatePath(os.path.join(USERDATA,'addon_data'))
ADDONS       =  xbmc.translatePath(os.path.join('special://home','addons'))
GUI          =  xbmc.translatePath(os.path.join(USERDATA,'guisettings.xml'))
FAVS         =  xbmc.translatePath(os.path.join(USERDATA,'favourites.xml'))
SOURCE       =  xbmc.translatePath(os.path.join(USERDATA,'sources.xml'))
ADVANCED     =  xbmc.translatePath(os.path.join(USERDATA,'advancedsettings.xml'))
RSS          =  xbmc.translatePath(os.path.join(USERDATA,'RssFeeds.xml'))
KEYMAPS      =  xbmc.translatePath(os.path.join(USERDATA,'keymaps','keyboard.xml'))
USB          =  xbmc.translatePath(os.path.join(zip))
skin         =  xbmc.getSkinDir()
HOME         =  xbmc.translatePath('special://home/')
AddonID      ='plugin.video.itv_wizard_kodi'; AddonTitle="Total Wipe"
EXCLUDES     =  ['plugin.video.itv_wizard_kodi','skin.infinitytv']
EXCLUDES_fav =  ['plugin.video.itv_wizard_kodi','skin.infinitytv','addon_data']
mac_url      =  'http://infinitytv.ca/downloads_kodi/mac_address.xml'

USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
ADDON=xbmcaddon.Addon(id='plugin.video.itv_wizard_kodi')

print "############################# Mac Address ######################################"

mac_address = xbmc.getInfoLabel('Network.MacAddress')
if not ":" in mac_address:
    time.sleep(2)
    mac_address = xbmc.getInfoLabel("Network.MacAddress")

html = net.http_GET(mac_url).content

if not mac_address in html:
    dialog.ok('[COLOR red]WRONG DEVICE USED[/COLOR]','Please go to [COLOR blue]www.infinitytv.ca[/COLOR] to see why your purchase device doesn\'t work!')
    print '################ Mac address Failed 1 ######################################'
    xbmc.executebuiltin('Quit')

print "############################# before settings ######################################"

