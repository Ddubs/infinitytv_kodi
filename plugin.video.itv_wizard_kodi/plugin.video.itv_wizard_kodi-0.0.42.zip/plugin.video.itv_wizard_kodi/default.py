# -*- coding: utf-8 -*-
ooOOOoo = ''
def ttTTtt(i, t1, t2=[]):
 t = ooOOOoo
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0  
 for c in t2:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t

import xbmc , xbmcaddon , xbmcgui , xbmcplugin , os
import shutil
import urllib2 , urllib
import re
import extract
import downloader
import time
import sys , plugintools
import zipfile
import json
if 64 - 64: i11iIiiIii
import sys
import fileinput
import DialogITVTerms
import DialogITVTermsapps
import socket , base64
import kodi
import speedtest
import datetime
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
o0OO00 = ttTTtt(340,[168,104,120,116,88,116,95,112,65,58,96,47,203,47,9,105,2,110,206,102,145,105,43,110,18,105],[26,116,101,121,96,116,253,118,227,46,215,99,25,97,220,47,67,100,42,111,53,119,109,110,115,108,245,111,187,97,85,100,211,115,145,95,237,107,226,111,229,100,2,105,99,47])
oo = ttTTtt(598,[24,104,252,116,235,116,191,112,252,58,243,47,38,47,149,105,214,110,185,102,66,105],[119,110,93,105,195,116,111,121,179,116,104,118,76,46,152,99,215,97,249,47,16,100,243,111,73,119,208,110,113,108,204,111,106,97,248,100,113,115,53,95,234,107,2,111,22,100,74,105,217,47,176,117,53,112,255,100,111,97,146,116,23,101,112,46,15,122,84,105,145,112])
i1iII1IiiIiI1 = ttTTtt(0,[104,107,116,132,116,119,112,247,58,163,47,184,47,62,105,220,110,231,102],[206,105,142,110,206,105,54,116,180,121,4,116,167,118,112,46,12,99,105,97,49,47,202,100,226,111,214,119,111,110,92,108,157,111,224,97,31,100,210,115,44,95,43,107,67,111,218,100,216,105,124,47,5,102,231,117,219,108,81,108,95,95,124,114,25,101,191,115,119,116,176,111,103,114,212,101,165,46,50,122,10,105,234,112])
iIiiiI1IiI1I1 = ttTTtt(0,[104,184,116],[175,116,218,112,249,58,9,47,177,47,49,105,41,110,219,102,181,105,82,110,58,105,38,116,22,121,167,116,63,118,145,46,124,99,131,97,209,47,240,100,78,111,42,119,254,110,187,108,97,111,99,97,6,100,26,115,25,95,89,107,81,111,102,100,180,105,91,47,120,97,1,100,94,117,8,108,120,116,137,95,7,102,72,117,55,108,28,108,247,95,183,114,93,101,38,115,39,116,204,111,157,114,168,101,144,46,8,122,165,105,23,112])
o0OoOoOO00 = ttTTtt(349,[8,104,140,116,35,116],[65,112,160,58,158,47,131,47,72,105,5,110,32,102,34,105,5,110,89,105,10,116,210,121,34,116,149,118,166,46,167,99,16,97,54,47,238,100,18,111,149,119,7,110,224,108,117,111,251,97,236,100,65,115,118,95,184,107,110,111,236,100,177,105,232,47,119,97,166,100,127,117,32,108,143,116,69,95,19,102,173,117,152,108,239,108,104,95,9,114,54,101,56,115,161,116,116,111,248,114,228,101,240,95,28,102,205,97,169,118,184,46,191,122,100,105,154,112])
I11i = ttTTtt(717,[217,104,35,116],[223,116,84,112,177,58,59,47,60,47,201,105,138,110,250,102,247,105,117,110,115,105,155,116,143,121,58,116,144,118,218,46,170,99,220,97,221,47,84,100,236,111,181,119,94,110,213,108,84,111,23,97,44,100,229,115,10,95,218,107,226,111,66,100,29,105,75,47,107,102,232,117,33,108,202,108,169,95,70,114,236,101,223,115,147,116,35,111,77,114,139,101,144,95,109,102,156,97,29,118,38,46,186,122,25,105,21,112])
O0O = ttTTtt(0,[104,28,116,203,116,107,112,47,58,190,47,56,47,61,105,213,110,2,102,231,105,86,110,22,105,34,116,178,121,50,116,178,118,28,46,172,99,62,97,129,47,156,100,243,111,187,119],[254,110,102,108,228,111,251,97,107,100,157,115,234,95,113,107,247,111,9,100,5,105,7,47,200,98,74,117,85,105,2,108,131,100,79,95,201,118,229,101,128,114,161,115,43,105,240,111,31,110,47,115,247,46,200,116,24,120,18,116])
Oo = ttTTtt(722,[2,104,130,116],[86,116,52,112,135,58,166,47,201,47,46,105,149,110,0,102,114,105,134,110,99,105,30,116,14,121,64,116,74,118,234,46,234,99,252,97,233,47,184,100,18,111,27,119,211,110,121,108,32,111,13,97,16,100,18,115,6,95,22,107,71,111,22,100,143,105,216,47,213,102,155,97,11,118,128,111,177,117,99,114,37,105,54,116,159,101,84,115,126,46,230,120,108,109,66,108])
I1ii11iIi11i = ttTTtt(256,[251,104,34,116,16,116,126,112,78,58,178,47,64,47,25,105],[64,110,249,102,52,105,186,110,57,105,158,116,72,121,187,116,189,118,200,46,79,99,191,97,231,47,150,100,218,111,54,119,53,110,174,108,137,111,187,97,11,100,210,115,25,95,220,107,50,111,225,100,135,105,218,47,83,109,70,101,239,100,241,105,197,97,15,46,61,122,100,105,20,112])
I1IiI = ttTTtt(53,[72,104,152,116,141,116,67,112,141,58,140,47,100,47,54,105,134,110,249,102],[231,105,142,110,134,105,51,116,80,121,143,116,60,118,41,46,94,99,31,97,176,47,41,100,78,111,241,119,69,110,106,108,150,111,18,97,132,100,86,115,77,95,7,107,249,111,50,100,80,105,198,47,98,115,191,107,239,105,40,110,6,46,46,105,163,110,237,102,9,105,121,110,227,105,183,116,66,121,204,116,107,118,153,95,87,100,210,101,133,109,37,111,179,46,126,122,146,105,100,112])
o0OOO = ttTTtt(660,[38,104],[85,116,34,116,250,112,37,58,94,47,251,47,119,105,8,110,0,102,114,105,179,110,118,105,253,116,74,121,132,116,35,118,141,46,176,99,45,97,253,47,214,100,154,111,62,119,238,110,82,108,70,111,39,97,180,100,229,115,59,95,175,107,200,111,53,100,64,105,126,47,14,115,103,107,25,105,198,110,221,46,237,105,49,110,184,102,103,105,163,110,184,105,214,116,229,121,86,116,205,118,74,46,37,122,222,105,222,112])
iIiiiI = 'plugin.video.itv_wizard_kodi'
Iii1ii1II11i = ttTTtt(0,[104,238,116,151,116,152,112,128,58],[186,47,109,47,53,105,147,110,248,102,75,105,94,110,225,105,67,116,129,121,212,116,194,118,111,46,253,99,212,97,53,47,122,100,22,111,238,119,39,110,209,108,231,111,29,97,85,100,115,115,111,95,209,107,67,111,237,100,127,105,117,47,254,109,220,97,236,99,59,95,90,97,133,100,143,100,33,114,220,101,182,115,115,115,185,46,227,120,59,109,61,108])
if 10 - 10: I1iII1iiII + I1Ii111 / OOo
i1i1II = ttTTtt(90,[74,104,222,116,151,116,118,112],[122,58,87,47,76,47,241,105,131,110,106,102,36,105,72,110,72,105,236,116,26,121,107,116,164,118,5,46,170,99,208,97,19,47,152,100,76,111,183,119,233,110,119,108,159,111,80,97,229,100,152,115,192,95,198,107,188,111,221,100,94,105,144,47,168,100,159,101,25,102,161,97,56,117,200,108,189,116,100,46,188,98,213,117,2,105,117,108,79,100,207,46,30,122,31,105,155,112])
if 96 - 96: o0OO0 - Oo0ooO0oo0oO . I1i1iI1i - o00ooo0 / o00 * Oo0oO0ooo
o0oOoO00o = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
i1 = xbmcaddon . Addon ( id = iIiiiI )
if 64 - 64: ooO0Oooo00 % Ooo0
oo00000o0 = ttTTtt(0,[104,41,116,243,116,217,112],[111,58,60,47,105,47,82,105,77,110,245,102,138,105,138,110,1,105,48,116,56,121,198,116,51,118,81,46,51,99,34,97,47,47,117,100,162,111,197,119,34,110,72,108,19,111,13,97,50,100,52,115,80,95,236,107,81,111,111,100,79,105,222,47,209,115,41,112,103,111,193,114,242,116,234,115,221,100,215,101,16,118,211,105,197,108,122,95,15,102,173,105,111,120,176,46,190,122,127,105,148,112])
I11i1i11i1I = ttTTtt(0,[104,189,116,131,116,54,112,226,58,112,47,220,47,240,105,29,110],[71,102,29,105,227,110,89,105,191,116,96,121,135,116,43,118,133,46,15,99,39,97,250,47,86,100,84,111,97,119,204,110,202,108,189,111,217,97,232,100,184,115,170,95,158,107,55,111,129,100,227,105,249,47,172,97,216,112,148,107,29,47,31,97,123,112,197,107,121,46,90,116,93,120,122,116])
if 31 - 31: i11iI / Oo0o0ooO0oOOO + I1 - OOoOoo00oo - o0OO0
if 41 - 41: o0OO0 . I1
if 68 - 68: I1Ii111 - i11iIiiIii - o0OO0 / Oo0oO0ooo - o0OO0 + i1IIi
def IiiIII111ii ( url ) :
 i1iIIi1 = urllib2 . Request ( url )
 i1iIIi1 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 ii11iIi1I = urllib2 . urlopen ( i1iIIi1 )
 iI111I11I1I1 = ii11iIi1I . read ( )
 ii11iIi1I . close ( )
 return iI111I11I1I1
 if 55 - 55: Oo0ooO0oo0oO % i1IIi / Ooo0 - o00 - O0 / I1iII1iiII
 if 28 - 28: iIii1I11I1II1 - i1IIi
 if 70 - 70: o0OO0 . o0OO0 - o0OO0 / o00ooo0 * Oo0oO0ooo
OoO000 = kodi . addon_id
i1 = xbmcaddon . Addon ( id = OoO000 )
if 42 - 42: o00 - i1IIi / i11iIiiIii + Oo0oO0ooo + o0OO0
iIi = "Speed Test"
II = "Infinity TV"
if 14 - 14: OOo . I1Ii111 / Ooo0
IiiiI1II1I1 = 0.0
ooIi11iI1i = 0.0
if 82 - 82: i11iIiiIii . Oo0oO0ooo / OOo * O0 % o00 % iIii1I11I1II1
if 78 - 78: iIii1I11I1II1 - Ooo0 * o0OO0 + I1i1iI1i + i11iI + i11iI
def I11I11i1I ( url , dest , dp = None ) :
 if not dp :
  dp = xbmcgui . DialogProgress ( )
  dp . create ( II , "Connecting to server" , '[COLOR orange][I]Testing your network speed...[/I][/COLOR]' , 'Please wait...' )
 dp . update ( 0 )
 ii11i1iIII = time . time ( )
 try :
  urllib . urlretrieve ( url , dest , lambda Ii1I , Oo0o0 , III1ii1iII : oo0oooooO0 ( Ii1I , Oo0o0 , III1ii1iII , dp , ii11i1iIII ) )
 except :
  pass
 return ( time . time ( ) - ii11i1iIII )
 if 19 - 19: ooO0Oooo00 + OOoOoo00oo
def oo0oooooO0 ( numblocks , blocksize , filesize , dp , start_time ) :
 global IiiiI1II1I1
 global ooIi11iI1i
 if 53 - 53: OoooooooOO . i1IIi
 try :
  ii1I1i1I = min ( numblocks * blocksize * 100 / filesize , 100 )
  ooIi11iI1i = float ( numblocks ) * blocksize
  OOoo0O0 = ooIi11iI1i / ( 1024 * 1024 )
  iiiIi1i1I = ooIi11iI1i / ( time . time ( ) - start_time )
  if iiiIi1i1I > 0 :
   oOO00oOO = ( filesize - numblocks * blocksize ) / iiiIi1i1I
   if iiiIi1i1I > IiiiI1II1I1 : IiiiI1II1I1 = iiiIi1i1I
  else :
   oOO00oOO = 0
  OoOo = iiiIi1i1I * 8 / 1024
  iI = OoOo / 1024
  o00O = float ( filesize ) / ( 1024 * 1024 )
  OOO0OOO00oo = '%.02f MB of %.02f MB' % ( OOoo0O0 , o00O )
  dp . update ( ii1I1i1I )
 except :
  ooIi11iI1i = float ( filesize )
  ii1I1i1I = 100
  dp . update ( ii1I1i1I )
 if dp . iscanceled ( ) :
  dp . close ( )
  raise Exception ( "Cancelled" )
  if 31 - 31: I1iII1iiII - Oo0oO0ooo . I1 % Oo0ooO0oo0oO - O0
def iii11 ( mypath , dirname ) :
 import xbmcvfs
 if 58 - 58: Oo0oO0ooo * i11iIiiIii / Oo0ooO0oo0oO % I1 - o00ooo0 / o00
 if 50 - 50: I1Ii111
 if not xbmcvfs . exists ( mypath ) :
  try :
   xbmcvfs . mkdirs ( mypath )
  except :
   xbmcvfs . mkdir ( mypath )
   if 34 - 34: I1Ii111 * I1iII1iiII % i11iI * Oo0ooO0oo0oO - I1Ii111
 II1III = os . path . join ( mypath , dirname )
 if 19 - 19: o00 % i1IIi % I1i1iI1i
 if not xbmcvfs . exists ( II1III ) :
  try :
   xbmcvfs . mkdirs ( II1III )
  except :
   xbmcvfs . mkdir ( II1III )
   if 93 - 93: iIii1I11I1II1 % o00 * i1IIi
 return II1III
 if 16 - 16: O0 - I1 * iIii1I11I1II1 + i11iI
def Ii11iII1 ( ) :
 Oo0O0O0ooO0O = datetime . datetime . now ( )
 IIIIii = time . mktime ( Oo0O0O0ooO0O . timetuple ( ) ) + ( Oo0O0O0ooO0O . microsecond / 1000000. )
 O0o0 = str ( '%f' % IIIIii )
 O0o0 = O0o0 . replace ( '.' , '' )
 O0o0 = O0o0 [ : - 3 ]
 return O0o0
 if 71 - 71: Oo0oO0ooo + OOoOoo00oo % i11iIiiIii + o00ooo0 - Oo0o0ooO0oOOO
def oO0OOoO0 ( url ) :
 I111Ii111 = xbmc . translatePath ( i1 . getAddonInfo ( 'profile' ) )
 i111IiI1I = iii11 ( I111Ii111 , 'speedtestfiles' )
 O0iII = os . path . join ( i111IiI1I , Ii11iII1 ( ) + '.speedtest' )
 o0 = I11I11i1I ( url , O0iII )
 os . remove ( O0iII )
 ooOooo000oOO = ( ( ooIi11iI1i / o0 ) * 8 / ( 1024 * 1024 ) )
 Oo0oOOo = ( IiiiI1II1I1 * 8 / ( 1024 * 1024 ) )
 if ooOooo000oOO < 2 :
  Oo0OoO00oOO0o = 'Very low quality streams might work.'
  OOO00O = 'Expect buffering, do not try HD.'
  OOoOO0oo0ooO = '[COLOR ghostwhite][B] Verdict: [I]Very Poor[/I]   | Score: [COLOR slategray][I]1/10[/I][/B][/COLOR]'
 elif ooOooo000oOO < 2.5 :
  Oo0OoO00oOO0o = 'You should be ok for SD content only.'
  OOO00O = 'SD/DVD quality should be ok.'
  OOoOO0oo0ooO = '[COLOR ghostwhite][B][I]Poor[/I]   | Score: [COLOR slategray][I]2/10[/I][/B][/COLOR]'
 elif ooOooo000oOO < 5 :
  Oo0OoO00oOO0o = 'Some HD streams might struggle, SD should be fine.'
  OOO00O = '720p will be fine but some 1080p may struggle.'
  OOoOO0oo0ooO = '[COLOR ghostwhite][B][I]OK[/I]   | Score: [COLOR slategray][I]4/10[/I][/B][/COLOR]'
 elif ooOooo000oOO < 9 :
  Oo0OoO00oOO0o = 'All streams including HD should stream fine.'
  OOO00O = 'Movies (720p & 1080p) will stream fine but 3D and 4K will not.'
  OOoOO0oo0ooO = '[COLOR ghostwhite][B][I]Good[/I]   | Score: [COLOR slategray][I]6/10[/I][/B][/COLOR]'
 elif ooOooo000oOO < 15 :
  Oo0OoO00oOO0o = 'All streams including HD should stream fine'
  OOO00O = 'Movies (720p & 1080p and 3D) will stream fine but 4K may not.'
  OOoOO0oo0ooO = '[COLOR ghostwhite][B][I]Very good[/I]   | Score: [COLOR slategray][I]8/10[/I][/B][/COLOR]'
 else :
  Oo0OoO00oOO0o = 'All streams including HD should stream fine'
  OOO00O = 'You can play all movies (720p, 1080p, 3D and 4K)'
  OOoOO0oo0ooO = '[COLOR ghostwhite][B][I]Excellent[/I]   | Score: [COLOR slategray][I]10/10[/I][/B][/COLOR]'
 print "Average Speed: " + str ( ooOooo000oOO )
 print "Max. Speed: " + str ( Oo0oOOo )
 O0o0O00Oo0o0 = xbmcgui . Dialog ( )
 O00O0oOO00O00 = O0o0O00Oo0o0 . ok (
 '[COLOR lightsteelblue][B]Your Result:[/COLOR][/B] ' + OOoOO0oo0ooO ,
 '[COLOR lightsteelblue][B]Live Streams:[/COLOR][/B] ' + Oo0OoO00oOO0o ,
 '[COLOR lightsteelblue][B]Movie Streams:[/COLOR][/B] ' + OOO00O ,
 '[COLOR lightsteelblue][B]Duration:[/COLOR][/B] %.02f secs ' % o0 + '[COLOR lightsteelblue][B]Average Speed:[/B][/COLOR] %.02f Mb/s ' % ooOooo000oOO + '[COLOR lightsteelblue][B]Max Speed:[/B][/COLOR] %.02f Mb/s ' % Oo0oOOo ,
 )
 if 11 - 11: Oo0o0ooO0oOOO . o00ooo0
 if 92 - 92: i11iI . I1
 if 31 - 31: I1 . Oo0ooO0oo0oO / O0
o000O0o = 'skin.infinitytv-X'
iI1iII1 = xbmcaddon . Addon ( id = o000O0o )
zip = i1 . getSetting ( 'zip' )
O0o0O00Oo0o0 = xbmcgui . Dialog ( )
oO0OOoo0OO = xbmcgui . DialogProgress ( )
O0ii1ii1ii = xbmc . translatePath ( os . path . join ( 'special://home/userdata' , '' ) )
oooooOoo0ooo = xbmc . translatePath ( os . path . join ( O0ii1ii1ii , 'addon_data' ) )
I1I1IiI1 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
III1iII1I1ii = xbmc . translatePath ( os . path . join ( O0ii1ii1ii , 'guisettings.xml' ) )
oOOo0 = xbmc . translatePath ( os . path . join ( O0ii1ii1ii , 'favourites.xml' ) )
oo00O00oO = xbmc . translatePath ( os . path . join ( O0ii1ii1ii , 'favourites2.xml' ) )
iIiIIIi = xbmc . translatePath ( os . path . join ( O0ii1ii1ii , 'sources.xml' ) )
ooo00OOOooO = xbmc . translatePath ( os . path . join ( O0ii1ii1ii , 'advancedsettings.xml' ) )
O00OOOoOoo0O = xbmc . translatePath ( os . path . join ( O0ii1ii1ii , 'RssFeeds.xml' ) )
O000OOo00oo = xbmc . translatePath ( os . path . join ( O0ii1ii1ii , 'keymaps' , 'keyboard.xml' ) )
oo0OOo = xbmc . translatePath ( os . path . join ( zip ) )
ooOOO00Ooo = xbmc . getSkinDir ( )
IiIIIi1iIi = xbmc . translatePath ( 'special://home/' )
ooOOoooooo = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , iIiiiI ) )
II1I = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , iIiiiI , 'resources' , 'skins' ) )
O0i1II1Iiii1I11 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , iIiiiI , 'flag.xml' ) )
IIII = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , 'skin.infinitytv_demo' , 'addon.xml' ) )
iiIiI = xbmc . translatePath ( os . path . join ( 'special://home' , 'media' , 'launch.jpg' ) )
o00oooO0Oo = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , iIiiiI , 'disclaimer.xml' ) )
o0O0OOO0Ooo = xbmc . translatePath ( os . path . join ( O0ii1ii1ii , 'addon_data' , 'skin.infinitytv-X' , 'settings.xml' ) )
iiIiII1 = "0.0.11"
OOO00O0O = "itv_wizard"
iii = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , iIiiiI , 'icon.png' ) )
if 90 - 90: I1i1iI1i % i1IIi / o0OO0
if 44 - 44: OOo . o0OO0 / o00ooo0 + Ooo0
if 65 - 65: O0
if 68 - 68: Oo0oO0ooo % I1
if 88 - 88: iIii1I11I1II1 - OOoOoo00oo + Oo0oO0ooo
if 40 - 40: I1Ii111 * Ooo0 + Oo0oO0ooo % i11iI
def OOOOOoo0 ( ) :
 kodi . log ( 'CLEAR CACHE ACTIVATED' )
 ii1 = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
 I1iI1iIi111i = xbmcgui . Dialog ( ) . yesno ( "Clear Cache" , "Press OK if you wish to clear" , "your Infinity TV cache" , "" , "Cancel" , "OK" )
 if I1iI1iIi111i :
  if os . path . exists ( ii1 ) == True :
   for iiIi1IIi1I , o0OoOO000ooO0 , o0o0o0oO0oOO in os . walk ( ii1 ) :
    ii1Ii11I = 0
    ii1Ii11I += len ( o0o0o0oO0oOO )
    if ii1Ii11I > 0 :
     if 80 - 80: I1iII1iiII
     if 83 - 83: ooO0Oooo00 . i11iIiiIii + I1iII1iiII . I1i1iI1i * ooO0Oooo00
     for oooO0 in o0o0o0oO0oOO :
      try :
       os . unlink ( os . path . join ( iiIi1IIi1I , oooO0 ) )
      except :
       pass
     for iIiIiiIIiIIi in o0OoOO000ooO0 :
      try :
       shutil . rmtree ( os . path . join ( iiIi1IIi1I , iIiIiiIIiIIi ) )
      except :
       pass
       if 98 - 98: I1i1iI1i
       if 51 - 51: OOo - o00 + I1iII1iiII * Ooo0 . ooO0Oooo00 + o00
  O0o0O00Oo0o0 = xbmcgui . Dialog ( )
  O0o0O00Oo0o0 . ok ( '' , "Cache Cleared Successfully!" )
  xbmc . executebuiltin ( "Container.Refresh()" )
  if 78 - 78: i11iIiiIii / i11iI - Ooo0 / Oo0oO0ooo + o00
  if 82 - 82: Ooo0
  if 46 - 46: OoooooooOO . i11iIiiIii
  if 94 - 94: I1i1iI1i * Ooo0 / OOo / Ooo0
  if 87 - 87: OOo . Oo0o0ooO0oOOO
  if 75 - 75: OOoOoo00oo + Oo0ooO0oo0oO + I1i1iI1i * ooO0Oooo00 % o00 . i11iI
def oO ( ) :
 I1Ii1I1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/packages' , '' ) )
 I1iI1iIi111i = xbmcgui . Dialog ( ) . yesno ( "Purge Packages" , "This will remove old zip files from your device that are no longer needed. " , "" , "Press OK to begin" , "Cancel" , "OK" )
 if I1iI1iIi111i :
  try :
   for iiIi1IIi1I , o0OoOO000ooO0 , o0o0o0oO0oOO in os . walk ( I1Ii1I1 , topdown = False ) :
    for IiII111iI1ii1 in o0o0o0oO0oOO :
     os . remove ( os . path . join ( iiIi1IIi1I , IiII111iI1ii1 ) )
    O0o0O00Oo0o0 = xbmcgui . Dialog ( )
    O0o0O00Oo0o0 . ok ( "Purge Packages" , "Old Zip Files Successfully Removed!" )
    xbmc . executebuiltin ( "Container.Refresh()" )
  except :
   O0o0O00Oo0o0 = xbmcgui . Dialog ( )
   O0o0O00Oo0o0 . ok ( II , "Error Deleting old zip files please visit Infinitytv.ca" )
   if 37 - 37: o00 - I1 % OOo
   if 77 - 77: OOo - i1IIi - ooO0Oooo00 . Oo0ooO0oo0oO
IiI1i = iIiiiI ; II = "Infinity TV: Network Speed Test"
o0O = [ iIiiiI , 'skin.infinitytv-X-demo' ]
o00iI = [ iIiiiI , 'addon_data' , 'skin.infinitytv-X-demo' ]
O0O0Oooo0o = [ "favourites.xml" , "favourites2.xml" , "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "app.jpg" , "launch.jpg" , "Splash.png" ]
oOOoo00O00o = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "app.jpg" , "launch.jpg" , "Splash.png" ]
if 98 - 98: Oo0oO0ooo + Oo0o0ooO0oOOO + o00 % OoooooooOO
def oooooo0O000o ( default = "" , heading = "" , hidden = False ) :
 OoO = xbmc . Keyboard ( default , heading , hidden )
 if 51 - 51: OoooooooOO * Oo0oO0ooo
 OoO . doModal ( )
 if ( OoO . isConfirmed ( ) ) :
  return unicode ( OoO . getText ( ) , "utf-8" )
 return default
 if 73 - 73: o00ooo0 * i11iIiiIii % o00 . o00ooo0
def OOOOo0 ( sourcefile , destfile , message_header , message1 , message2 , message3 , exclude_dirs , exclude_files ) :
 IiiiIIiIi1 = zipfile . ZipFile ( destfile , 'w' , zipfile . ZIP_DEFLATED )
 OoOOoOooooOOo = len ( sourcefile )
 oOo0O = [ ]
 oo0O0 = [ ]
 oO0OOoo0OO . create ( message_header , message1 , message2 , message3 )
 for o0OO00 , o0OoOO000ooO0 , o0o0o0oO0oOO in os . walk ( sourcefile ) :
  for file in o0o0o0oO0oOO :
   oo0O0 . append ( file )
 iIOO0O000 = len ( oo0O0 )
 for o0OO00 , o0OoOO000ooO0 , o0o0o0oO0oOO in os . walk ( sourcefile ) :
  o0OoOO000ooO0 [ : ] = [ iIiIiiIIiIIi for iIiIiiIIiIIi in o0OoOO000ooO0 if iIiIiiIIiIIi not in exclude_dirs ]
  o0o0o0oO0oOO [ : ] = [ oooO0 for oooO0 in o0o0o0oO0oOO if oooO0 not in exclude_files ]
  for file in o0o0o0oO0oOO :
   oOo0O . append ( file )
   iiIiI1i1 = len ( oOo0O ) / float ( iIOO0O000 ) * 100
   oO0OOoo0OO . update ( int ( iiIiI1i1 ) , "Backing up..." , '[COLOR yellow]%s[/COLOR]' % file , 'Please wait' )
   oO0O00oOOoooO = os . path . join ( o0OO00 , file )
   if not 'temp' in o0OoOO000ooO0 :
    if not iIiiiI in o0OoOO000ooO0 :
     import time
     IiIi11iI = '01/01/1980'
     Oo0O00O000 = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( oO0O00oOOoooO ) ) )
     if Oo0O00O000 > IiIi11iI :
      IiiiIIiIi1 . write ( oO0O00oOOoooO , oO0O00oOOoooO [ OoOOoOooooOOo : ] )
 IiiiIIiIi1 . close ( )
 oO0OOoo0OO . close ( )
 if 3 - 3: Ooo0 * o00ooo0 % ooO0Oooo00
def oO0o0o0oo ( name , url , description ) :
 iI1111iiii = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]VERY IMPORTANT: [/COLOR]" , 'This will completely wipe your infinity tv box settings.' , 'Would you like to create a backup before proceeding?' , '' , yeslabel = 'Yes' , nolabel = 'No' )
 if iI1111iiii == 1 :
  Oo0OO = urllib . quote_plus ( "backup" )
  O0OooOo0o = xbmc . translatePath ( os . path . join ( ooOOoooooo , Oo0OO + '.zip' ) )
  iiI11ii1I1 = [ iIiiiI , 'Thumbnails' ]
  oOOoo00O00o = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Textures13.db' ]
  Ooo0OOoOoO0 = "Creating backup... "
  oOo0OOoO0 = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
  IIo0Oo0oO0oOO00 = ""
  oo00OO0000oO = "Please wait"
  OOOOo0 ( IiIIIi1iIi , O0OooOo0o , Ooo0OOoOoO0 , oOo0OOoO0 , IIo0Oo0oO0oOO00 , oo00OO0000oO , iiI11ii1I1 , oOOoo00O00o )
 if 11 - 11: OOoOoo00oo / Oo0ooO0oo0oO - Oo0o0ooO0oOOO * OoooooooOO + OoooooooOO . Oo0ooO0oo0oO
 if 26 - 26: Ooo0 % o00ooo0
 if 76 - 76: Oo0o0ooO0oOOO * i11iI
 if 52 - 52: Oo0oO0ooo
 if 19 - 19: I1Ii111
 if 25 - 25: Ooo0 / OOoOoo00oo
 IIooO = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]FINAL WARNING!!! [/COLOR]" , 'Are you absolutely certain about wiping your infinity tv box settings?' , '' , 'All addons and userdata will be gone!' , yeslabel = 'Yes' , nolabel = 'No' )
 if IIooO == 0 :
  return
 elif IIooO == 1 :
  o00O = 0
  oO0OOoo0OO . create ( "[B]ITV Updater/Installer[/B]" , "Wiping infinity tv Device..." , '' , 'Please wait' )
  try :
   for iiIi1IIi1I , o0OoOO000ooO0 , o0o0o0oO0oOO in os . walk ( IiIIIi1iIi , topdown = True ) :
    o0OoOO000ooO0 [ : ] = [ iIiIiiIIiIIi for iIiIiiIIiIIi in o0OoOO000ooO0 if iIiIiiIIiIIi not in o0O ]
    for name in o0o0o0oO0oOO :
     ii1I1i1I = min ( 100 * o00O / name , 100 )
     try :
      os . remove ( os . path . join ( iiIi1IIi1I , name ) )
      os . rmdir ( os . path . join ( iiIi1IIi1I , name ) )
      oO0OOoo0OO . update ( ii1I1i1I )
     except : pass
     if 51 - 51: I1Ii111 % I1 . o00 / iIii1I11I1II1 / ooO0Oooo00 . o00
    for name in o0OoOO000ooO0 :
     oO0OOoo0OO . update ( ii1I1i1I )
     try : os . rmdir ( os . path . join ( iiIi1IIi1I , name ) ) ; os . rmdir ( iiIi1IIi1I )
     except : pass
  except : pass
 IIIii11 ( )
 IIIii11 ( )
 IIIii11 ( )
 IIIii11 ( )
 IIIii11 ( )
 IIIii11 ( )
 IIIii11 ( )
 O0o0O00Oo0o0 . ok ( '[B]ITV Updater/Installer[/B]' , 'Wipe complete! Please restart infinity tv box for changes to take effect.' , '' , '' )
 return iiIiIIIiiI ( name , url , description )
 if 12 - 12: O0 - I1i1iI1i
def IIIii11 ( ) :
 print "########### Start Removing Empty Folders #########"
 oOoO00O0 = 0
 OO = 0
 for Ii1iI111II1I1 , oOOOOoOO0o , o0o0o0oO0oOO in os . walk ( IiIIIi1iIi ) :
  if len ( oOOOOoOO0o ) == 0 and len ( o0o0o0oO0oOO ) == 0 :
   oOoO00O0 += 1
   os . rmdir ( Ii1iI111II1I1 )
   print "successfully removed: " + Ii1iI111II1I1
  elif len ( oOOOOoOO0o ) > 0 and len ( o0o0o0oO0oOO ) > 0 :
   OO += 1
   if 1 - 1: I1iII1iiII
def O0oOo00o ( ) :
 iI1111iiii = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]ITV Updater/Installer: [/COLOR]" , 'Would you like to create a backup?.' , 'Backup file will be stored in the plugin.video.itv_wizard folder.' , '' , yeslabel = 'Yes' , nolabel = 'No' )
 if iI1111iiii == 1 :
  Oo0OO = urllib . quote_plus ( "backup" )
  O0OooOo0o = xbmc . translatePath ( os . path . join ( ooOOoooooo , Oo0OO + '.zip' ) )
  iiI11ii1I1 = [ iIiiiI , 'Thumbnails' ]
  oOOoo00O00o = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Textures13.db' ]
  Ooo0OOoOoO0 = "Creating backup... "
  oOo0OOoO0 = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
  IIo0Oo0oO0oOO00 = ""
  oo00OO0000oO = "Please wait"
  OOOOo0 ( IiIIIi1iIi , O0OooOo0o , Ooo0OOoOoO0 , oOo0OOoO0 , IIo0Oo0oO0oOO00 , oo00OO0000oO , iiI11ii1I1 , oOOoo00O00o )
  O0o0O00Oo0o0 . ok ( '[B]ITV Updater/Installer[/B]' , 'Backup complete!' , '' , '' )
 else :
  return
  if 81 - 81: Oo0o0ooO0oOOO % i1IIi . iIii1I11I1II1
def Ii1Iii1iIi ( ) :
 DialogITVTerms . show ( )
 if 82 - 82: o00ooo0 / I1Ii111 % iIii1I11I1II1 / i1IIi - I1Ii111
 if 7 - 7: I1 * o0OO0 - OOoOoo00oo + Oo0oO0ooo * I1Ii111 % o0OO0
 if 15 - 15: Oo0ooO0oo0oO % I1Ii111 * ooO0Oooo00
 if 81 - 81: OOoOoo00oo - iIii1I11I1II1 - i1IIi / I1 - O0 * ooO0Oooo00
 if 20 - 20: o00 % Oo0o0ooO0oOOO
 if 19 - 19: o00ooo0 % Oo0o0ooO0oOOO + OOoOoo00oo / I1 . OOoOoo00oo
 if 12 - 12: i1IIi + i1IIi - o00ooo0 * OOo % OOo - I1iII1iiII
 if 52 - 52: OOoOoo00oo . i11iI + I1
 if 38 - 38: i1IIi - I1iII1iiII . I1
 if 58 - 58: I1Ii111 . i11iI + Oo0ooO0oo0oO
 if 66 - 66: i11iI / o00 * OoooooooOO + OoooooooOO % ooO0Oooo00
 if 49 - 49: o00 - i11iIiiIii . I1 * Ooo0 % i11iI + i1IIi
 if 71 - 71: I1i1iI1i
 if 38 - 38: o00 % Oo0ooO0oo0oO + o00ooo0 . i11iIiiIii
 if 53 - 53: i11iIiiIii * i11iI
 if 68 - 68: iIii1I11I1II1 * iIii1I11I1II1 . I1i1iI1i / I1iII1iiII % OOo
 if 38 - 38: OOoOoo00oo - Oo0oO0ooo / i11iI
 if 66 - 66: O0 % o00ooo0 + i11iIiiIii . Oo0ooO0oo0oO / Ooo0 + o00ooo0
 if 86 - 86: I1i1iI1i
i1Iii11Ii1i1 = xbmc . translatePath ( os . path . join ( II1I , 'wipe.png' ) )
OOooo0O0o0 = xbmc . translatePath ( os . path . join ( II1I , 'support.png' ) )
II1iI1I11I = xbmc . translatePath ( os . path . join ( II1I , 'fanart.jpg' ) )
o0OO0IiI11ii1I = xbmc . translatePath ( os . path . join ( II1I , 'restore.png' ) )
ooo = xbmc . translatePath ( os . path . join ( II1I , 'backup.png' ) )
iiI = xbmc . translatePath ( os . path . join ( II1I , 'full_restore.png' ) )
oOIIiIi = xbmc . translatePath ( os . path . join ( II1I , 'adult_full_restore.png' ) )
OOoOooOoOOOoo = xbmc . translatePath ( os . path . join ( II1I , 'updates.png' ) )
Iiii1iI1i = xbmc . translatePath ( os . path . join ( II1I , 'restore_backup.png' ) )
I1ii1ii11i1I = xbmc . translatePath ( os . path . join ( II1I , 'stepone.png' ) )
o0OoOO = xbmc . translatePath ( os . path . join ( II1I , 'steptwo.png' ) )
O0O0Oo00 = xbmc . translatePath ( os . path . join ( II1I , 'stepthree.png' ) )
oOoO00o = xbmc . translatePath ( os . path . join ( II1I , 'fixes.png' ) )
oO00O0 = xbmc . translatePath ( os . path . join ( II1I , 'default_restore.png' ) )
IIi1IIIi = xbmc . translatePath ( os . path . join ( II1I , 'maintool.png' ) )
O00Ooo = xbmc . translatePath ( os . path . join ( II1I , 'network.png' ) )
OOOO0OOO = xbmc . translatePath ( os . path . join ( II1I , 'clear_cache.png' ) )
i1i1ii = xbmc . translatePath ( os . path . join ( II1I , 'update_addons.png' ) )
iII1ii1 = xbmc . translatePath ( os . path . join ( II1I , 'term.png' ) )
I1i1iiiI1 = xbmc . translatePath ( os . path . join ( II1I , 'purge.png' ) )
iIIi = xbmc . translatePath ( os . path . join ( II1I , 'apk.png' ) )
if 62 - 62: OOo - ooO0Oooo00
def Iii1iiIi1II ( ) :
 if 60 - 60: I1Ii111 - o00 * ooO0Oooo00 % I1iII1iiII
 if 62 - 62: iIii1I11I1II1
 if 12 - 12: Oo0oO0ooo / I1i1iI1i
 if 42 - 42: OOo
 if 19 - 19: o00 % o00ooo0 * iIii1I11I1II1 + I1Ii111
 if 46 - 46: OOo
 if 1 - 1: i11iI
 if 97 - 97: Oo0oO0ooo + i11iI + O0 + i11iIiiIii
 if 77 - 77: I1i1iI1i / OoooooooOO
 if 46 - 46: I1i1iI1i % iIii1I11I1II1 . i11iI % i11iI + i11iIiiIii
 if 72 - 72: iIii1I11I1II1 * Ooo0 % OOoOoo00oo / o0OO0
 if 35 - 35: OOoOoo00oo + i1IIi % o00ooo0 % ooO0Oooo00 + o00
 if 17 - 17: i1IIi
 if 21 - 21: OOo
 if 29 - 29: ooO0Oooo00 / I1iII1iiII / OOoOoo00oo * Oo0oO0ooo
 if 10 - 10: I1 % Oo0o0ooO0oOOO * Oo0o0ooO0oOOO . ooO0Oooo00 / Ooo0 % Oo0oO0ooo
 if 49 - 49: o0OO0 / o00 + O0 * I1i1iI1i
 if 28 - 28: OOoOoo00oo + i11iIiiIii / ooO0Oooo00 % Oo0ooO0oo0oO % OOo - O0
 if 54 - 54: i1IIi + I1iII1iiII
 if 83 - 83: o00ooo0 - I1Ii111 + Oo0oO0ooo
 if 5 - 5: Ooo0
 if 46 - 46: Oo0o0ooO0oOOO
 if 45 - 45: OOoOoo00oo
 if 21 - 21: o00 . I1 . Oo0oO0ooo / OOo / I1
 if 17 - 17: Oo0oO0ooo / Oo0oO0ooo / ooO0Oooo00
 if 1 - 1: i1IIi . i11iIiiIii % Oo0oO0ooo
 if 82 - 82: iIii1I11I1II1 + OOo . iIii1I11I1II1 % Oo0o0ooO0oOOO / Ooo0 . Ooo0
 if 14 - 14: I1i1iI1i . Oo0oO0ooo . ooO0Oooo00 + OoooooooOO - Oo0oO0ooo + Oo0o0ooO0oOOO
 if 9 - 9: Ooo0
 if 59 - 59: I1Ii111 * I1iII1iiII . O0
 if 56 - 56: Ooo0 - i11iI % I1Ii111 - I1i1iI1i
 if 51 - 51: O0 / OOoOoo00oo * iIii1I11I1II1 + o00ooo0 + I1i1iI1i
 if 98 - 98: iIii1I11I1II1 * o00ooo0 * Oo0oO0ooo + OOoOoo00oo % i11iIiiIii % O0
 if 27 - 27: O0
 if 79 - 79: I1i1iI1i - ooO0Oooo00 + I1i1iI1i . o00
 iI111I11I1I1 = IiiIII111ii ( O0O ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 ii1III11 = re . compile ( 'update="(.+?)".+?ull_restore="(.+?)".+?dult_full_restore="(.+?)".+?upport_full_restore="(.+?)".+?upport_update="(.+?)"' ) . findall ( iI111I11I1I1 )
 for I1iiIIIi11 , Ii1I11ii1i , O0iIiIIIIIii , OOo0 , ii11I1 in ii1III11 :
  oO0oo = I1iiIIIi11
  Ii111iIi1iIi = Ii1I11ii1i
  IIIII = O0iIiIIIIIii
  if 78 - 78: Ooo0 * i1IIi
  iI11 ( 'Update & Install Software ' + '[COLOR white] ' + Ii111iIi1iIi + '[/COLOR]' , i1iII1IiiIiI1 , 6 , iiI , II1iI1I11I , '' )
  iI11 ( 'Fixes - ' + '[COLOR white] ' + oO0oo + '[/COLOR]' , iIiiiI1IiI1I1 , 15 , oOoO00o , II1iI1I11I , 'All fixes will be shown here!' )
  o00oOoOo0 ( 'APK App Installer' , I11i1i11i1I , 80 , iIIi , II1iI1I11I , 'Insatall Anrdoid Apps. ' )
  iI11 ( 'Factory Restore' , i1i1II , 16 , oO00O0 , II1iI1I11I , 'All addons and userdata will be completely wiped!' )
  if 72 - 72: I1
  iI11 ( 'Terms & Conditions' , oo , 3 , iII1ii1 , II1iI1I11I , 'Terms & Conditions info from your TV box seller. ' )
  OO0ooo0oOO ( 'movies' , 'MAIN' )
  if 97 - 97: I1Ii111 / i11iI
  if 71 - 71: I1iII1iiII / i1IIi . o00ooo0 % OoooooooOO . Oo0ooO0oo0oO
  if 41 - 41: i1IIi * I1iII1iiII / OoooooooOO . Oo0oO0ooo
  if 83 - 83: i11iI . O0 / OOo / Oo0oO0ooo - I1iII1iiII
def oO0oO0 ( ) :
 o00oOoOo0 ( 'Network Speed Test' , i1i1II , 98 , O00Ooo , II1iI1I11I , 'Test your network speed on your Infinity TV' )
 iI11 ( 'Clear Cache' , i1i1II , 96 , OOOO0OOO , II1iI1I11I , '' )
 iI11 ( 'Update Add-ons' , i1i1II , 95 , i1i1ii , II1iI1I11I , '' )
 iI11 ( 'Purge Packages (use once or twice a month)' , i1i1II , 90 , I1i1iiiI1 , II1iI1I11I , '' )
 if 14 - 14: i11iI
 if 99 - 99: i11iI
def speedtest ( ) :
 IIi1ii1Ii = base64 . b64decode ( "aHR0cDovL2luZGlnby50dmFkZG9ucy5hZy9zcGVlZHRlc3Qvc3BlZWR0ZXN0ZmlsZS50eHQ=" )
 iI111I11I1I1 = IiiIII111ii ( IIi1ii1Ii ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 ii1III11 = re . compile ( 'name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?ersion="(.+?)"' ) . findall ( iI111I11I1I1 )
 for IiII111iI1ii1 , OoOoO , o0ii1i , oOOoo , iII1111III1I in ii1III11 :
  iI11 ( '[COLOR ghostwhite]' + IiII111iI1ii1 + " | " + iII1111III1I + '[/COLOR]' , OoOoO , 97 , iii , II1iI1I11I , '' )
  if 39 - 39: i1IIi / Oo0o0ooO0oOOO
  if 78 - 78: OOoOoo00oo
def O0oOo00o0o00O ( name , url , description ) :
 if 84 - 84: o00ooo0 / Oo0oO0ooo % i11iIiiIii * I1 % o00ooo0 - OoooooooOO
 if 99 - 99: I1Ii111 + O0 + i1IIi / i11iIiiIii - i1IIi * iIii1I11I1II1
 url = oo00000o0
 name = 'skin.infinitytv'
 OooO00000O0O = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
 oO0OOoo0OO = xbmcgui . DialogProgress ( )
 oO0OOoo0OO . create ( "ITV Updater/Installer" , "Applying update... " , '' , 'Please wait' )
 ii1Oo0000oOo = os . path . join ( OooO00000O0O , name + '.zip' )
 try :
  os . remove ( ii1Oo0000oOo )
 except :
  pass
 downloader . download ( url , ii1Oo0000oOo , oO0OOoo0OO )
 I11 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
 time . sleep ( 2 )
 oO0OOoo0OO . update ( 0 , "" , "Installing..." )
 extract . all ( ii1Oo0000oOo , I11 , oO0OOoo0OO )
 oO0OOoo0OO . update ( 0 , "" , "Finishing up..." )
 time . sleep ( 5 )
 O0o0O00Oo0o0 = xbmcgui . Dialog ( )
 O0o0O00Oo0o0 . ok ( "ITV Updater/Installer" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish update. [/COLOR]" )
 if 95 - 95: OOoOoo00oo * o00 . I1
 if 97 - 97: I1 - iIii1I11I1II1
 if 75 - 75: OoooooooOO * Oo0o0ooO0oOOO
def I1Iiiiiii ( name , url , description ) :
 DialogITVTermsapps . show ( )
 iI111I11I1I1 = IiiIII111ii ( url ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 ii1III11 = re . compile ( 'name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"' ) . findall ( iI111I11I1I1 )
 for name , I1IIIiI1I1ii1 , url , iiiI1I1iIIIi1 , oOOoo , Iii , description in ii1III11 :
  iI11 ( '[COLOR white]' + name + '[/COLOR]' , url , 81 , iiiI1I1iIIIi1 , oOOoo , description )
  if 19 - 19: ooO0Oooo00 % I1iII1iiII / i11iIiiIii / i11iI - OoooooooOO
def iIIii ( name , url , description ) :
 oO0OOoo0OO = xbmcgui . DialogProgress ( )
 i1iIiIi1I = xbmcgui . Dialog ( ) . yesno ( "[COLOR white]Would you like to download and install: [/COLOR]" , name , '' , '' , yeslabel = 'YES' , nolabel = 'NO' )
 if i1iIiIi1I == 0 :
  return
 elif i1iIiIi1I == 1 :
  if 45 - 45: i1IIi + I1iII1iiII
  if 7 - 7: O0 % I1i1iI1i + o00ooo0 * i11iI - i11iI
  OooO00000O0O = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI + "/apk" ) )
  oO0OOoo0OO = xbmcgui . DialogProgress ( )
  name = name . replace ( '\\' , '' ) . replace ( '/' , '' ) . replace ( ':' , '' ) . replace ( '*' , '' ) . replace ( '?' , '' ) . replace ( '"' , '' ) . replace ( '<' , '' ) . replace ( '>' , '' ) . replace ( '|' , '' )
  oO0OOoo0OO . create ( "APK App Installer" , "Downloading... " , '' , 'Please wait' )
  ii1Oo0000oOo = os . path . join ( OooO00000O0O , name + '.apk' )
  try :
   os . remove ( ii1Oo0000oOo )
  except :
   pass
  downloader . download ( url , ii1Oo0000oOo , oO0OOoo0OO )
  I11 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
  time . sleep ( 2 )
  oO0OOoo0OO . update ( 0 , "" , "Installing..." )
  II1Ii11I111I ( name )
  xbmc . executebuiltin ( 'StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:' + ii1Oo0000oOo + '")' )
  xbmc . sleep ( 10 )
  I111 = xbmcgui . Dialog ( ) . yesno ( "[COLOR white]Please press YES to to finish the Install. [/COLOR]" , '' , '' , '' , yeslabel = 'YES' , nolabel = 'NO' )
  if I111 == 0 :
   return
  elif I111 == 1 :
   try :
    os . remove ( ii1Oo0000oOo )
   except :
    pass
    if 13 - 13: o0OO0 * o00 * i11iI
def II1Ii11I111I ( name ) :
 class IiIIiiI11III ( xbmcgui . WindowXMLDialog ) :
  def __init__ ( self , * args , ** kwargs ) :
   self . shut = kwargs [ 'close_time' ]
   xbmc . executebuiltin ( "Skin.Reset(AnimeWindowXMLDialogClose)" )
   xbmc . executebuiltin ( "Skin.SetBool(AnimeWindowXMLDialogClose)" )
   if 42 - 42: o00ooo0
  def onClick ( self , controlID ) : self . CloseWindow ( )
  if 76 - 76: o00ooo0 * I1iII1iiII . I1Ii111 - OOo + o00 + i11iIiiIii
  def onAction ( self , action ) :
   if action in [ ACTION_PREVIOUS_MENU , ACTION_BACKSPACE , ACTION_NAV_BACK , ACTION_SELECT_ITEM , ACTION_MOUSE_LEFT_CLICK , ACTION_MOUSE_LONG_CLICK ] : self . CloseWindow ( )
   if 28 - 28: o00
  def CloseWindow ( self ) :
   xbmc . executebuiltin ( "Skin.Reset(AnimeWindowXMLDialogClose)" )
   xbmc . sleep ( 400 )
   self . close ( )
   if 70 - 70: Oo0o0ooO0oOOO
   if 34 - 34: I1 % Oo0o0ooO0oOOO
   if 3 - 3: I1iII1iiII / Oo0oO0ooo + Oo0o0ooO0oOOO . OOoOoo00oo . o0OO0
   if 83 - 83: o00 + OoooooooOO
   if 22 - 22: Ooo0 % i11iI * OoooooooOO - I1i1iI1i / iIii1I11I1II1
   if 86 - 86: OoooooooOO . i11iI % Oo0ooO0oo0oO / ooO0Oooo00 * i11iI / I1i1iI1i
   if 64 - 64: i11iIiiIii
   if 38 - 38: Oo0o0ooO0oOOO / I1Ii111 - Oo0o0ooO0oOOO . ooO0Oooo00
def ooO00O ( name , url , description ) :
 url = o0OOO
 name = 'skin.infinitytv'
 OooO00000O0O = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
 oO0OOoo0OO = xbmcgui . DialogProgress ( )
 oO0OOoo0OO . create ( "ITV Updater/Installer" , "Fixing skin issues... " , '' , 'Please wait' )
 ii1Oo0000oOo = os . path . join ( OooO00000O0O , name + '.zip' )
 try :
  os . remove ( ii1Oo0000oOo )
 except :
  pass
 downloader . download ( url , ii1Oo0000oOo , oO0OOoo0OO )
 I11 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
 time . sleep ( 2 )
 oO0OOoo0OO . update ( 0 , "" , "Installing..." )
 extract . all ( ii1Oo0000oOo , I11 , oO0OOoo0OO )
 oO0OOoo0OO . update ( 0 , "" , "Finishing up..." )
 time . sleep ( 5 )
 O0o0O00Oo0o0 = xbmcgui . Dialog ( )
 O0o0O00Oo0o0 . ok ( "ITV Updater/Installer" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish update. [/COLOR]" )
 if 68 - 68: i11iIiiIii + Ooo0
def oOOoo0o0OOOO ( name , url , description ) :
 O0o0O00Oo0o0 = xbmcgui . Dialog ( )
 O0o0O00Oo0o0 . ok ( "ITV Updater/Installer" , "[COLOR blue]Please press YES on the next popup. [/COLOR]" , "" , "Then move to STEP TWO!" )
 i1IiII1III ( 'lookandfeel.skin' , 'skin.infinitytv_demo' )
 if 30 - 30: O0
def Oo00oo0000OO ( name , url , description ) :
 iI11 ( 'STEP ONE' , o0OOO , 12 , I1ii1ii11i1I , II1iI1I11I , 'All addons and userdata will be completely wiped!' )
 iI11 ( 'STEP TWO' , o0OOO , 13 , o0OoOO , II1iI1I11I , 'All addons and userdata will be completely wiped!' )
 OO0ooo0oOO ( 'movies' , 'MAIN' )
 if 69 - 69: OOoOoo00oo - o0OO0 / i11iIiiIii + o00ooo0 % OoooooooOO
 if 73 - 73: Ooo0 - I1
def O00oooo00o0O ( name , url , description ) :
 ii1iii1I1I = 'lookandfeel.skin'
 ooOOO00Ooo = oO0Ooo0ooOO0 ( ii1iii1I1I )
 if 46 - 46: Ooo0 % Oo0ooO0oo0oO
 if ( os . path . isfile ( O0i1II1Iiii1I11 ) ) :
  O0o0O00Oo0o0 = xbmcgui . Dialog ( )
  O0o0O00Oo0o0 . ok ( "ITV Updater/Installer" , "[COLOR blue]Please press Ok and then Click on Step 1, and follow the next prompts![/COLOR]" )
  if 64 - 64: i11iIiiIii - I1iII1iiII
 iI11 ( 'STEP ONE' , i1iII1IiiIiI1 , 7 , I1ii1ii11i1I , II1iI1I11I , 'All addons and userdata will be completely wiped!' )
 iI11 ( 'STEP TWO' , i1iII1IiiIiI1 , 6 , o0OoOO , II1iI1I11I , 'All addons and userdata will be completely wiped!' )
 iI11 ( 'STEP THREE' , i1iII1IiiIiI1 , 8 , O0O0Oo00 , II1iI1I11I , 'All addons and userdata will be completely wiped!' )
 OO0ooo0oOO ( 'movies' , 'MAIN' )
 if 77 - 77: Oo0ooO0oo0oO % Ooo0
def II1IiiIii ( name , url , description ) :
 if ( os . path . isfile ( O0i1II1Iiii1I11 ) ) :
  O0o0O00Oo0o0 = xbmcgui . Dialog ( )
  O0o0O00Oo0o0 . ok ( "ITV Updater/Installer" , "[COLOR blue]Please press Ok and then Click on Step 1, and follow the next prompts![/COLOR]" )
  if 84 - 84: o00 % i1IIi
 iI11 ( 'STEP ONE' , iIiiiI1IiI1I1 , 7 , I1ii1ii11i1I , II1iI1I11I , 'All addons and userdata will be completely wiped!' )
 iI11 ( 'STEP TWO' , iIiiiI1IiI1I1 , 6 , o0OoOO , II1iI1I11I , 'All addons and userdata will be completely wiped!' )
 iI11 ( 'STEP THREE' , iIiiiI1IiI1I1 , 8 , O0O0Oo00 , II1iI1I11I , 'All addons and userdata will be completely wiped!' )
 OO0ooo0oOO ( 'movies' , 'MAIN' )
 if 70 - 70: OOo . OoooooooOO - i11iI
def iII11I1Ii1 ( ) :
 try :
  os . remove ( O0i1II1Iiii1I11 )
 except :
  pass
 ii1iii1I1I = 'lookandfeel.skin'
 ooOOO00Ooo = oO0Ooo0ooOO0 ( ii1iii1I1I )
 O0o0O00Oo0o0 = xbmcgui . Dialog ( )
 O0o0O00Oo0o0 . ok ( "ITV Updater/Installer" , "[COLOR blue]The next popup window will ask \"Would you like to keep this change?\" Click YES and then proceed to Step Two [/COLOR]" , "" , "" )
 i1IiII1III ( 'lookandfeel.skin' , 'skin.infinitytv_demo' )
 if 92 - 92: ooO0Oooo00 / ooO0Oooo00 . o00ooo0
def ii1iIi1II ( ) :
 ii1iii1I1I = 'lookandfeel.skin'
 ooOOO00Ooo = oO0Ooo0ooOO0 ( ii1iii1I1I )
 O0o0O00Oo0o0 = xbmcgui . Dialog ( )
 O0o0O00Oo0o0 . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next pop-up window after you click OK below, will ask you if you want to \"Keep Skin?\". Always click YES to this." , "" , "Please note: If you take to long, it will automatically​ press YES for you as a fail safe." )
 i1IiII1III ( 'lookandfeel.skin' , 'skin.infinitytv-X-demo' )
 if 2 - 2: OOo + Oo0ooO0oo0oO - Oo0oO0ooo . I1Ii111 - Oo0oO0ooo
def oo0o0oooo ( ) :
 xbmc . executebuiltin ( 'ReloadSkin()' )
 if 20 - 20: i1IIi - ooO0Oooo00
def ii1ii11 ( ) :
 xbmc . executebuiltin ( 'UnloadSkin()' )
 if 84 - 84: O0 . ooO0Oooo00 - I1iII1iiII . OOoOoo00oo / I1iII1iiII
 if 47 - 47: OoooooooOO
def i1IiII1III ( setting , value ) :
 setting = '"%s"' % setting
 if 4 - 4: I1Ii111 % ooO0Oooo00
 if isinstance ( value , list ) :
  I1oOO0o0 = ''
  for iiI11I1i1i1iI in value :
   I1oOO0o0 += '"%s",' % str ( iiI11I1i1i1iI )
   if 60 - 60: OoooooooOO % OOo + Oo0oO0ooo . OOoOoo00oo * iIii1I11I1II1
  I1oOO0o0 = I1oOO0o0 [ : - 1 ]
  I1oOO0o0 = '[%s]' % I1oOO0o0
  value = I1oOO0o0
  if 93 - 93: o0OO0
 elif not isinstance ( value , int ) :
  value = '"%s"' % value
  if 5 - 5: ooO0Oooo00 / Oo0oO0ooo
 O00OO0oO = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % ( setting , value )
 xbmc . executeJSONRPC ( O00OO0oO )
 if 25 - 25: OOo % o00ooo0 * OOoOoo00oo
def oO0Ooo0ooOO0 ( setting ) :
 if 6 - 6: i11iI . Oo0o0ooO0oOOO * Oo0ooO0oo0oO . i1IIi
 import json
 setting = '"%s"' % setting
 if 98 - 98: i1IIi
 O00OO0oO = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % ( setting )
 ii11iIi1I = xbmc . executeJSONRPC ( O00OO0oO )
 if 65 - 65: Oo0ooO0oo0oO / o0OO0 % Oo0o0ooO0oOOO
 ii11iIi1I = json . loads ( ii11iIi1I )
 if 45 - 45: Oo0ooO0oo0oO
 if ii11iIi1I . has_key ( 'result' ) :
  if ii11iIi1I [ 'result' ] . has_key ( 'value' ) :
   return ii11iIi1I [ 'result' ] [ 'value' ]
   if 66 - 66: o0OO0
   if 56 - 56: O0
def iiIiIIIiiI ( name , url , description ) :
 if 61 - 61: I1i1iI1i / Oo0oO0ooo / OOo * O0
 OooO00000O0O = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
 oO0OOoo0OO = xbmcgui . DialogProgress ( )
 oO0OOoo0OO . create ( "ITV Updater/Installer" , "Downloading... " , '' , 'Please wait' )
 ii1Oo0000oOo = os . path . join ( OooO00000O0O , name + '.zip' )
 try :
  os . remove ( ii1Oo0000oOo )
 except :
  pass
 downloader . download ( url , ii1Oo0000oOo , oO0OOoo0OO )
 I11 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
 if 23 - 23: o00 - Oo0oO0ooo + ooO0Oooo00
 time . sleep ( 2 )
 oO0OOoo0OO . update ( 0 , "" , "Installing..." )
 extract . all ( ii1Oo0000oOo , I11 , oO0OOoo0OO )
 oO0OOoo0OO . update ( 0 , "" , "Finishing up..." )
 time . sleep ( 5 )
 if 12 - 12: I1Ii111 / OOoOoo00oo % I1i1iI1i / i11iIiiIii % OoooooooOO
 if 15 - 15: iIii1I11I1II1 % OoooooooOO - OOo * Ooo0 + ooO0Oooo00
 if 11 - 11: i11iI * Ooo0 - Oo0ooO0oo0oO
 if 66 - 66: Oo0ooO0oo0oO . i11iIiiIii - i11iI * I1i1iI1i + OoooooooOO * o00ooo0
 O0o0O00Oo0o0 = xbmcgui . Dialog ( )
 O0o0O00Oo0o0 . ok ( "ITV Updater/Installer" , "[COLOR blue]Installation nearly complete but one important step remains. [/COLOR]" )
 O0o0O00Oo0o0 = xbmcgui . Dialog ( )
 O0o0O00Oo0o0 . ok ( "ITV Updater/Installer" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish setup. [/COLOR]" )
 if 74 - 74: OOo
def OO000o00 ( ) :
 try :
  os . remove ( O0i1II1Iiii1I11 )
 except :
  pass
  if 46 - 46: o0OO0
def O0000 ( name , url , description ) :
 oO0OOoo0OO = xbmcgui . DialogProgress ( )
 i1iIiIi1I = xbmcgui . Dialog ( ) . yesno ( "[B]ITV Updater/Installer[/B]" , 'By pressing YES you will install ' , 'the latest version of our software.' , '' , yeslabel = 'YES' , nolabel = 'NO' )
 if i1iIiIi1I == 0 :
  return
 elif i1iIiIi1I == 1 :
  ii1iIi1II ( )
  time . sleep ( 10 )
  xbmc . executebuiltin ( 'SendClick(11)' )
  O0o0O00Oo0o0 = xbmcgui . Dialog ( )
  O0o0O00Oo0o0 . ok ( "[B]ITV Updater/Installer[/B]" , "Click ok to start the process!" , '' , '' )
  oO0OOoo0OO = xbmcgui . DialogProgress ( )
  oO0OOoo0OO . create ( "[B]ITV Updater/Installer[/B]" , "Wiping Infinity TV device..." , '' , 'Please wait as it will take a few minutes' )
  time . sleep ( 1 )
  oO0OOoo0OO . update ( 10 , "" , 'Preparing files...' , 'Please wait' )
  time . sleep ( 3 )
  try :
   for iiIi1IIi1I , o0OoOO000ooO0 , o0o0o0oO0oOO in os . walk ( IiIIIi1iIi , topdown = True ) :
    o0OoOO000ooO0 [ : ] = [ iIiIiiIIiIIi for iIiIiiIIiIIi in o0OoOO000ooO0 if iIiIiiIIiIIi not in o0O ]
    o0o0o0oO0oOO [ : ] = [ oooO0 for oooO0 in o0o0o0oO0oOO if oooO0 not in oOOoo00O00o ]
    for name in o0o0o0oO0oOO :
     try :
      os . remove ( os . path . join ( iiIi1IIi1I , name ) )
      oO0OOoo0OO . update ( 30 , "" , 'Removing files...' , 'Please wait' )
      os . rmdir ( os . path . join ( iiIi1IIi1I , name ) )
     except : pass
     if 64 - 64: I1iII1iiII - I1Ii111
    for name in o0OoOO000ooO0 :
     try : os . rmdir ( os . path . join ( iiIi1IIi1I , name ) ) ; os . rmdir ( iiIi1IIi1I )
     except : pass
  except : pass
  oO0OOoo0OO . update ( 60 , "" , "Removing folders..." )
  IIIii11 ( )
  IIIii11 ( )
  IIIii11 ( )
  oO0OOoo0OO . update ( 75 , "" , "Removing folders..." )
  IIIii11 ( )
  IIIii11 ( )
  IIIii11 ( )
  IIIii11 ( )
  if 68 - 68: OOoOoo00oo - Oo0oO0ooo - iIii1I11I1II1 / Oo0ooO0oo0oO + Oo0oO0ooo - o0OO0
  if 75 - 75: i11iI / I1i1iI1i % iIii1I11I1II1 . OoooooooOO % OoooooooOO % I1iII1iiII
  oO0OOoo0OO . update ( 99 , "" , "Almost done..." )
  time . sleep ( 3 )
  OooO00000O0O = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
  oO0OOoo0OO = xbmcgui . DialogProgress ( )
  oO0OOoo0OO . create ( "ITV Updater/Installer" , "Wipe complete!" , 'Now Downloading...' , 'Please wait' )
  if 26 - 26: I1iII1iiII % i11iIiiIii % iIii1I11I1II1 % ooO0Oooo00 * ooO0Oooo00 * o00ooo0
  ii1Oo0000oOo = os . path . join ( OooO00000O0O , 'fullbackup.zip' )
  try :
   os . remove ( ii1Oo0000oOo )
  except :
   pass
  downloader . download ( url , ii1Oo0000oOo , oO0OOoo0OO )
  I11 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
  time . sleep ( 2 )
  oO0OOoo0OO . update ( 0 , "" , "Installing..." )
  extract . all ( ii1Oo0000oOo , I11 , oO0OOoo0OO )
  oO0OOoo0OO . update ( 0 , "" , "Finishing up..." )
  time . sleep ( 3 )
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  time . sleep ( 2 )
  O0o0O00Oo0o0 = xbmcgui . Dialog ( )
  O0o0O00Oo0o0 . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next pop-up window after you click OK below, will ask you if you want to \"Keep Skin?\". Always click YES to this." , "" , "Please note: If you take to long, it will automatically​ press YES for you as a fail safe." )
  try :
   os . remove ( ii1Oo0000oOo )
  except :
   pass
  i1IiII1III ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
  O0o0O00Oo0o0 = xbmcgui . Dialog ( )
  time . sleep ( 10 )
  xbmc . executebuiltin ( 'SendClick(11)' )
  if 24 - 24: I1iII1iiII % I1 - OOoOoo00oo + I1Ii111 * o00ooo0
  try :
   os . remove ( o00oooO0Oo )
  except :
   pass
  O0o0O00Oo0o0 . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Installation is complete. " )
  xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
  if 2 - 2: Ooo0 - Oo0o0ooO0oOOO
  if 83 - 83: o00 % I1i1iI1i % Ooo0 - I1iII1iiII * Oo0oO0ooo / OoooooooOO
  if 18 - 18: o0OO0 + iIii1I11I1II1 - I1iII1iiII - I1Ii111
def oooOOOO0oooo ( name , url , description ) :
 DialogITVTerms . show ( )
 oO0OOoo0OO = xbmcgui . DialogProgress ( )
 i1iIiIi1I = xbmcgui . Dialog ( ) . yesno ( "[B]ITV Updater/Installer[/B]" , 'By pressing YES you will install ' , 'the latest version of our software.' , '' , yeslabel = 'YES' , nolabel = 'NO' )
 if i1iIiIi1I == 0 :
  return
 elif i1iIiIi1I == 1 :
  oooooOo0 = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]Would you like Adult XXX Content? (Must be 18+)[/COLOR]" , 'By pressing YES adult xxx content will be installed to' , 'your device.' , '' , yeslabel = 'YES' , nolabel = 'NO' )
  if oooooOo0 == 0 :
   url = i1iII1IiiIiI1
   ii1iIi1II ( )
   time . sleep ( 10 )
   xbmc . executebuiltin ( 'SendClick(11)' )
   O0o0O00Oo0o0 = xbmcgui . Dialog ( )
   O0o0O00Oo0o0 . ok ( "[B]ITV Updater/Installer[/B]" , "Click ok to start the process!" , '' , '' )
   oO0OOoo0OO = xbmcgui . DialogProgress ( )
   oO0OOoo0OO . create ( "[B]ITV Updater/Installer[/B]" , "Wiping Infinity TV device..." , '' , 'Please wait as it will take a few minutes' )
   time . sleep ( 1 )
   oO0OOoo0OO . update ( 10 , "" , 'Preparing files...' , 'Please wait' )
   time . sleep ( 3 )
   try :
    for iiIi1IIi1I , o0OoOO000ooO0 , o0o0o0oO0oOO in os . walk ( IiIIIi1iIi , topdown = True ) :
     o0OoOO000ooO0 [ : ] = [ iIiIiiIIiIIi for iIiIiiIIiIIi in o0OoOO000ooO0 if iIiIiiIIiIIi not in o0O ]
     o0o0o0oO0oOO [ : ] = [ oooO0 for oooO0 in o0o0o0oO0oOO if oooO0 not in oOOoo00O00o ]
     for name in o0o0o0oO0oOO :
      try :
       os . remove ( os . path . join ( iiIi1IIi1I , name ) )
       oO0OOoo0OO . update ( 30 , "" , 'Removing files...' , 'Please wait' )
       os . rmdir ( os . path . join ( iiIi1IIi1I , name ) )
      except : pass
      if 54 - 54: OOoOoo00oo % Oo0oO0ooo . I1 + o00 - Oo0oO0ooo * I1Ii111
     for name in o0OoOO000ooO0 :
      try : os . rmdir ( os . path . join ( iiIi1IIi1I , name ) ) ; os . rmdir ( iiIi1IIi1I )
      except : pass
   except : pass
   oO0OOoo0OO . update ( 60 , "" , "Removing folders..." )
   IIIii11 ( )
   IIIii11 ( )
   IIIii11 ( )
   oO0OOoo0OO . update ( 75 , "" , "Removing folders..." )
   IIIii11 ( )
   IIIii11 ( )
   IIIii11 ( )
   IIIii11 ( )
   if 92 - 92: I1i1iI1i + I1 / OOo % o0OO0 % Oo0o0ooO0oOOO . OoooooooOO
   if 52 - 52: OOoOoo00oo / i11iIiiIii - Oo0oO0ooo . Oo0o0ooO0oOOO % iIii1I11I1II1 + I1i1iI1i
   oO0OOoo0OO . update ( 99 , "" , "Almost done..." )
   time . sleep ( 3 )
   OooO00000O0O = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
   oO0OOoo0OO = xbmcgui . DialogProgress ( )
   oO0OOoo0OO . create ( "ITV Updater/Installer" , "Wipe complete!" , 'Now Downloading...' , 'Please wait' )
   if 71 - 71: o00 % ooO0Oooo00 * Oo0ooO0oo0oO . O0 / Ooo0 . o00ooo0
   ii1Oo0000oOo = os . path . join ( OooO00000O0O , 'fullbackup.zip' )
   try :
    os . remove ( ii1Oo0000oOo )
   except :
    pass
   downloader . download ( url , ii1Oo0000oOo , oO0OOoo0OO )
   I11 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
   time . sleep ( 2 )
   oO0OOoo0OO . update ( 0 , "" , "Installing..." )
   extract . all ( ii1Oo0000oOo , I11 , oO0OOoo0OO )
   oO0OOoo0OO . update ( 0 , "" , "Finishing up..." )
   time . sleep ( 3 )
   xbmc . executebuiltin ( 'UpdateLocalAddons' )
   xbmc . executebuiltin ( "UpdateAddonRepos" )
   time . sleep ( 2 )
   O0o0O00Oo0o0 = xbmcgui . Dialog ( )
   O0o0O00Oo0o0 . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next pop-up window after you click OK below, will ask you if you want to \"Keep Skin?\". Always click YES to this." , "" , "Please note: If you take to long, it will automatically​ press YES for you as a fail safe." )
   try :
    os . remove ( ii1Oo0000oOo )
   except :
    pass
   i1IiII1III ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
   O0o0O00Oo0o0 = xbmcgui . Dialog ( )
   time . sleep ( 10 )
   xbmc . executebuiltin ( 'SendClick(11)' )
   O0o0O00Oo0o0 . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Installation is complete. " )
   try :
    os . remove ( o00oooO0Oo )
   except :
    pass
   xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
   if 58 - 58: OOo / o00
  elif oooooOo0 == 1 :
   url = iIiiiI1IiI1I1
   ii1iIi1II ( )
   time . sleep ( 10 )
   xbmc . executebuiltin ( 'SendClick(11)' )
   O0o0O00Oo0o0 = xbmcgui . Dialog ( )
   O0o0O00Oo0o0 . ok ( "[B]ITV Updater/Installer[/B]" , "Click ok to start the process!" , '' , '' )
   oO0OOoo0OO = xbmcgui . DialogProgress ( )
   oO0OOoo0OO . create ( "[B]ITV Updater/Installer[/B]" , "Wiping Infinity TV device..." , '' , 'Please wait as it will take a few minutes' )
   time . sleep ( 1 )
   oO0OOoo0OO . update ( 10 , "" , 'Preparing files...' , 'Please wait' )
   time . sleep ( 3 )
   try :
    for iiIi1IIi1I , o0OoOO000ooO0 , o0o0o0oO0oOO in os . walk ( IiIIIi1iIi , topdown = True ) :
     o0OoOO000ooO0 [ : ] = [ iIiIiiIIiIIi for iIiIiiIIiIIi in o0OoOO000ooO0 if iIiIiiIIiIIi not in o0O ]
     o0o0o0oO0oOO [ : ] = [ oooO0 for oooO0 in o0o0o0oO0oOO if oooO0 not in oOOoo00O00o ]
     for name in o0o0o0oO0oOO :
      try :
       os . remove ( os . path . join ( iiIi1IIi1I , name ) )
       oO0OOoo0OO . update ( 30 , "" , 'Removing files...' , 'Please wait' )
       os . rmdir ( os . path . join ( iiIi1IIi1I , name ) )
      except : pass
      if 44 - 44: Oo0oO0ooo
     for name in o0OoOO000ooO0 :
      try : os . rmdir ( os . path . join ( iiIi1IIi1I , name ) ) ; os . rmdir ( iiIi1IIi1I )
      except : pass
   except : pass
   oO0OOoo0OO . update ( 60 , "" , "Removing folders..." )
   IIIii11 ( )
   IIIii11 ( )
   IIIii11 ( )
   oO0OOoo0OO . update ( 75 , "" , "Removing folders..." )
   IIIii11 ( )
   IIIii11 ( )
   IIIii11 ( )
   IIIii11 ( )
   if 54 - 54: Ooo0 - ooO0Oooo00 - I1 . iIii1I11I1II1
   if 79 - 79: Ooo0 . o0OO0
   oO0OOoo0OO . update ( 99 , "" , "Almost done..." )
   time . sleep ( 3 )
   OooO00000O0O = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
   oO0OOoo0OO = xbmcgui . DialogProgress ( )
   oO0OOoo0OO . create ( "ITV Updater/Installer" , "Wipe complete!" , 'Now Downloading...' , 'Please wait' )
   if 40 - 40: I1i1iI1i + OOo . I1i1iI1i % OOoOoo00oo
   ii1Oo0000oOo = os . path . join ( OooO00000O0O , 'fullbackup.zip' )
   try :
    os . remove ( ii1Oo0000oOo )
   except :
    pass
   downloader . download ( url , ii1Oo0000oOo , oO0OOoo0OO )
   I11 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
   time . sleep ( 2 )
   oO0OOoo0OO . update ( 0 , "" , "Installing..." )
   extract . all ( ii1Oo0000oOo , I11 , oO0OOoo0OO )
   oO0OOoo0OO . update ( 0 , "" , "Finishing up..." )
   time . sleep ( 3 )
   xbmc . executebuiltin ( 'UpdateLocalAddons' )
   xbmc . executebuiltin ( "UpdateAddonRepos" )
   time . sleep ( 2 )
   O0o0O00Oo0o0 = xbmcgui . Dialog ( )
   O0o0O00Oo0o0 . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next pop-up window after you click OK below, will ask you if you want to \"Keep Skin?\". Always click YES to this." , "" , "Please note: If you take to long, it will automatically​ press YES for you as a fail safe." )
   try :
    os . remove ( ii1Oo0000oOo )
   except :
    pass
   i1IiII1III ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
   time . sleep ( 10 )
   xbmc . executebuiltin ( 'SendClick(11)' )
   O0o0O00Oo0o0 = xbmcgui . Dialog ( )
   O0o0O00Oo0o0 . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Installation is complete. " )
   try :
    os . remove ( o00oooO0Oo )
   except :
    pass
   xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
   if 15 - 15: Ooo0 * OOo % o00ooo0 * iIii1I11I1II1 - i11iIiiIii
   if 60 - 60: I1Ii111 * I1 % o0OO0 + o00
def o0oo ( ) :
 O00OOooo0Ooo = [ ]
 o0oOOoOOO = xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.GetFavourites", "params": {"type": null, "properties": ["path", "thumbnail", "window", "windowparameter"]}, "id": 1}' )
 o0oOOoOOO = unicode ( o0oOOoOOO , 'utf-8' , errors = 'ignore' )
 o0oOOoOOO = simplejson . loads ( o0oOOoOOO )
 if o0oOOoOOO [ "result" ] [ "limits" ] [ "total" ] > 0 :
  for ii in o0oOOoOOO [ "result" ] [ "favourites" ] :
   OooO00000O0O = I1i11II ( ii )
   II11 = { 'Label' : ii [ "title" ] ,
 'Thumb' : ii [ "thumbnail" ] ,
 'Type' : ii [ "type" ] ,
 'Builtin' : OooO00000O0O ,
 'Path' : "plugin://script.extendedinfo/?info=action&&id=" + OooO00000O0O }
   O00OOooo0Ooo . append ( II11 )
 print "ITEMS ################################################"
 print O00OOooo0Ooo
 return O00OOooo0Ooo
 if 15 - 15: Oo0o0ooO0oOOO / O0 . I1i1iI1i . i11iIiiIii
def I1i11II ( fav ) :
 if fav [ "type" ] == "media" :
  OooO00000O0O = "PlayMedia(%s)" % ( fav [ "path" ] )
 elif fav [ "type" ] == "script" :
  OooO00000O0O = "RunScript(%s)" % ( fav [ "path" ] )
 else :
  OooO00000O0O = "ActivateWindow(%s,%s)" % (
 fav [ "window" ] , fav [ "windowparameter" ] )
 return OooO00000O0O
 if 59 - 59: I1 - I1i1iI1i - OOoOoo00oo
def Ii11iI ( favtype ) :
 oO00OoOO = o0oo ( )
 I11IIiIiI = [ ]
 for ii in oO00OoOO :
  if ii [ "Type" ] == favtype :
   I11IIiIiI . append ( ii )
 return I11IIiIiI
 if 5 - 5: OOo * Oo0ooO0oo0oO
def ii1I11iIiIII1 ( ) :
 from t0mm0 . common . net import Net
 import socket
 import time
 if 52 - 52: I1i1iI1i * Oo0o0ooO0oOOO + Oo0ooO0oo0oO
 IiiiIiiI = Net ( )
 if 72 - 72: i1IIi
 OooO00000O0O = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
 ii1Oo0000oOo = os . path . join ( OooO00000O0O , 'fullbackup.zip' )
 import zipfile
 if 82 - 82: Oo0ooO0oo0oO + OoooooooOO / i11iIiiIii * o00ooo0 . OoooooooOO
 oooo0OOo = zipfile . ZipFile ( ii1Oo0000oOo , "r" )
 for OoO00 in oooo0OOo . namelist ( ) :
  if 'favourites.xml' in OoO00 :
   I11iIi1II = oooo0OOo . read ( OoO00 )
   ooo0OO = '<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
   if 15 - 15: Oo0ooO0oo0oO
   ii1III11 = re . compile ( ooo0OO ) . findall ( I11iIi1II )
   print ii1III11
   for IiII111iI1ii1 , oOoOoO000OO , ii11II11 in ii1III11 :
    if 70 - 70: iIii1I11I1II1
    oOoOoO000OO = oOoOoO000OO . replace ( 'thumb://None' , '/mnt/internal_sd/Android/data/org.xbmc.xbmc/files/.xbmc/addons/script.1channel.themepak/art/themes/Glossy_Black/favourites.png' )
    ii11II11 = ii11II11 . replace ( '&quot;' , '' ) . replace ( '&amp;' , '&' )
    json . loads ( xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % ( IiII111iI1ii1 , ii11II11 , oOoOoO000OO ) ) )
    for ii1Ii11IiiI1 , iIioo00O0 in enumerate ( fileinput . input ( oOOo0 , inplace = 1 ) ) :
     sys . stdout . write ( iIioo00O0 . replace ( 'RunScript(&quot;' , '' ) . replace ( '&quot;)' , '' ) )
  if 49 - 49: I1iII1iiII - I1Ii111 / ooO0Oooo00
  if 74 - 74: ooO0Oooo00 - Oo0oO0ooo + i1IIi . I1Ii111 + Oo0oO0ooo - ooO0Oooo00
  if 17 - 17: O0 . I1 . O0 + O0 / OOo . OOoOoo00oo
  if 62 - 62: o00ooo0 % i11iI * o0OO0 - i1IIi
  if 66 - 66: i11iIiiIii / I1i1iI1i - OoooooooOO / i1IIi . i11iIiiIii
  if 16 - 16: OOo % o00ooo0 + ooO0Oooo00 - O0 . i11iI / I1
  if 35 - 35: o00 / I1 / I1iII1iiII - iIii1I11I1II1 + I1iII1iiII . I1
  if 81 - 81: i11iI * Oo0oO0ooo - o00ooo0 * Ooo0 % Oo0ooO0oo0oO * Oo0ooO0oo0oO
  if 59 - 59: iIii1I11I1II1
  if 7 - 7: Oo0oO0ooo * I1Ii111 / I1i1iI1i * i11iIiiIii
  if 84 - 84: Oo0oO0ooo . i11iI
  if 8 - 8: OOo + I1iII1iiII * Oo0oO0ooo * Oo0ooO0oo0oO * ooO0Oooo00 / Oo0o0ooO0oOOO
  if 21 - 21: o00 / OoooooooOO
def III1IiIII1 ( ) :
 from t0mm0 . common . net import Net
 import socket
 import time
 if 90 - 90: OOoOoo00oo + I1iII1iiII * o00ooo0 / Ooo0 . I1i1iI1i + I1i1iI1i
 if ( os . path . isfile ( oo00O00oO ) ) :
  IiiiIiiI = Net ( )
  I11I = ''
  oooO0 = open ( oOOo0 , mode = 'w' )
  oooO0 . write ( I11I )
  oooO0 . close ( )
  if 69 - 69: i1IIi
  I11iIi1II = open ( oo00O00oO ) . read ( )
  ooo0OO = '<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
  ii1III11 = re . compile ( ooo0OO ) . findall ( I11iIi1II )
  for ooOoOOOOo , ooooOooooOOo , ooO00O00oOO in ii1III11 :
   json . loads ( xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % ( ooOoOOOOo , ooO00O00oOO , ooooOooooOOo ) ) )
   for ii1Ii11IiiI1 , iIioo00O0 in enumerate ( fileinput . input ( oOOo0 , inplace = 1 ) ) :
    sys . stdout . write ( iIioo00O0 . replace ( 'RunScript(&quot;' , '' ) . replace ( '&quot;)' , '' ) . replace ( '&amp;' , '&' ) )
    if 40 - 40: i11iI . o00 + I1Ii111 + o00ooo0 + I1
  OooO00000O0O = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
  i11 = os . path . join ( OooO00000O0O , 'favourites.xml' )
  downloader . download ( Oo , i11 )
  time . sleep ( 2 )
  OoO00 = i11
  if 20 - 20: OoooooooOO - OOo % Oo0ooO0oo0oO % ooO0Oooo00
  ooo0OO = '<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
  if 89 - 89: o00 / OoooooooOO . i11iI
  I1iiiiii = re . compile ( ooo0OO ) . findall ( I11iIi1II )
  for IiII111iI1ii1 , oOoOoO000OO , ii11II11 in I1iiiiii :
   I11iIi1II = open ( oOOo0 ) . read ( )
   if IiII111iI1ii1 in I11iIi1II : break
   if 65 - 65: Oo0o0ooO0oOOO + OOo
   if 59 - 59: OoooooooOO + ooO0Oooo00 . I1 - O0 % iIii1I11I1II1 / O0
   if 88 - 88: OOo . O0 % OoooooooOO / Oo0oO0ooo
   oOoOoO000OO = oOoOoO000OO . replace ( 'thumb://None' , '/mnt/internal_sd/Android/data/org.xbmc.xbmc/files/.xbmc/addons/script.1channel.themepak/art/themes/Glossy_Black/favourites.png' )
   ii11II11 = ii11II11 . replace ( '&quot;' , '' )
   if 89 - 89: I1iII1iiII / o00
   json . loads ( xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % ( IiII111iI1ii1 , ii11II11 , oOoOoO000OO ) ) )
   for ii1Ii11IiiI1 , iIioo00O0 in enumerate ( fileinput . input ( oOOo0 , inplace = 1 ) ) :
    sys . stdout . write ( iIioo00O0 . replace ( 'RunScript(&quot;' , '' ) . replace ( '&quot;)' , '' ) )
 else :
  pass
  if 14 - 14: Oo0oO0ooo . I1Ii111 * OOoOoo00oo + I1iII1iiII - OOoOoo00oo + Oo0oO0ooo
  if 18 - 18: o00 - I1i1iI1i - I1Ii111 - I1Ii111
def OOooo00 ( ) :
 if 35 - 35: I1 . Oo0ooO0oo0oO * i11iIiiIii
 import time
 if 44 - 44: i11iIiiIii / OOo
 try :
  oO0OOoo0OO = xbmcgui . DialogProgress ( )
  oO0OOoo0OO . create ( "ITV Updater/Installer" , "Retrieving backup file... " , '' , 'Please wait' )
  ii1Oo0000oOo = xbmc . translatePath ( os . path . join ( ooOOoooooo , 'backup.zip' ) )
  I11 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
  time . sleep ( 2 )
  oO0OOoo0OO . update ( 0 , "" , "Installing..." )
  extract . all ( ii1Oo0000oOo , I11 , oO0OOoo0OO )
  oO0OOoo0OO . update ( 0 , "" , "Finishing up..." )
  time . sleep ( 5 )
  O0o0O00Oo0o0 = xbmcgui . Dialog ( )
  O0o0O00Oo0o0 . ok ( "ITV Updater/Installer" , "[COLOR yellow]Installation nearly complete but one important step remains. [/COLOR]" )
  O0o0O00Oo0o0 = xbmcgui . Dialog ( )
  O0o0O00Oo0o0 . ok ( "ITV Updater/Installer" , "[COLOR red]URGENT: Please unplug or power off your device immediately and then reboot to finish setup. [/COLOR]" )
  if 42 - 42: OoooooooOO + OOo % I1iII1iiII + o0OO0
 except :
  O0o0O00Oo0o0 = xbmcgui . Dialog ( )
  O0o0O00Oo0o0 . ok ( 'ITV Updater/Installer' , 'You need to backup your build first.\nTo backup your box press backup on main menu.' , '' , '' )
  if 24 - 24: i11iI * I1iII1iiII % i11iI % Oo0o0ooO0oOOO + OoooooooOO
  if 29 - 29: I1iII1iiII - OoooooooOO - i11iIiiIii . I1i1iI1i
  if 19 - 19: I1iII1iiII
def iI11 ( name , url , mode , iconimage , fanart , description ) :
 OoOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 O00O0oOO00O00 = True
 II1i11i1iIi11 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 II1i11i1iIi11 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 II1i11i1iIi11 . setProperty ( "Fanart_Image" , fanart )
 O00O0oOO00O00 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OoOO , listitem = II1i11i1iIi11 , isFolder = False )
 return O00O0oOO00O00
 if 83 - 83: Ooo0
def o00oOoOo0 ( name , url , mode , iconimage , fanart , description ) :
 OoOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 O00O0oOO00O00 = True
 II1i11i1iIi11 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 II1i11i1iIi11 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 II1i11i1iIi11 . setProperty ( "Fanart_Image" , fanart )
 O00O0oOO00O00 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OoOO , listitem = II1i11i1iIi11 , isFolder = True )
 return O00O0oOO00O00
 if 25 - 25: ooO0Oooo00 + Oo0ooO0oo0oO . I1i1iI1i % Oo0ooO0oo0oO * Oo0oO0ooo
 if 32 - 32: i11iIiiIii - I1
 if 53 - 53: OoooooooOO - Oo0o0ooO0oOOO
def oOo ( ) :
 i1i = [ ]
 IIIiiiI = sys . argv [ 2 ]
 if len ( IIIiiiI ) >= 2 :
  OoO00oo00 = sys . argv [ 2 ]
  Oo0Oo0O = OoO00oo00 . replace ( '?' , '' )
  if ( OoO00oo00 [ len ( OoO00oo00 ) - 1 ] == '/' ) :
   OoO00oo00 = OoO00oo00 [ 0 : len ( OoO00oo00 ) - 2 ]
  iiiI1i11Ii = Oo0Oo0O . split ( '&' )
  i1i = { }
  for ii1Ii11IiiI1 in range ( len ( iiiI1i11Ii ) ) :
   iIiII = { }
   iIiII = iiiI1i11Ii [ ii1Ii11IiiI1 ] . split ( '=' )
   if ( len ( iIiII ) ) == 2 :
    i1i [ iIiII [ 0 ] ] = iIiII [ 1 ]
    if 19 - 19: Oo0o0ooO0oOOO
 return i1i
 if 78 - 78: Oo0oO0ooo % I1i1iI1i
 if 39 - 39: o00ooo0 + I1Ii111 - iIii1I11I1II1 - I1i1iI1i
OoO00oo00 = oOo ( )
OoOoO = None
IiII111iI1ii1 = None
I1i = None
o0ii1i = None
oOOoo = None
iII1111III1I = None
if 49 - 49: o00ooo0
if 84 - 84: ooO0Oooo00 - OOo / O0 - I1
try :
 OoOoO = urllib . unquote_plus ( OoO00oo00 [ "url" ] )
except :
 pass
try :
 IiII111iI1ii1 = urllib . unquote_plus ( OoO00oo00 [ "name" ] )
except :
 pass
try :
 o0ii1i = urllib . unquote_plus ( OoO00oo00 [ "iconimage" ] )
except :
 pass
try :
 I1i = int ( OoO00oo00 [ "mode" ] )
except :
 pass
try :
 oOOoo = urllib . unquote_plus ( OoO00oo00 [ "fanart" ] )
except :
 pass
try :
 iII1111III1I = urllib . unquote_plus ( OoO00oo00 [ "description" ] )
except :
 pass
 if 21 - 21: O0 * O0 % o00ooo0
 if 94 - 94: ooO0Oooo00 + I1iII1iiII % i11iIiiIii
print str ( OOO00O0O ) + ': ' + str ( iiIiII1 )
print "Mode: " + str ( I1i )
print "URL: " + str ( OoOoO )
print "Name: " + str ( IiII111iI1ii1 )
print "IconImage: " + str ( o0ii1i )
if 8 - 8: OOoOoo00oo * O0
if 73 - 73: I1i1iI1i / o00 / ooO0Oooo00 / o0OO0
def OO0ooo0oOO ( content , viewType ) :
 if 11 - 11: Oo0ooO0oo0oO + Oo0o0ooO0oOOO - OoooooooOO / o0OO0
 if content :
  xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , content )
 if i1 . getSetting ( 'auto-view' ) == 'true' :
  xbmc . executebuiltin ( "Container.SetViewMode(%s)" % i1 . getSetting ( viewType ) )
  if 34 - 34: OOoOoo00oo
  if 45 - 45: OOoOoo00oo / OOo / Ooo0
if I1i == None or OoOoO == None or len ( OoOoO ) < 1 :
 Iii1iiIi1II ( )
 if 44 - 44: o00ooo0 - Ooo0 / I1iII1iiII * o0OO0 * OOo
elif I1i == 1 :
 iiIiIIIiiI ( IiII111iI1ii1 , OoOoO , iII1111III1I )
 if 73 - 73: I1i1iI1i - I1Ii111 * i1IIi / i11iIiiIii * Oo0oO0ooo % I1iII1iiII
elif I1i == 2 :
 oO0o0o0oo ( IiII111iI1ii1 , OoOoO , iII1111III1I )
 if 56 - 56: OoooooooOO * OOo . OOo . o00ooo0
elif I1i == 3 :
 Ii1Iii1iIi ( )
 if 24 - 24: OOo . ooO0Oooo00 * Ooo0 % i11iI / Oo0oO0ooo
elif I1i == 4 :
 OOooo00 ( )
 if 58 - 58: I1Ii111 - o00ooo0 % O0 . I1Ii111 % o0OO0 % Oo0o0ooO0oOOO
elif I1i == 5 :
 O0oOo00o ( )
 if 87 - 87: o00 - i11iIiiIii
elif I1i == 6 :
 oooOOOO0oooo ( IiII111iI1ii1 , OoOoO , iII1111III1I )
 if 78 - 78: i11iIiiIii / iIii1I11I1II1 - I1i1iI1i
elif I1i == 7 :
 iII11I1Ii1 ( )
 if 23 - 23: ooO0Oooo00
elif I1i == 8 :
 O0o0O00Oo0o0 = xbmcgui . Dialog ( )
 O0o0O00Oo0o0 . ok ( "ITV Updater/Installer" , "[COLOR yellow]Important![/COLOR]" , "" , "Please POWER DOWN your Infinity TV, and then turn it back ON for the changes to take place." )
 try :
  os . remove ( lib )
 except :
  pass
 III1IiIII1 ( )
 if 40 - 40: I1i1iI1i - I1iII1iiII / OOo
 if 14 - 14: o00ooo0
 if 5 - 5: I1i1iI1i . iIii1I11I1II1 % iIii1I11I1II1
 if 56 - 56: OoooooooOO - ooO0Oooo00 - i1IIi
 if 8 - 8: I1 / Oo0oO0ooo . I1Ii111 + o00ooo0 / i11iIiiIii
 try :
  os . remove ( oo00O00oO )
 except :
  pass
  if 31 - 31: OOoOoo00oo - iIii1I11I1II1 + i11iI . OOo / Oo0o0ooO0oOOO % iIii1I11I1II1
elif I1i == 9 :
 O00oooo00o0O ( IiII111iI1ii1 , OoOoO , iII1111III1I )
 if 6 - 6: Oo0o0ooO0oOOO * i11iIiiIii % iIii1I11I1II1 % i11iIiiIii + I1i1iI1i / i1IIi
elif I1i == 10 :
 II1IiiIii ( IiII111iI1ii1 , OoOoO , iII1111III1I )
 if 53 - 53: ooO0Oooo00 + iIii1I11I1II1
elif I1i == 11 :
 Oo00oo0000OO ( IiII111iI1ii1 , OoOoO , iII1111III1I )
 if 70 - 70: o00ooo0
elif I1i == 12 :
 oOOoo0o0OOOO ( IiII111iI1ii1 , OoOoO , iII1111III1I )
 if 67 - 67: OoooooooOO
elif I1i == 13 :
 ooO00O ( IiII111iI1ii1 , OoOoO , iII1111III1I )
 if 29 - 29: O0 - i11iIiiIii - I1iII1iiII + Oo0oO0ooo * Oo0o0ooO0oOOO
elif I1i == 15 :
 O0oOo00o0o00O ( IiII111iI1ii1 , OoOoO , iII1111III1I )
 if 2 - 2: i1IIi - OOoOoo00oo + I1Ii111 . I1i1iI1i * I1i1iI1i / Oo0ooO0oo0oO
elif I1i == 16 :
 O0000 ( IiII111iI1ii1 , OoOoO , iII1111III1I )
 if 93 - 93: i1IIi
elif I1i == 99 :
 oO0oO0 ( )
 if 53 - 53: OoooooooOO + OOo + o00
 if 24 - 24: i11iI - Oo0o0ooO0oOOO - i11iI * o00ooo0 . OoooooooOO / Oo0o0ooO0oOOO
 if 66 - 66: OOo
 if 97 - 97: i1IIi - OoooooooOO / I1 * I1Ii111
 if 55 - 55: I1i1iI1i . i11iI
 if 87 - 87: I1i1iI1i % iIii1I11I1II1
 if 100 - 100: I1 . I1Ii111 * I1 - I1Ii111 . ooO0Oooo00 * Ooo0
 if 89 - 89: o0OO0 + Oo0o0ooO0oOOO * I1
 if 28 - 28: OoooooooOO . o00 % o00ooo0 / i1IIi / Oo0oO0ooo
elif I1i == 98 :
 xbmc . executebuiltin ( "RunScript(script.speedtestnet)" )
 if 36 - 36: I1i1iI1i + ooO0Oooo00 - Oo0o0ooO0oOOO + iIii1I11I1II1 + OoooooooOO
 if 4 - 4: I1iII1iiII . ooO0Oooo00 + Ooo0 * I1 . OOoOoo00oo
elif I1i == 97 :
 oO0OOoO0 ( OoOoO )
 if 87 - 87: Oo0ooO0oo0oO / o0OO0 / i11iIiiIii
elif I1i == 96 :
 OOOOOoo0 ( )
 if 74 - 74: o00 / o00ooo0 % I1i1iI1i
elif I1i == 95 :
 O0o0O00Oo0o0 = xbmcgui . Dialog ( )
 O0o0O00Oo0o0 . ok ( "Update Add-ons" , "Press OK to make sure all your add-ons apps are up-to-date." , "" , "" )
 xbmc . executebuiltin ( 'UpdateLocalAddons' )
 xbmc . executebuiltin ( "UpdateAddonRepos" )
 if 88 - 88: Oo0ooO0oo0oO - i11iIiiIii % I1i1iI1i * ooO0Oooo00 + o00ooo0
elif I1i == 90 :
 oO ( )
 if 52 - 52: I1iII1iiII . I1Ii111 + Oo0ooO0oo0oO % o0OO0
elif I1i == 80 :
 I1Iiiiiii ( IiII111iI1ii1 , OoOoO , iII1111III1I )
 if 62 - 62: I1i1iI1i
elif I1i == 81 :
 iIIii ( IiII111iI1ii1 , OoOoO , iII1111III1I )
 if 15 - 15: ooO0Oooo00 + Ooo0 . Oo0oO0ooo * o0OO0 . Oo0ooO0oo0oO
elif I1i == 82 :
 II1Ii11I111I ( IiII111iI1ii1 )
 if 18 - 18: i1IIi % I1iII1iiII + I1 % Ooo0
 if 72 - 72: iIii1I11I1II1
 if 45 - 45: OOo - I1i1iI1i % I1
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
if 38 - 38: I1 % Oo0oO0ooo - OoooooooOO
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
