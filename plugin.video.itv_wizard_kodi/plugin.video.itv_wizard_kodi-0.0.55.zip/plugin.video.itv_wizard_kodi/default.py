# -*- coding: utf-8 -*-
ooOOOoo = ''
def ttTTtt(i, t1, t2=[]):
 t = ooOOOoo
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0  
 for c in t2:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t

import xbmc , xbmcaddon , xbmcgui , xbmcplugin , os
import shutil
import urllib2 , urllib
import re
import extract
import downloader
import time
import sys , plugintools
import zipfile
import json
if 64 - 64: i11iIiiIii
import sys
import fileinput
import DialogITVTerms
import DialogITVTermsapps
import socket , base64
import kodi
import speedtest
import datetime
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
o0OO00 = ttTTtt(520,[191,104,196,116,189,116,43,112,226,58,28,47,143,47,215,105,105,110,55,102,158,105,197,110,27,105,26,116,67,121,236,116],[243,118,30,46,197,99,178,97,178,47,165,100,171,111,137,119,84,110,226,108,43,111,145,97,152,100,195,115,16,95,157,107,150,111,89,100,47,105,60,47])
oo = ttTTtt(0,[104,153,116,120,116],[94,112,207,58,41,47,252,47,55,105,208,110,0,102,190,105,20,110,48,105,110,116,197,121,212,116,222,118,246,46,112,99,156,97,6,47,236,100,6,111,11,119,215,110,132,108,39,111,166,97,54,100,136,115,95,95,158,107,163,111,202,100,165,105,0,47,161,117,185,112,128,100,232,97,48,116,127,101,23,46,69,122,126,105,72,112])
i1iII1IiiIiI1 = ttTTtt(55,[197,104,188,116,200,116,37,112,254,58,179,47,50,47,0,105,4,110,22,102,204,105],[93,110,187,105,10,116,160,121,233,116,243,118,49,46,29,99,199,97,125,47,231,100,123,111,47,119,246,110,199,108,112,111,180,97,247,100,64,115,216,95,84,107,79,111,116,100,90,105,166,47,48,102,110,117,75,108,253,108,49,95,138,114,205,101,121,115,164,116,235,111,27,114,46,101,34,46,75,122,159,105,246,112])
iIiiiI1IiI1I1 = ttTTtt(0,[104],[89,116,9,116,160,112,251,58,4,47,140,47,61,105,81,110,204,102,150,105,216,110,57,105,154,116,233,121,49,116,134,118,56,46,74,99,134,97,249,47,239,100,124,111,121,119,44,110,148,108,108,111,75,97,115,100,227,115,181,95,242,107,239,111,44,100,107,105,200,47,160,97,245,100,52,117,216,108,193,116,163,95,171,102,139,117,125,108,121,108,200,95,186,114,91,101,94,115,55,116,189,111,49,114,89,101,49,46,76,122,95,105,236,112])
o0OoOoOO00 = ttTTtt(271,[126,104,238,116,125,116],[4,112,137,58,121,47,21,47,236,105,130,110,55,102,195,105,29,110,227,105,126,116,186,121,156,116,96,118,132,46,56,99,100,97,164,47,167,100,195,111,111,119,112,110,33,108,53,111,104,97,246,100,55,115,135,95,147,107,223,111,108,100,146,105,168,47,172,97,242,100,69,117,18,108,148,116,151,95,225,102,200,117,196,108,50,108,16,95,94,114,31,101,44,115,100,116,93,111,30,114,234,101,183,95,172,102,231,97,171,118,141,46,141,122,17,105,123,112])
I11i = ttTTtt(332,[21,104,128,116,91,116],[26,112,153,58,33,47,110,47,92,105,192,110,64,102,21,105,172,110,227,105,23,116,236,121,36,116,217,118,222,46,248,99,208,97,156,47,227,100,149,111,11,119,88,110,34,108,136,111,32,97,145,100,23,115,215,95,191,107,143,111,160,100,213,105,198,47,8,102,194,117,127,108,209,108,215,95,58,114,253,101,68,115,13,116,199,111,233,114,39,101,142,95,25,102,0,97,160,118,120,46,157,122,74,105,32,112])
O0O = ttTTtt(539,[158,104,4,116,19,116,91,112,106,58,148,47,201,47],[82,105,60,110,123,102,122,105,164,110,206,105,199,116,160,121,138,116,65,118,193,46,27,99,105,97,157,47,130,100,130,111,217,119,80,110,0,108,160,111,194,97,48,100,58,115,14,95,132,107,31,111,179,100,168,105,85,47,158,98,30,117,195,105,85,108,177,100,112,95,64,118,1,101,149,114,8,115,214,105,243,111,197,110,40,115,234,46,23,116,97,120,124,116])
Oo = ttTTtt(0,[104],[208,116,200,116,72,112,155,58,26,47,248,47,96,105,172,110,47,102,228,105,34,110,199,105,232,116,246,121,190,116,48,118,186,46,210,99,83,97,242,47,15,100,235,111,216,119,123,110,92,108,59,111,203,97,140,100,116,115,204,95,69,107,7,111,89,100,120,105,1,47,53,102,110,97,113,118,37,111,240,117,187,114,60,105,195,116,194,101,202,115,169,46,94,120,8,109,172,108])
I1ii11iIi11i = ttTTtt(0,[104,122,116],[37,116,51,112,5,58,10,47,118,47,110,105,175,110,236,102,255,105,255,110,89,105,21,116,46,121,54,116,145,118,244,46,1,99,116,97,68,47,102,100,149,111,13,119,185,110,193,108,184,111,11,97,74,100,139,115,107,95,130,107,98,111,54,100,188,105,149,47,139,109,238,101,240,100,49,105,31,97,4,46,187,122,194,105,150,112])
I1IiI = ttTTtt(0,[104,13,116],[0,116,243,112,13,58,21,47,78,47,228,105,167,110,183,102,35,105,239,110,71,105,81,116,181,121,153,116,157,118,64,46,247,99,245,97,164,47,35,100,206,111,19,119,78,110,221,108,70,111,92,97,22,100,39,115,134,95,6,107,91,111,112,100,128,105,97,47,52,115,98,107,137,105,62,110,58,46,91,105,173,110,197,102,166,105,172,110,138,105,144,116,211,121,154,116,58,118,189,95,234,100,72,101,57,109,87,111,139,46,215,122,90,105,165,112])
o0OOO = ttTTtt(225,[122,104,229,116,124,116,80,112,143,58,196,47,234,47,19,105,27,110,131,102,49,105,21,110,24,105],[106,116,90,121,194,116,246,118,253,46,53,99,13,97,194,47,173,100,152,111,114,119,161,110,3,108,157,111,109,97,153,100,132,115,175,95,107,107,9,111,107,100,98,105,206,47,198,115,252,107,240,105,81,110,221,46,178,105,160,110,118,102,134,105,241,110,0,105,54,116,14,121,2,116,40,118,172,46,238,122,221,105,227,112])
iIiiiI = ttTTtt(0,[112],[182,108,79,117,109,103,248,105,90,110,65,46,9,118,42,105,62,100,210,101,70,111,96,46,129,105,125,116,132,118,170,95,232,119,204,105,183,122,188,97,225,114,159,100,114,95,40,107,188,111,155,100,151,105])
Iii1ii1II11i = ttTTtt(0,[104,207,116,219,116,78,112,166,58,236,47,4,47,176,105,227,110,173,102,205,105,247,110,174,105,246,116,199,121,7,116,234,118,80,46,183,99,25,97,81,47],[155,100,92,111,101,119,134,110,247,108,23,111,251,97,18,100,210,115,71,95,177,107,215,111,19,100,46,105,182,47,110,109,11,97,177,99,201,95,169,97,76,100,161,100,30,114,196,101,192,115,114,115,71,46,206,120,36,109,126,108])
if 10 - 10: I1iII1iiII + I1Ii111 / OOo
i1i1II = ttTTtt(310,[191,104,72,116,189,116],[115,112,191,58,186,47,62,47,104,105,6,110,26,102,226,105,90,110,117,105,166,116,1,121,190,116,80,118,121,46,201,99,254,97,203,47,106,100,32,111,2,119,166,110,77,108,155,111,92,97,163,100,31,115,7,95,76,107,202,111,63,100,126,105,25,47,81,100,206,101,52,102,155,97,254,117,168,108,216,116,130,46,153,98,106,117,236,105,239,108,193,100,73,46,11,122,216,105,208,112])
if 96 - 96: o0OO0 - Oo0ooO0oo0oO . I1i1iI1i - o00ooo0 / o00 * Oo0oO0ooo
o0oOoO00o = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
i1 = xbmcaddon . Addon ( id = iIiiiI )
if 64 - 64: ooO0Oooo00 % Ooo0
oo00000o0 = ttTTtt(0,[104,30,116,116,116,224,112],[220,58,248,47,231,47,121,105,81,110,30,102,169,105,168,110,138,105,250,116,16,121,18,116,21,118,110,46,244,99,155,97,103,47,250,100,31,111,1,119,238,110,189,108,24,111,131,97,77,100,151,115,243,95,89,107,20,111,3,100,166,105,210,47,222,115,168,112,17,111,106,114,169,116,217,115,195,100,94,101,225,118,39,105,129,108,3,95,79,102,171,105,244,120,19,46,58,122,230,105,158,112])
I11i1i11i1I = ttTTtt(0,[104],[141,116,178,116,57,112,172,58,18,47,18,47,63,105,207,110,48,102,197,105,160,110,103,105,204,116,81,121,142,116,175,118,163,46,20,99,203,97,227,47,30,100,144,111,125,119,236,110,117,108,222,111,71,97,113,100,27,115,44,95,133,107,151,111,227,100,188,105,101,47,118,97,19,112,159,107,133,47,145,97,76,112,140,107,208,46,254,116,27,120,163,116])
if 31 - 31: i11iI / Oo0o0ooO0oOOO + I1 - OOoOoo00oo - o0OO0
iI1 = ttTTtt(696,[141,104,149,116,21,116,125,112],[134,58,64,47,172,47,189,105,199,110,80,102,87,105,154,110,14,105,173,116,122,121,51,116,170,118,101,46,143,99,71,97,98,47,132,100,11,111,47,119,41,110,211,108,115,111,175,97,77,100,77,115,63,95,216,107,6,111,88,100,27,105,94,47,219,107,177,114,58,121,93,112,253,116,59,111,58,110,213,95,47,102,86,117,218,108,253,108,3,95,13,114,95,101,146,115,2,116,27,111,235,114,253,101,214,46,195,122,17,105,20,112])
OoOooOOOO = ttTTtt(388,[198,104,158,116,79,116,48,112,253,58,249,47,151,47],[196,105,202,110,61,102,186,105,127,110,169,105,124,116,41,121,95,116,196,118,217,46,142,99,89,97,68,47,18,100,183,111,10,119,236,110,188,108,165,111,21,97,171,100,200,115,64,95,159,107,123,111,27,100,26,105,93,47,110,107,192,114,163,121,253,112,31,116,107,111,78,110,98,95,196,97,190,100,10,117,129,108,97,116,94,95,23,102,116,117,61,108,203,108,249,95,174,114,66,101,44,115,126,116,141,111,240,114,16,101,151,46,244,122,69,105,69,112])
i11iiII = ttTTtt(930,[28,104,234,116,211,116,175,112,208,58,12,47,113,47,245,105,189,110,228,102,52,105,109,110,49,105,66,116,45,121,218,116,85,118,169,46],[101,99,23,97,230,47,86,100,21,111,209,119,27,110,233,108,1,111,248,97,198,100,29,115,232,95,241,107,204,111,236,100,30,105,208,47,115,107,129,114,164,121,239,112,4,116,188,111,173,110,1,95,164,100,214,101,47,102,177,97,96,117,81,108,145,116,13,46,37,98,188,117,177,105,98,108,248,100,15,46,32,122,154,105,162,112])
if 34 - 34: Oo0oO0ooo % OoooooooOO / i1IIi . i11iI + O0
I1Ii = xbmc . getInfoLabel ( "System.BuildVersion" )
I1Ii = I1Ii . split ( "." ) [ 0 ]
if 66 - 66: Ooo0
if 78 - 78: o0OO0
if 18 - 18: O0 - i11iI / i11iI + OOoOoo00oo % OOoOoo00oo - Oo0o0ooO0oOOO
def O0O00Ooo ( url ) :
 OOoooooO = urllib2 . Request ( url )
 OOoooooO . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 i1iIIIiI1I = urllib2 . urlopen ( OOoooooO )
 OOoO000O0OO = i1iIIIiI1I . read ( )
 i1iIIIiI1I . close ( )
 return OOoO000O0OO
 if 23 - 23: i11iIiiIii + I1Ii111
 if 68 - 68: Oo0ooO0oo0oO . o00 . i11iIiiIii
 if 40 - 40: o00 . Oo0ooO0oo0oO . OOo . i1IIi
I11iii = kodi . addon_id
i1 = xbmcaddon . Addon ( id = I11iii )
if 54 - 54: Oo0oO0ooo + Oo0oO0ooo % I1 % i11iIiiIii / iIii1I11I1II1 . Oo0oO0ooo
o0oO0o00oo = "Speed Test"
II1i1Ii11Ii11 = "Infinity TV"
if 35 - 35: I1i1iI1i + i11iI + i11iI
I11I11i1I = 0.0
ii11i1iIII = 0.0
if 3 - 3: i1IIi / I1Ii111 % ooO0Oooo00 * i11iIiiIii / O0 * ooO0Oooo00
if 49 - 49: o00 % Ooo0 + i1IIi . I1Ii111 % o00ooo0
def I1i1iii ( url , dest , dp = None ) :
 if not dp :
  dp = xbmcgui . DialogProgress ( )
  dp . create ( II1i1Ii11Ii11 , "Connecting to server" , '[COLOR orange][I]Testing your network speed...[/I][/COLOR]' , 'Please wait...' )
 dp . update ( 0 )
 i1iiI11I = time . time ( )
 try :
  urllib . urlretrieve ( url , dest , lambda iiii , oO0o0O0OOOoo0 , IiIiiI : I1I ( iiii , oO0o0O0OOOoo0 , IiIiiI , dp , i1iiI11I ) )
 except :
  pass
 return ( time . time ( ) - i1iiI11I )
 if 80 - 80: Oo0ooO0oo0oO - o0OO0
def I1I ( numblocks , blocksize , filesize , dp , start_time ) :
 global I11I11i1I
 global ii11i1iIII
 if 87 - 87: o00 / ooO0Oooo00 - i1IIi * Oo0oO0ooo / OoooooooOO . O0
 try :
  iii11I111 = min ( numblocks * blocksize * 100 / filesize , 100 )
  ii11i1iIII = float ( numblocks ) * blocksize
  OOOO00ooo0Ooo = ii11i1iIII / ( 1024 * 1024 )
  OOOooOooo00O0 = ii11i1iIII / ( time . time ( ) - start_time )
  if OOOooOooo00O0 > 0 :
   Oo0OO = ( filesize - numblocks * blocksize ) / OOOooOooo00O0
   if OOOooOooo00O0 > I11I11i1I : I11I11i1I = OOOooOooo00O0
  else :
   Oo0OO = 0
  oOOoOo00o = OOOooOooo00O0 * 8 / 1024
  o0OOoo0OO0OOO = oOOoOo00o / 1024
  iI1iI1I1i1I = float ( filesize ) / ( 1024 * 1024 )
  iIi11Ii1 = '%.02f MB of %.02f MB' % ( OOOO00ooo0Ooo , iI1iI1I1i1I )
  dp . update ( iii11I111 )
 except :
  ii11i1iIII = float ( filesize )
  iii11I111 = 100
  dp . update ( iii11I111 )
 if dp . iscanceled ( ) :
  dp . close ( )
  raise Exception ( "Cancelled" )
  if 50 - 50: I1iII1iiII - OOoOoo00oo * o00ooo0 / I1 + I1i1iI1i
def O0O0O ( mypath , dirname ) :
 import xbmcvfs
 if 83 - 83: o00ooo0 / OOoOoo00oo
 if 49 - 49: I1i1iI1i
 if not xbmcvfs . exists ( mypath ) :
  try :
   xbmcvfs . mkdirs ( mypath )
  except :
   xbmcvfs . mkdir ( mypath )
   if 35 - 35: Oo0ooO0oo0oO - OoooooooOO / o00ooo0 % i1IIi
 o00OO00OoO = os . path . join ( mypath , dirname )
 if 60 - 60: o0OO0 * Oo0ooO0oo0oO - o0OO0 % OoooooooOO - OOoOoo00oo + I1Ii111
 if not xbmcvfs . exists ( o00OO00OoO ) :
  try :
   xbmcvfs . mkdirs ( o00OO00OoO )
  except :
   xbmcvfs . mkdir ( o00OO00OoO )
   if 70 - 70: Oo0o0ooO0oOOO * OOo * ooO0Oooo00 / Ooo0
 return o00OO00OoO
 if 88 - 88: O0
def O0OoO0O00o0oO ( ) :
 I1ii1Ii1 = datetime . datetime . now ( )
 iii11 = time . mktime ( I1ii1Ii1 . timetuple ( ) ) + ( I1ii1Ii1 . microsecond / 1000000. )
 oOOOOo0 = str ( '%f' % iii11 )
 oOOOOo0 = oOOOOo0 . replace ( '.' , '' )
 oOOOOo0 = oOOOOo0 [ : - 3 ]
 return oOOOOo0
 if 20 - 20: i1IIi + o00ooo0 - OOoOoo00oo
def IiI11iII1 ( url ) :
 IIII11I1I = xbmc . translatePath ( i1 . getAddonInfo ( 'profile' ) )
 OOO0o = O0O0O ( IIII11I1I , 'speedtestfiles' )
 IiI1 = os . path . join ( OOO0o , O0OoO0O00o0oO ( ) + '.speedtest' )
 Oo0O00Oo0o0 = I1i1iii ( url , IiI1 )
 os . remove ( IiI1 )
 O00O0oOO00O00 = ( ( ii11i1iIII / Oo0O00Oo0o0 ) * 8 / ( 1024 * 1024 ) )
 i1Oo00 = ( I11I11i1I * 8 / ( 1024 * 1024 ) )
 if O00O0oOO00O00 < 2 :
  i1i = 'Very low quality streams might work.'
  iiI111I1iIiI = 'Expect buffering, do not try HD.'
  II = '[COLOR ghostwhite][B] Verdict: [I]Very Poor[/I]   | Score: [COLOR slategray][I]1/10[/I][/B][/COLOR]'
 elif O00O0oOO00O00 < 2.5 :
  i1i = 'You should be ok for SD content only.'
  iiI111I1iIiI = 'SD/DVD quality should be ok.'
  II = '[COLOR ghostwhite][B][I]Poor[/I]   | Score: [COLOR slategray][I]2/10[/I][/B][/COLOR]'
 elif O00O0oOO00O00 < 5 :
  i1i = 'Some HD streams might struggle, SD should be fine.'
  iiI111I1iIiI = '720p will be fine but some 1080p may struggle.'
  II = '[COLOR ghostwhite][B][I]OK[/I]   | Score: [COLOR slategray][I]4/10[/I][/B][/COLOR]'
 elif O00O0oOO00O00 < 9 :
  i1i = 'All streams including HD should stream fine.'
  iiI111I1iIiI = 'Movies (720p & 1080p) will stream fine but 3D and 4K will not.'
  II = '[COLOR ghostwhite][B][I]Good[/I]   | Score: [COLOR slategray][I]6/10[/I][/B][/COLOR]'
 elif O00O0oOO00O00 < 15 :
  i1i = 'All streams including HD should stream fine'
  iiI111I1iIiI = 'Movies (720p & 1080p and 3D) will stream fine but 4K may not.'
  II = '[COLOR ghostwhite][B][I]Very good[/I]   | Score: [COLOR slategray][I]8/10[/I][/B][/COLOR]'
 else :
  i1i = 'All streams including HD should stream fine'
  iiI111I1iIiI = 'You can play all movies (720p, 1080p, 3D and 4K)'
  II = '[COLOR ghostwhite][B][I]Excellent[/I]   | Score: [COLOR slategray][I]10/10[/I][/B][/COLOR]'
 print "Average Speed: " + str ( O00O0oOO00O00 )
 print "Max. Speed: " + str ( i1Oo00 )
 Ii1I1IIii1II = xbmcgui . Dialog ( )
 O0ii1ii1ii = Ii1I1IIii1II . ok (
 '[COLOR lightsteelblue][B]Your Result:[/COLOR][/B] ' + II ,
 '[COLOR lightsteelblue][B]Live Streams:[/COLOR][/B] ' + i1i ,
 '[COLOR lightsteelblue][B]Movie Streams:[/COLOR][/B] ' + iiI111I1iIiI ,
 '[COLOR lightsteelblue][B]Duration:[/COLOR][/B] %.02f secs ' % Oo0O00Oo0o0 + '[COLOR lightsteelblue][B]Average Speed:[/B][/COLOR] %.02f Mb/s ' % O00O0oOO00O00 + '[COLOR lightsteelblue][B]Max Speed:[/B][/COLOR] %.02f Mb/s ' % i1Oo00 ,
 )
 if 91 - 91: Oo0o0ooO0oOOO
 if 15 - 15: I1iII1iiII
 if 18 - 18: i11iIiiIii . i1IIi % OoooooooOO / O0
 if 75 - 75: Oo0ooO0oo0oO % I1i1iI1i % I1i1iI1i . I1
 if 5 - 5: I1i1iI1i * OOoOoo00oo + Oo0ooO0oo0oO . Oo0oO0ooo + Oo0ooO0oo0oO
zip = i1 . getSetting ( 'zip' )
Ii1I1IIii1II = xbmcgui . Dialog ( )
oO = xbmcgui . DialogProgress ( )
iIi1IIIi1 = xbmc . translatePath ( os . path . join ( 'special://home/userdata' , '' ) )
O0oOoOOOoOO = xbmc . translatePath ( os . path . join ( iIi1IIIi1 , 'addon_data' ) )
ii1ii11IIIiiI = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
O00OOOoOoo0O = xbmc . translatePath ( os . path . join ( iIi1IIIi1 , 'guisettings.xml' ) )
O000OOo00oo = xbmc . translatePath ( os . path . join ( iIi1IIIi1 , 'favourites.xml' ) )
oo0OOo = xbmc . translatePath ( os . path . join ( iIi1IIIi1 , 'favourites2.xml' ) )
ooOOO00Ooo = xbmc . translatePath ( os . path . join ( iIi1IIIi1 , 'sources.xml' ) )
IiIIIi1iIi = xbmc . translatePath ( os . path . join ( iIi1IIIi1 , 'advancedsettings.xml' ) )
ooOOoooooo = xbmc . translatePath ( os . path . join ( iIi1IIIi1 , 'RssFeeds.xml' ) )
II1I = xbmc . translatePath ( os . path . join ( iIi1IIIi1 , 'keymaps' , 'keyboard.xml' ) )
O0i1II1Iiii1I11 = xbmc . translatePath ( os . path . join ( zip ) )
IIII = xbmc . getSkinDir ( )
iiIiI = xbmc . translatePath ( 'special://home/' )
o00oooO0Oo = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , iIiiiI ) )
o0O0OOO0Ooo = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , iIiiiI , 'resources' , 'skins' ) )
iiIiII1 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , iIiiiI , 'flag.xml' ) )
OOO00O0O = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , 'skin.infinitytv_demo' , 'addon.xml' ) )
iii = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , 'script.cerebro.pairwith' , 'addon.xml' ) )
oOooOOOoOo = xbmc . translatePath ( os . path . join ( 'special://home' , 'media' , 'launch.jpg' ) )
i1Iii1i1I = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , iIiiiI , 'disclaimer.xml' ) )
OOoO00 = xbmc . translatePath ( os . path . join ( iIi1IIIi1 , 'addon_data' , 'skin.infinitytv-XK' , 'settings.xml' ) )
IiI111111IIII = "0.0.11"
i1Ii = "itv_wizard"
ii111iI1iIi1 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , iIiiiI , 'icon.png' ) )
if 78 - 78: o0OO0 . Oo0oO0ooo + o0OO0 / ooO0Oooo00 / o0OO0
if 54 - 54: Oo0ooO0oo0oO % i11iI
if 37 - 37: Oo0ooO0oo0oO * OOo / OOoOoo00oo - i11iI % I1iII1iiII . o00
if 88 - 88: i11iI . I1iII1iiII * I1iII1iiII % I1
if 15 - 15: i1IIi * I1Ii111 + i11iIiiIii
if 6 - 6: OOoOoo00oo / i11iIiiIii + i11iI * o00
def o00o0 ( ) :
 kodi . log ( 'CLEAR CACHE ACTIVATED' )
 ii = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
 OOooooO0Oo = xbmcgui . Dialog ( ) . yesno ( "Clear Cache" , "Press OK if you wish to clear" , "your Infinity TV cache" , "" , "Cancel" , "OK" )
 if OOooooO0Oo :
  if os . path . exists ( ii ) == True :
   for OO , iIiIIi1 , I1IIII1i in os . walk ( ii ) :
    I1I11i = 0
    I1I11i += len ( I1IIII1i )
    if I1I11i > 0 :
     if 5 - 5: OoooooooOO % Oo0ooO0oo0oO % o00 % i11iI
     if 7 - 7: I1iII1iiII + OoooooooOO . I1 . OOoOoo00oo - I1i1iI1i
     for II11 in I1IIII1i :
      try :
       os . unlink ( os . path . join ( OO , II11 ) )
      except :
       pass
     for i111I1 in iIiIIi1 :
      try :
       shutil . rmtree ( os . path . join ( OO , i111I1 ) )
      except :
       pass
       if 50 - 50: I1i1iI1i * ooO0Oooo00 % O0
       if 61 - 61: I1Ii111 - Oo0oO0ooo . o00 / Oo0oO0ooo + OOo
  Ii1I1IIii1II = xbmcgui . Dialog ( )
  Ii1I1IIii1II . ok ( '' , "Cache Cleared Successfully!" )
  xbmc . executebuiltin ( "Container.Refresh()" )
  if 5 - 5: OOoOoo00oo + OOoOoo00oo / O0 * OOo - Oo0oO0ooo % OOoOoo00oo
  if 15 - 15: i11iIiiIii % Ooo0 . OOo + o00ooo0
  if 61 - 61: OOo * o00ooo0 % OOo - i1IIi - iIii1I11I1II1
  if 74 - 74: o00ooo0 + I1iII1iiII / o0OO0
  if 100 - 100: Oo0ooO0oo0oO * iIii1I11I1II1
  if 86 - 86: o0OO0 * Oo0oO0ooo . i11iI
def iI ( ) :
 O0O0Oooo0o = xbmc . translatePath ( os . path . join ( 'special://home/addons/packages' , '' ) )
 OOooooO0Oo = xbmcgui . Dialog ( ) . yesno ( "Purge Packages" , "This will remove old zip files from your device that are no longer needed. " , "" , "Press OK to begin" , "Cancel" , "OK" )
 if OOooooO0Oo :
  try :
   for OO , iIiIIi1 , I1IIII1i in os . walk ( O0O0Oooo0o , topdown = False ) :
    for oOOoo00O00o in I1IIII1i :
     os . remove ( os . path . join ( OO , oOOoo00O00o ) )
    Ii1I1IIii1II = xbmcgui . Dialog ( )
    Ii1I1IIii1II . ok ( "Purge Packages" , "Old Zip Files Successfully Removed!" )
    xbmc . executebuiltin ( "Container.Refresh()" )
  except :
   Ii1I1IIii1II = xbmcgui . Dialog ( )
   Ii1I1IIii1II . ok ( II1i1Ii11Ii11 , "Error Deleting old zip files please visit Infinitytv.ca" )
   if 98 - 98: Oo0oO0ooo + Oo0o0ooO0oOOO + o00 % OoooooooOO
   if 97 - 97: O0 * OoooooooOO . OoooooooOO
I111iI = iIiiiI ; II1i1Ii11Ii11 = "Infinity TV: Network Speed Test"
oOOo0 = [ iIiiiI , 'skin.infinitytv-X-demo' , 'skin.infinitytv-XK-demo' ]
II1I1iiIII = [ iIiiiI , 'addon_data' , 'skin.infinitytv-X-demo' , 'skin.infinitytv-XK-demo' ]
oOOo0O00o = [ "favourites.xml" , "favourites2.xml" , "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "app.jpg" , "launch.jpg" , "Splash.png" ]
iIiIi11 = [ "favourites.xml" , "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "app.jpg" , "launch.jpg" , "Splash.png" ]
if 87 - 87: OOo . I1Ii111 - I1iII1iiII + O0 / OOo / o00
def IiI ( default = "" , heading = "" , hidden = False ) :
 IIIii1I = xbmc . Keyboard ( default , heading , hidden )
 if 97 - 97: O0 + Oo0ooO0oo0oO
 IIIii1I . doModal ( )
 if ( IIIii1I . isConfirmed ( ) ) :
  return unicode ( IIIii1I . getText ( ) , "utf-8" )
 return default
 if 89 - 89: I1i1iI1i + o0OO0 * ooO0Oooo00 * Ooo0
def iiIiI1i1 ( sourcefile , destfile , message_header , message1 , message2 , message3 , exclude_dirs , exclude_files ) :
 oO0O00oOOoooO = zipfile . ZipFile ( destfile , 'w' , zipfile . ZIP_DEFLATED )
 IiIi11iI = len ( sourcefile )
 Oo0O00O000 = [ ]
 i11I1IiII1i1i = [ ]
 oO . create ( message_header , message1 , message2 , message3 )
 for o0OO00 , iIiIIi1 , I1IIII1i in os . walk ( sourcefile ) :
  for file in I1IIII1i :
   i11I1IiII1i1i . append ( file )
 ooI1111i = len ( i11I1IiII1i1i )
 for o0OO00 , iIiIIi1 , I1IIII1i in os . walk ( sourcefile ) :
  iIiIIi1 [ : ] = [ i111I1 for i111I1 in iIiIIi1 if i111I1 not in exclude_dirs ]
  I1IIII1i [ : ] = [ II11 for II11 in I1IIII1i if II11 not in exclude_files ]
  for file in I1IIII1i :
   Oo0O00O000 . append ( file )
   iIIii = len ( Oo0O00O000 ) / float ( ooI1111i ) * 100
   oO . update ( int ( iIIii ) , "Backing up..." , '[COLOR yellow]%s[/COLOR]' % file , 'Please wait' )
   o00O0O = os . path . join ( o0OO00 , file )
   if not 'temp' in iIiIIi1 :
    if not iIiiiI in iIiIIi1 :
     import time
     ii1iii1i = '01/01/1980'
     Iii1I1111ii = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( o00O0O ) ) )
     if Iii1I1111ii > ii1iii1i :
      oO0O00oOOoooO . write ( o00O0O , o00O0O [ IiIi11iI : ] )
 oO0O00oOOoooO . close ( )
 oO . close ( )
 if 72 - 72: I1iII1iiII + i1IIi + I1i1iI1i
def OOO ( name , url , description ) :
 IIiI1i1i = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]VERY IMPORTANT: [/COLOR]" , 'This will completely wipe your infinity tv box settings.' , 'Would you like to create a backup before proceeding?' , '' , yeslabel = 'Yes' , nolabel = 'No' )
 if IIiI1i1i == 1 :
  O00Oo0 = urllib . quote_plus ( "backup" )
  IiII111i1i11 = xbmc . translatePath ( os . path . join ( o00oooO0Oo , O00Oo0 + '.zip' ) )
  i111iIi1i1II1 = [ iIiiiI , 'Thumbnails' ]
  iIiIi11 = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Textures13.db' ]
  oooO = "Creating backup... "
  i1I1i111Ii = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
  ooo = ""
  i1i1iI1iiiI = "Please wait"
  iiIiI1i1 ( iiIiI , IiII111i1i11 , oooO , i1I1i111Ii , ooo , i1i1iI1iiiI , i111iIi1i1II1 , iIiIi11 )
 if 51 - 51: I1Ii111 % I1 . o00 / iIii1I11I1II1 / ooO0Oooo00 . o00
 if 42 - 42: I1i1iI1i + i1IIi - Ooo0 / Oo0o0ooO0oOOO
 if 9 - 9: O0 % O0 - I1i1iI1i
 if 51 - 51: I1Ii111 . iIii1I11I1II1 - o00ooo0 / O0
 if 52 - 52: I1i1iI1i + O0 + i11iI + OOo % i11iI
 if 75 - 75: I1Ii111 . OOoOoo00oo . O0 * I1
 i11II1I11I1 = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]FINAL WARNING!!! [/COLOR]" , 'Are you absolutely certain about wiping your infinity tv box settings?' , '' , 'All addons and userdata will be gone!' , yeslabel = 'Yes' , nolabel = 'No' )
 if i11II1I11I1 == 0 :
  return
 elif i11II1I11I1 == 1 :
  iI1iI1I1i1I = 0
  oO . create ( "[B]ITV Updater/Installer[/B]" , "Wiping infinity tv Device..." , '' , 'Please wait' )
  try :
   for OO , iIiIIi1 , I1IIII1i in os . walk ( iiIiI , topdown = True ) :
    iIiIIi1 [ : ] = [ i111I1 for i111I1 in iIiIIi1 if i111I1 not in oOOo0 ]
    for name in I1IIII1i :
     iii11I111 = min ( 100 * iI1iI1I1i1I / name , 100 )
     try :
      os . remove ( os . path . join ( OO , name ) )
      os . rmdir ( os . path . join ( OO , name ) )
      oO . update ( iii11I111 )
     except : pass
     if 67 - 67: I1Ii111 - I1i1iI1i / ooO0Oooo00 - i1IIi
    for name in iIiIIi1 :
     oO . update ( iii11I111 )
     try : os . rmdir ( os . path . join ( OO , name ) ) ; os . rmdir ( OO )
     except : pass
  except : pass
 i1II1 ( )
 i1II1 ( )
 i1II1 ( )
 i1II1 ( )
 i1II1 ( )
 i1II1 ( )
 i1II1 ( )
 Ii1I1IIii1II . ok ( '[B]ITV Updater/Installer[/B]' , 'Wipe complete! Please restart infinity tv box for changes to take effect.' , '' , '' )
 return i11i1 ( name , url , description )
 if 42 - 42: i11iIiiIii * iIii1I11I1II1 / o00ooo0 . i11iIiiIii % ooO0Oooo00
def i1II1 ( ) :
 print "########### Start Removing Empty Folders #########"
 i1iI = 0
 IiI1iiiIii = 0
 for I1III1111iIi , I1i111I , I1IIII1i in os . walk ( iiIiI ) :
  if len ( I1i111I ) == 0 and len ( I1IIII1i ) == 0 :
   i1iI += 1
   os . rmdir ( I1III1111iIi )
   print "successfully removed: " + I1III1111iIi
  elif len ( I1i111I ) > 0 and len ( I1IIII1i ) > 0 :
   IiI1iiiIii += 1
   if 97 - 97: i1IIi . o00 / i11iI * O0
def o0O0o ( ) :
 IIiI1i1i = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]ITV Updater/Installer: [/COLOR]" , 'Would you like to create a backup?.' , 'Backup file will be stored in the plugin.video.itv_wizard folder.' , '' , yeslabel = 'Yes' , nolabel = 'No' )
 if IIiI1i1i == 1 :
  O00Oo0 = urllib . quote_plus ( "backup" )
  IiII111i1i11 = xbmc . translatePath ( os . path . join ( o00oooO0Oo , O00Oo0 + '.zip' ) )
  i111iIi1i1II1 = [ iIiiiI , 'Thumbnails' ]
  iIiIi11 = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Textures13.db' ]
  oooO = "Creating backup... "
  i1I1i111Ii = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
  ooo = ""
  i1i1iI1iiiI = "Please wait"
  iiIiI1i1 ( iiIiI , IiII111i1i11 , oooO , i1I1i111Ii , ooo , i1i1iI1iiiI , i111iIi1i1II1 , iIiIi11 )
  Ii1I1IIii1II . ok ( '[B]ITV Updater/Installer[/B]' , 'Backup complete!' , '' , '' )
 else :
  return
  if 77 - 77: Oo0ooO0oo0oO - I1Ii111 * i11iIiiIii * OOoOoo00oo * iIii1I11I1II1
def oOo0 ( ) :
 DialogITVTerms . show ( )
 if 56 - 56: I1i1iI1i + I1iII1iiII + Oo0ooO0oo0oO - OOoOoo00oo . Oo0ooO0oo0oO
 if 84 - 84: o0OO0 + i1IIi - I1iII1iiII . o00ooo0 * OoooooooOO + I1Ii111
 if 38 - 38: Oo0oO0ooo + I1iII1iiII % OOoOoo00oo % Oo0ooO0oo0oO - Ooo0 / OoooooooOO
 if 73 - 73: I1i1iI1i * O0 - i11iIiiIii
 if 85 - 85: Ooo0 % i11iI + ooO0Oooo00 / I1i1iI1i . o00 + Oo0oO0ooo
 if 62 - 62: i11iIiiIii + i11iIiiIii - I1i1iI1i
 if 28 - 28: i11iI . i11iI % iIii1I11I1II1 * iIii1I11I1II1 . I1i1iI1i / i11iI
 if 27 - 27: o0OO0 + OOoOoo00oo - i1IIi
 if 69 - 69: Oo0o0ooO0oOOO - O0 % o00ooo0 + i11iIiiIii . Oo0ooO0oo0oO / o0OO0
 if 79 - 79: O0 * i11iIiiIii - Oo0o0ooO0oOOO / Oo0o0ooO0oOOO
 if 48 - 48: O0
 if 93 - 93: i11iIiiIii - I1Ii111 * o00ooo0 * ooO0Oooo00 % O0 + OoooooooOO
 if 25 - 25: Oo0o0ooO0oOOO + Ooo0 / OOoOoo00oo . I1i1iI1i % O0 * o0OO0
 if 84 - 84: OOoOoo00oo % Ooo0 + i11iIiiIii
 if 28 - 28: OOo + o0OO0 * Oo0oO0ooo % o00 . ooO0Oooo00 % O0
 if 16 - 16: ooO0Oooo00 - iIii1I11I1II1 / I1Ii111 . I1iII1iiII + iIii1I11I1II1
 if 19 - 19: o0OO0 - OOo . O0
 if 60 - 60: I1iII1iiII + OOo
 if 9 - 9: OOoOoo00oo * OoooooooOO - iIii1I11I1II1 + Oo0ooO0oo0oO / o0OO0 . o0OO0
iiIIi = xbmc . translatePath ( os . path . join ( o0O0OOO0Ooo , 'wipe.png' ) )
iiI1iI111ii1i = xbmc . translatePath ( os . path . join ( o0O0OOO0Ooo , 'support.png' ) )
Ii1IIiI1IiIII = xbmc . translatePath ( os . path . join ( o0O0OOO0Ooo , 'fanart.jpg' ) )
OO0Oo000OOOoO = xbmc . translatePath ( os . path . join ( o0O0OOO0Ooo , 'restore.png' ) )
O0i11I1I1I = xbmc . translatePath ( os . path . join ( o0O0OOO0Ooo , 'backup.png' ) )
oOOOo00O00O = xbmc . translatePath ( os . path . join ( o0O0OOO0Ooo , 'full_restore.png' ) )
iIIIII1I = xbmc . translatePath ( os . path . join ( o0O0OOO0Ooo , 'adult_full_restore.png' ) )
ooI1i = xbmc . translatePath ( os . path . join ( o0O0OOO0Ooo , 'updates.png' ) )
iIII = xbmc . translatePath ( os . path . join ( o0O0OOO0Ooo , 'restore_backup.png' ) )
o0o0O = xbmc . translatePath ( os . path . join ( o0O0OOO0Ooo , 'stepone.png' ) )
ooooO0oOoOOoO = xbmc . translatePath ( os . path . join ( o0O0OOO0Ooo , 'steptwo.png' ) )
I1i11i = xbmc . translatePath ( os . path . join ( o0O0OOO0Ooo , 'stepthree.png' ) )
IiIi = xbmc . translatePath ( os . path . join ( o0O0OOO0Ooo , 'fixes.png' ) )
OOOOO0O00 = xbmc . translatePath ( os . path . join ( o0O0OOO0Ooo , 'default_restore.png' ) )
Iii = xbmc . translatePath ( os . path . join ( o0O0OOO0Ooo , 'maintool.png' ) )
iIIiIiI1I1 = xbmc . translatePath ( os . path . join ( o0O0OOO0Ooo , 'network.png' ) )
ooO = xbmc . translatePath ( os . path . join ( o0O0OOO0Ooo , 'clear_cache.png' ) )
iiOO0O0Ooo = xbmc . translatePath ( os . path . join ( o0O0OOO0Ooo , 'update_addons.png' ) )
oOoO0 = xbmc . translatePath ( os . path . join ( o0O0OOO0Ooo , 'term.png' ) )
Oo0 = xbmc . translatePath ( os . path . join ( o0O0OOO0Ooo , 'purge.png' ) )
oo0O0o00o0O = xbmc . translatePath ( os . path . join ( o0O0OOO0Ooo , 'apk.png' ) )
I11i1II = xbmc . translatePath ( os . path . join ( o0O0OOO0Ooo , 'pair.png' ) )
if 72 - 72: iIii1I11I1II1 . i1IIi / OOo . I1iII1iiII
def ooo000o000 ( ) :
 print "###############################################################################################################################################"
 if 100 - 100: Oo0o0ooO0oOOO . ooO0Oooo00 / Ooo0 % Oo0ooO0oo0oO % I1iII1iiII - o0OO0
 if 46 - 46: O0 * I1iII1iiII - OOo * OOoOoo00oo
 if 33 - 33: Ooo0
 if 74 - 74: Oo0oO0ooo + O0 + i1IIi - i1IIi + I1iII1iiII
 if 83 - 83: o00ooo0 - I1Ii111 + Oo0oO0ooo
 if 5 - 5: Ooo0
 if 46 - 46: Oo0o0ooO0oOOO
 if 45 - 45: OOoOoo00oo
 if 21 - 21: o00 . I1 . Oo0oO0ooo / OOo / I1
 if 17 - 17: Oo0oO0ooo / Oo0oO0ooo / ooO0Oooo00
 if 1 - 1: i1IIi . i11iIiiIii % Oo0oO0ooo
 if 82 - 82: iIii1I11I1II1 + OOo . iIii1I11I1II1 % Oo0o0ooO0oOOO / Ooo0 . Ooo0
 if 14 - 14: I1i1iI1i . Oo0oO0ooo . ooO0Oooo00 + OoooooooOO - Oo0oO0ooo + Oo0o0ooO0oOOO
 if 9 - 9: Ooo0
 if 59 - 59: I1Ii111 * I1iII1iiII . O0
 if 56 - 56: Ooo0 - i11iI % I1Ii111 - I1i1iI1i
 if 51 - 51: O0 / OOoOoo00oo * iIii1I11I1II1 + o00ooo0 + I1i1iI1i
 if 98 - 98: iIii1I11I1II1 * o00ooo0 * Oo0oO0ooo + OOoOoo00oo % i11iIiiIii % O0
 if 27 - 27: O0
 if 79 - 79: I1i1iI1i - ooO0Oooo00 + I1i1iI1i . o00
 if 28 - 28: i1IIi - i11iI
 if 54 - 54: i11iI - O0 % Oo0oO0ooo
 if 73 - 73: O0 . Oo0ooO0oo0oO + I1Ii111 - ooO0Oooo00 % ooO0Oooo00 . ooO0Oooo00
 if 17 - 17: Ooo0 - OoooooooOO % Ooo0 . Oo0o0ooO0oOOO / i11iIiiIii % i11iI
 if 28 - 28: ooO0Oooo00
 if 58 - 58: Oo0ooO0oo0oO
 if 37 - 37: OOo - iIii1I11I1II1 / o00ooo0
 if 73 - 73: i11iIiiIii - Oo0o0ooO0oOOO
 if 25 - 25: OoooooooOO + Oo0o0ooO0oOOO * o00ooo0
 if 92 - 92: I1Ii111 + ooO0Oooo00 + O0 / I1i1iI1i + I1
 if 18 - 18: OOoOoo00oo * Oo0ooO0oo0oO . i11iI / o00ooo0 / i11iIiiIii
 if 21 - 21: o00 / o00ooo0 + Ooo0 + OoooooooOO
 if 91 - 91: i11iIiiIii / i1IIi + i11iI + OOoOoo00oo * i11iIiiIii
 if 66 - 66: iIii1I11I1II1 % i1IIi - O0 + ooO0Oooo00 * I1 . Oo0o0ooO0oOOO
 if 52 - 52: OOoOoo00oo + O0 . i11iI . o00ooo0 . o0OO0
 OOoO000O0OO = O0O00Ooo ( O0O ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 oo000 = re . compile ( 'update="(.+?)".+?ull_restore="(.+?)".+?dult_full_restore="(.+?)".+?upport_full_restore="(.+?)".+?upport_update="(.+?)"' ) . findall ( OOoO000O0OO )
 for iiOoO , Iiiiii111i1ii , i1i1iII1 , iii11i1IIII , Ii in oo000 :
  o00iiI1Ii1 = iiOoO
  ii1i = Iiiiii111i1ii
  oOOoo = i1i1iII1
  if 14 - 14: I1i1iI1i * o00
  O0OOO0OOooo00 ( 'Update & Install Software ' + '[COLOR white] ' + ii1i + '[/COLOR]' , i1iII1IiiIiI1 , 6 , oOOOo00O00O , Ii1IIiI1IiIII , '' )
  O0OOO0OOooo00 ( 'Fixes - ' + '[COLOR white] ' + o00iiI1Ii1 + '[/COLOR]' , iIiiiI1IiI1I1 , 15 , IiIi , Ii1IIiI1IiIII , 'All fixes will be shown here!' )
  I111iIi1 ( 'APK App Installer' , I11i1i11i1I , 80 , oo0O0o00o0O , Ii1IIiI1IiIII , 'Insatall Anrdoid Apps. ' )
  O0OOO0OOooo00 ( 'Factory Restore' , i1i1II , 16 , OOOOO0O00 , Ii1IIiI1IiIII , 'All addons and userdata will be completely wiped!' )
  if 92 - 92: OOoOoo00oo
  O0OOO0OOooo00 ( 'Terms & Conditions' , oo , 3 , oOoO0 , Ii1IIiI1IiIII , 'Terms & Conditions info from your TV box seller. ' )
  if 95 - 95: OoooooooOO - Oo0o0ooO0oOOO * I1Ii111 + Oo0ooO0oo0oO
  if 10 - 10: I1i1iI1i / i11iIiiIii
  if 92 - 92: ooO0Oooo00 . I1
  if 85 - 85: o00ooo0 . I1
def O0O0Ooooo000 ( ) :
 I111iIi1 ( 'Network Speed Test' , i1i1II , 98 , iIIiIiI1I1 , Ii1IIiI1IiIII , 'Test your network speed on your Infinity TV' )
 O0OOO0OOooo00 ( 'Clear Cache' , i1i1II , 96 , ooO , Ii1IIiI1IiIII , '' )
 O0OOO0OOooo00 ( 'Update Add-ons' , i1i1II , 95 , iiOO0O0Ooo , Ii1IIiI1IiIII , '' )
 O0OOO0OOooo00 ( 'Purge Packages (use once or twice a month)' , i1i1II , 90 , Oo0 , Ii1IIiI1IiIII , '' )
 if ( os . path . isfile ( iii ) ) :
  O0OOO0OOooo00 ( 'Easy To Pair' , i1i1II , 83 , I11i1II , Ii1IIiI1IiIII , '' )
  if 65 - 65: Oo0oO0ooo * I1
  if 79 - 79: OoooooooOO - I1Ii111
def speedtest ( ) :
 o00O00oO00 = base64 . b64decode ( "aHR0cDovL2luZGlnby50dmFkZG9ucy5hZy9zcGVlZHRlc3Qvc3BlZWR0ZXN0ZmlsZS50eHQ=" )
 OOoO000O0OO = O0O00Ooo ( o00O00oO00 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 oo000 = re . compile ( 'name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?ersion="(.+?)"' ) . findall ( OOoO000O0OO )
 for oOOoo00O00o , Ii1i1i1i1I1Ii , iiiI1 , OOOoO0O , o0 in oo000 :
  O0OOO0OOooo00 ( '[COLOR ghostwhite]' + oOOoo00O00o + " | " + o0 + '[/COLOR]' , Ii1i1i1i1I1Ii , 97 , ii111iI1iIi1 , Ii1IIiI1IiIII , '' )
  if 30 - 30: O0 * OoooooooOO
  if 38 - 38: Oo0o0ooO0oOOO - o00ooo0 . Oo0ooO0oo0oO - I1 . OoooooooOO
def oooOooooO0oOO ( name , url , description ) :
 if 30 - 30: OoooooooOO - OoooooooOO . O0 / i11iI
 if 31 - 31: Oo0oO0ooo + I1i1iI1i . OoooooooOO
 url = oo00000o0
 name = 'skin.infinitytv'
 ooOooo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
 oO = xbmcgui . DialogProgress ( )
 oO . create ( "ITV Updater/Installer" , "Applying update... " , '' , 'Please wait' )
 oO0OO0 = os . path . join ( ooOooo0 , name + '.zip' )
 try :
  os . remove ( oO0OO0 )
 except :
  pass
 downloader . download ( url , oO0OO0 , oO )
 o0O0Oo00 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
 time . sleep ( 2 )
 oO . update ( 0 , "" , "Installing..." )
 extract . all ( oO0OO0 , o0O0Oo00 , oO )
 oO . update ( 0 , "" , "Finishing up..." )
 time . sleep ( 5 )
 Ii1I1IIii1II = xbmcgui . Dialog ( )
 Ii1I1IIii1II . ok ( "ITV Updater/Installer" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish update. [/COLOR]" )
 if 51 - 51: Oo0oO0ooo % iIii1I11I1II1 - OoooooooOO % OOoOoo00oo * iIii1I11I1II1 % o0OO0
 if 99 - 99: o00 * I1iII1iiII * I1
 if 92 - 92: OOo
def iI11I ( name , url , description ) :
 DialogITVTermsapps . show ( )
 OOoO000O0OO = O0O00Ooo ( url ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 oo000 = re . compile ( 'name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"' ) . findall ( OOoO000O0OO )
 for name , ooO000 , url , oOOOO , OOOoO0O , IiIi1ii111i1 , description in oo000 :
  O0OOO0OOooo00 ( '[COLOR white]' + name + '[/COLOR]' , url , 81 , oOOOO , OOOoO0O , description )
  if 31 - 31: Oo0oO0ooo + O0
def oO0oOOoo00000 ( name , url , description ) :
 oO = xbmcgui . DialogProgress ( )
 oOo00 = xbmcgui . Dialog ( ) . yesno ( "[COLOR white]Would you like to download and install: [/COLOR]" , name , '' , '' , yeslabel = 'YES' , nolabel = 'NO' )
 if oOo00 == 0 :
  return
 elif oOo00 == 1 :
  if 3 - 3: i11iI % i1IIi
  if 46 - 46: I1iII1iiII % I1i1iI1i % iIii1I11I1II1 - OOo . OoooooooOO - Oo0o0ooO0oOOO
  ooOooo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
  oO = xbmcgui . DialogProgress ( )
  name = name . replace ( '\\' , '' ) . replace ( '/' , '' ) . replace ( ':' , '' ) . replace ( '*' , '' ) . replace ( '?' , '' ) . replace ( '"' , '' ) . replace ( '<' , '' ) . replace ( '>' , '' ) . replace ( '|' , '' )
  oO . create ( "APK App Installer" , "Downloading... " , '' , 'Please wait' )
  oO0OO0 = os . path . join ( ooOooo0 , name + '.apk' )
  try :
   os . remove ( oO0OO0 )
  except :
   pass
  downloader . download ( url , oO0OO0 , oO )
  o0O0Oo00 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
  time . sleep ( 2 )
  oO . update ( 0 , "" , "Installing..." )
  o00ooO00O ( name )
  xbmc . executebuiltin ( 'StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:' + oO0OO0 + '")' )
  xbmc . sleep ( 10 )
  oo00o0 = xbmcgui . Dialog ( ) . yesno ( "[COLOR white]Please press YES to to finish the Install. [/COLOR]" , '' , '' , '' , yeslabel = 'YES' , nolabel = 'NO' )
  if oo00o0 == 0 :
   return
  elif oo00o0 == 1 :
   try :
    os . remove ( oO0OO0 )
   except :
    pass
    if 65 - 65: I1iII1iiII . I1Ii111 % o00 * o0OO0
def o00ooO00O ( name ) :
 class iI11II1IIIiii1 ( xbmcgui . WindowXMLDialog ) :
  def __init__ ( self , * args , ** kwargs ) :
   self . shut = kwargs [ 'close_time' ]
   xbmc . executebuiltin ( "Skin.Reset(AnimeWindowXMLDialogClose)" )
   xbmc . executebuiltin ( "Skin.SetBool(AnimeWindowXMLDialogClose)" )
   if 65 - 65: ooO0Oooo00 / I1iII1iiII * Ooo0 . i11iI * o00 % Oo0oO0ooo
  def onClick ( self , controlID ) : self . CloseWindow ( )
  if 69 - 69: OOoOoo00oo - o0OO0 / i11iIiiIii + o00ooo0 % OoooooooOO
  def onAction ( self , action ) :
   if action in [ ACTION_PREVIOUS_MENU , ACTION_BACKSPACE , ACTION_NAV_BACK , ACTION_SELECT_ITEM , ACTION_MOUSE_LEFT_CLICK , ACTION_MOUSE_LONG_CLICK ] : self . CloseWindow ( )
   if 73 - 73: Ooo0 - I1
  def CloseWindow ( self ) :
   xbmc . executebuiltin ( "Skin.Reset(AnimeWindowXMLDialogClose)" )
   xbmc . sleep ( 400 )
   self . close ( )
   if 68 - 68: i11iI * OoooooooOO * iIii1I11I1II1 . I1iII1iiII
   if 81 - 81: Oo0oO0ooo / O0 + ooO0Oooo00 + Ooo0 / I1Ii111
   if 27 - 27: Oo0ooO0oo0oO * Oo0o0ooO0oOOO
   if 59 - 59: Oo0o0ooO0oOOO . Oo0o0ooO0oOOO - I1iII1iiII + Oo0o0ooO0oOOO . i1IIi . o0OO0
   if 57 - 57: I1Ii111 + Ooo0 % o00 + o00 / I1iII1iiII . Ooo0
   if 17 - 17: Ooo0 + o00 . o0OO0 - OOo * i11iIiiIii
   if 20 - 20: I1Ii111 . OoooooooOO % Oo0oO0ooo
   if 63 - 63: I1Ii111 % iIii1I11I1II1
def I1ii ( name , url , description ) :
 url = o0OOO
 name = 'skin.infinitytv'
 ooOooo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
 oO = xbmcgui . DialogProgress ( )
 oO . create ( "ITV Updater/Installer" , "Fixing skin issues... " , '' , 'Please wait' )
 oO0OO0 = os . path . join ( ooOooo0 , name + '.zip' )
 try :
  os . remove ( oO0OO0 )
 except :
  pass
 downloader . download ( url , oO0OO0 , oO )
 o0O0Oo00 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
 time . sleep ( 2 )
 oO . update ( 0 , "" , "Installing..." )
 extract . all ( oO0OO0 , o0O0Oo00 , oO )
 oO . update ( 0 , "" , "Finishing up..." )
 time . sleep ( 5 )
 Ii1I1IIii1II = xbmcgui . Dialog ( )
 Ii1I1IIii1II . ok ( "ITV Updater/Installer" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish update. [/COLOR]" )
 if 73 - 73: Oo0o0ooO0oOOO + I1Ii111 * OOo * OoooooooOO
def Oo0o0O ( name , url , description ) :
 Ii1I1IIii1II = xbmcgui . Dialog ( )
 Ii1I1IIii1II . ok ( "ITV Updater/Installer" , "[COLOR blue]Please press YES on the next popup. [/COLOR]" , "" , "Then move to STEP TWO!" )
 ii1iIi1II ( 'lookandfeel.skin' , 'skin.infinitytv_demo' )
 if 2 - 2: OOo + Oo0ooO0oo0oO - Oo0oO0ooo . I1Ii111 - Oo0oO0ooo
def oo0o0oooo ( name , url , description ) :
 O0OOO0OOooo00 ( 'STEP ONE' , o0OOO , 12 , o0o0O , Ii1IIiI1IiIII , 'All addons and userdata will be completely wiped!' )
 O0OOO0OOooo00 ( 'STEP TWO' , o0OOO , 13 , ooooO0oOoOOoO , Ii1IIiI1IiIII , 'All addons and userdata will be completely wiped!' )
 II11iI111i1 ( 'movies' , 'MAIN' )
 if 20 - 20: i1IIi - ooO0Oooo00
 if 30 - 30: Oo0ooO0oo0oO
def Ii111 ( name , url , description ) :
 oO0 = 'lookandfeel.skin'
 IIII = i1iIii ( oO0 )
 if 81 - 81: O0 % Ooo0
 if ( os . path . isfile ( iiIiII1 ) ) :
  Ii1I1IIii1II = xbmcgui . Dialog ( )
  Ii1I1IIii1II . ok ( "ITV Updater/Installer" , "[COLOR blue]Please press Ok and then Click on Step 1, and follow the next prompts![/COLOR]" )
  if 5 - 5: OoooooooOO - o0OO0 + Oo0o0ooO0oOOO - i11iI . o0OO0 / OOoOoo00oo
 O0OOO0OOooo00 ( 'STEP ONE' , i1iII1IiiIiI1 , 7 , o0o0O , Ii1IIiI1IiIII , 'All addons and userdata will be completely wiped!' )
 O0OOO0OOooo00 ( 'STEP TWO' , i1iII1IiiIiI1 , 6 , ooooO0oOoOOoO , Ii1IIiI1IiIII , 'All addons and userdata will be completely wiped!' )
 O0OOO0OOooo00 ( 'STEP THREE' , i1iII1IiiIiI1 , 8 , I1i11i , Ii1IIiI1IiIII , 'All addons and userdata will be completely wiped!' )
 II11iI111i1 ( 'movies' , 'MAIN' )
 if 28 - 28: Ooo0 * Ooo0 - iIii1I11I1II1
def ooOO00oOOo000 ( name , url , description ) :
 if ( os . path . isfile ( iiIiII1 ) ) :
  Ii1I1IIii1II = xbmcgui . Dialog ( )
  Ii1I1IIii1II . ok ( "ITV Updater/Installer" , "[COLOR blue]Please press Ok and then Click on Step 1, and follow the next prompts![/COLOR]" )
  if 14 - 14: o0OO0 . I1iII1iiII . ooO0Oooo00 / Ooo0 % o00ooo0 - OOoOoo00oo
 O0OOO0OOooo00 ( 'STEP ONE' , iIiiiI1IiI1I1 , 7 , o0o0O , Ii1IIiI1IiIII , 'All addons and userdata will be completely wiped!' )
 O0OOO0OOooo00 ( 'STEP TWO' , iIiiiI1IiI1I1 , 6 , ooooO0oOoOOoO , Ii1IIiI1IiIII , 'All addons and userdata will be completely wiped!' )
 O0OOO0OOooo00 ( 'STEP THREE' , iIiiiI1IiI1I1 , 8 , I1i11i , Ii1IIiI1IiIII , 'All addons and userdata will be completely wiped!' )
 II11iI111i1 ( 'movies' , 'MAIN' )
 if 67 - 67: ooO0Oooo00 - Oo0oO0ooo . i1IIi
def I1I1iI ( ) :
 try :
  os . remove ( iiIiII1 )
 except :
  pass
 oO0 = 'lookandfeel.skin'
 IIII = i1iIii ( oO0 )
 Ii1I1IIii1II = xbmcgui . Dialog ( )
 Ii1I1IIii1II . ok ( "ITV Updater/Installer" , "[COLOR blue]The next popup window will ask \"Would you like to keep this change?\" Click YES and then proceed to Step Two [/COLOR]" , "" , "" )
 ii1iIi1II ( 'lookandfeel.skin' , 'skin.infinitytv_demo' )
 if 16 - 16: Oo0o0ooO0oOOO * Oo0ooO0oo0oO . OOoOoo00oo / i1IIi . o0OO0 - i1IIi
def I1IiIIi ( ) :
 oO0 = 'lookandfeel.skin'
 IIII = i1iIii ( oO0 )
 Ii1I1IIii1II = xbmcgui . Dialog ( )
 Ii1I1IIii1II . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next pop-up window after you click OK below, will ask you if you want to \"Keep Skin?\". Always click YES to this." , "" , "Please note: If you take to long, it will automatically​ press YES for you as a fail safe." )
 I1Ii = xbmc . getInfoLabel ( "System.BuildVersion" )
 I1Ii = I1Ii . split ( "." ) [ 0 ]
 if I1Ii == "17" :
  ii1iIi1II ( 'lookandfeel.skin' , 'skin.infinitytv-XK-demo' )
 else :
  ii1iIi1II ( 'lookandfeel.skin' , 'skin.infinitytv-X-demo' )
  if 42 - 42: O0 . o00 - I1i1iI1i / i1IIi
def OooOOO ( ) :
 xbmc . executebuiltin ( 'ReloadSkin()' )
 if 48 - 48: iIii1I11I1II1 % i1IIi % i11iI + OOoOoo00oo
def Iiii11iIi1 ( ) :
 xbmc . executebuiltin ( 'UnloadSkin()' )
 if 40 - 40: ooO0Oooo00 % o0OO0 . I1
 if 84 - 84: Oo0ooO0oo0oO % OOoOoo00oo - Oo0ooO0oo0oO . I1i1iI1i
def ii1iIi1II ( setting , value ) :
 setting = '"%s"' % setting
 if 5 - 5: Oo0ooO0oo0oO * I1 - o00ooo0 / iIii1I11I1II1 % o00 + Oo0o0ooO0oOOO
 if isinstance ( value , list ) :
  o00o00OoO00o0 = ''
  for OOoOoO00O0O0o in value :
   o00o00OoO00o0 += '"%s",' % str ( OOoOoO00O0O0o )
   if 12 - 12: o00ooo0 + o0OO0 % ooO0Oooo00
  o00o00OoO00o0 = o00o00OoO00o0 [ : - 1 ]
  o00o00OoO00o0 = '[%s]' % o00o00OoO00o0
  value = o00o00OoO00o0
  if 85 - 85: i11iI * I1i1iI1i
 elif not isinstance ( value , int ) :
  value = '"%s"' % value
  if 3 - 3: Oo0oO0ooo
 IiiO0o0o = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % ( setting , value )
 xbmc . executeJSONRPC ( IiiO0o0o )
 if 87 - 87: ooO0Oooo00 * i1IIi - Ooo0 % Oo0oO0ooo / I1
def i1iIii ( setting ) :
 if 39 - 39: I1Ii111 * i11iIiiIii - o00 / Oo0o0ooO0oOOO % I1 % ooO0Oooo00
 import json
 setting = '"%s"' % setting
 if 65 - 65: o00 - OOoOoo00oo % OoooooooOO / OoooooooOO % OoooooooOO
 IiiO0o0o = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % ( setting )
 i1iIIIiI1I = xbmc . executeJSONRPC ( IiiO0o0o )
 if 52 - 52: o00ooo0 + o00ooo0 . I1iII1iiII
 i1iIIIiI1I = json . loads ( i1iIIIiI1I )
 if 34 - 34: OoooooooOO . O0 / o00 * Oo0ooO0oo0oO - o00ooo0
 if i1iIIIiI1I . has_key ( 'result' ) :
  if i1iIIIiI1I [ 'result' ] . has_key ( 'value' ) :
   return i1iIIIiI1I [ 'result' ] [ 'value' ]
   if 36 - 36: i1IIi / O0 / o0OO0 - O0 - i1IIi
   if 22 - 22: i1IIi + Ooo0
def i11i1 ( name , url , description ) :
 if 54 - 54: OOoOoo00oo % Oo0oO0ooo . I1 + o00 - Oo0oO0ooo * I1Ii111
 ooOooo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
 oO = xbmcgui . DialogProgress ( )
 oO . create ( "ITV Updater/Installer" , "Downloading... " , '' , 'Please wait' )
 oO0OO0 = os . path . join ( ooOooo0 , name + '.zip' )
 try :
  os . remove ( oO0OO0 )
 except :
  pass
 downloader . download ( url , oO0OO0 , oO )
 o0O0Oo00 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
 if 92 - 92: I1i1iI1i + I1 / OOo % o0OO0 % Oo0o0ooO0oOOO . OoooooooOO
 time . sleep ( 2 )
 oO . update ( 0 , "" , "Installing..." )
 extract . all ( oO0OO0 , o0O0Oo00 , oO )
 oO . update ( 0 , "" , "Finishing up..." )
 time . sleep ( 5 )
 if 52 - 52: OOoOoo00oo / i11iIiiIii - Oo0oO0ooo . Oo0o0ooO0oOOO % iIii1I11I1II1 + I1i1iI1i
 if 71 - 71: o00 % ooO0Oooo00 * Oo0ooO0oo0oO . O0 / Ooo0 . o00ooo0
 if 58 - 58: OOo / o00
 if 44 - 44: Oo0oO0ooo
 Ii1I1IIii1II = xbmcgui . Dialog ( )
 Ii1I1IIii1II . ok ( "ITV Updater/Installer" , "[COLOR blue]Installation nearly complete but one important step remains. [/COLOR]" )
 Ii1I1IIii1II = xbmcgui . Dialog ( )
 Ii1I1IIii1II . ok ( "ITV Updater/Installer" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish setup. [/COLOR]" )
 if 54 - 54: Ooo0 - ooO0Oooo00 - I1 . iIii1I11I1II1
def o0O ( ) :
 try :
  os . remove ( iiIiII1 )
 except :
  pass
  if 40 - 40: I1i1iI1i + OOo . I1i1iI1i % OOoOoo00oo
def I11I1IIiiII1 ( name , url , description ) :
 oO = xbmcgui . DialogProgress ( )
 oOo00 = xbmcgui . Dialog ( ) . yesno ( "[B]ITV Updater/Installer[/B]" , 'By pressing YES you will install ' , 'the latest version of our software.' , '' , yeslabel = 'YES' , nolabel = 'NO' )
 if oOo00 == 0 :
  return
 elif oOo00 == 1 :
  if I1Ii == "17" :
   url = krypton_defualt_build_link
   if 31 - 31: I1Ii111 * o00 + OoooooooOO - i11iI / OoooooooOO
  else :
   url = i1i1II
   if 19 - 19: Oo0o0ooO0oOOO * OOoOoo00oo * I1i1iI1i + O0 / O0
  I1IiIIi ( )
  time . sleep ( 10 )
  xbmc . executebuiltin ( 'SendClick(11)' )
  Ii1I1IIii1II = xbmcgui . Dialog ( )
  Ii1I1IIii1II . ok ( "[B]ITV Updater/Installer[/B]" , "Click ok to start the process!" , '' , '' )
  oO = xbmcgui . DialogProgress ( )
  oO . create ( "[B]ITV Updater/Installer[/B]" , "Wiping Infinity TV device..." , '' , 'Please wait as it will take a few minutes' )
  time . sleep ( 1 )
  oO . update ( 10 , "" , 'Preparing files...' , 'Please wait' )
  time . sleep ( 3 )
  try :
   for OO , iIiIIi1 , I1IIII1i in os . walk ( iiIiI , topdown = True ) :
    iIiIIi1 [ : ] = [ i111I1 for i111I1 in iIiIIi1 if i111I1 not in oOOo0 ]
    I1IIII1i [ : ] = [ II11 for II11 in I1IIII1i if II11 not in iIiIi11 ]
    for name in I1IIII1i :
     try :
      os . remove ( os . path . join ( OO , name ) )
      oO . update ( 30 , "" , 'Removing files...' , 'Please wait' )
      os . rmdir ( os . path . join ( OO , name ) )
     except : pass
     if 73 - 73: iIii1I11I1II1 / iIii1I11I1II1 - o00
    for name in iIiIIi1 :
     try : os . rmdir ( os . path . join ( OO , name ) ) ; os . rmdir ( OO )
     except : pass
  except : pass
  oO . update ( 60 , "" , "Removing folders..." )
  i1II1 ( )
  i1II1 ( )
  i1II1 ( )
  oO . update ( 75 , "" , "Removing folders..." )
  i1II1 ( )
  i1II1 ( )
  i1II1 ( )
  i1II1 ( )
  if 91 - 91: o00 + I1Ii111
  if 59 - 59: I1Ii111 + i11iIiiIii + i1IIi / ooO0Oooo00
  oO . update ( 99 , "" , "Almost done..." )
  time . sleep ( 3 )
  ooOooo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
  oO = xbmcgui . DialogProgress ( )
  oO . create ( "ITV Updater/Installer" , "Wipe complete!" , 'Now Downloading...' , 'Please wait' )
  if 44 - 44: ooO0Oooo00 . Oo0ooO0oo0oO * I1Ii111 + OoooooooOO - i11iI - Oo0o0ooO0oOOO
  oO0OO0 = os . path . join ( ooOooo0 , 'fullbackup.zip' )
  try :
   os . remove ( oO0OO0 )
  except :
   pass
  downloader . download ( url , oO0OO0 , oO )
  o0O0Oo00 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
  time . sleep ( 2 )
  oO . update ( 0 , "" , "Installing..." )
  extract . all ( oO0OO0 , o0O0Oo00 , oO )
  oO . update ( 0 , "" , "Finishing up..." )
  time . sleep ( 3 )
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  time . sleep ( 2 )
  Ii1I1IIii1II = xbmcgui . Dialog ( )
  Ii1I1IIii1II . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next pop-up window after you click OK below, will ask you if you want to \"Keep Skin?\". Always click YES to this." , "" , "Please note: If you take to long, it will automatically​ press YES for you as a fail safe." )
  try :
   os . remove ( oO0OO0 )
  except :
   pass
  if I1Ii == "17" :
   ii1iIi1II ( 'lookandfeel.skin' , 'skin.infinitytv-XK' )
  else :
   ii1iIi1II ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
  Ii1I1IIii1II = xbmcgui . Dialog ( )
  time . sleep ( 10 )
  xbmc . executebuiltin ( 'SendClick(11)' )
  if 15 - 15: Oo0o0ooO0oOOO / O0 . I1i1iI1i . i11iIiiIii
  try :
   os . remove ( i1Iii1i1I )
  except :
   pass
  Ii1I1IIii1II . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Installation is complete. [CR]Please press OK and wait while your Infinity TV app shuts down to apply the changes" )
  if 59 - 59: I1 - I1i1iI1i - OOoOoo00oo
  os . _exit ( 1 )
  if 48 - 48: i1IIi + ooO0Oooo00 % Oo0ooO0oo0oO / OOo - I1i1iI1i
  if 67 - 67: o00 % I1i1iI1i . OoooooooOO + Oo0oO0ooo * ooO0Oooo00 * Oo0ooO0oo0oO
  if 36 - 36: O0 + OOo
def iIIIi1i1I11i ( name , url , description ) :
 DialogITVTerms . show ( )
 oO = xbmcgui . DialogProgress ( )
 oOo00 = xbmcgui . Dialog ( ) . yesno ( "[B]ITV Updater/Installer[/B]" , 'By pressing YES you will install ' , 'the latest version of our software.' , '' , yeslabel = 'YES' , nolabel = 'NO' )
 if oOo00 == 0 :
  return
 elif oOo00 == 1 :
  oOO0OO0OO = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]Would you like Adult XXX Content? (Must be 18+)[/COLOR]" , 'By pressing YES adult xxx content will be installed to' , 'your device.' , '' , yeslabel = 'YES' , nolabel = 'NO' )
  if oOO0OO0OO == 0 :
   if I1Ii == "17" :
    url = iI1
    if 87 - 87: o00 + iIii1I11I1II1 - OoooooooOO
   else :
    url = i1iII1IiiIiI1
    if 8 - 8: OoooooooOO / ooO0Oooo00 + i1IIi . i11iI
    if 73 - 73: i1IIi + i11iI . i11iIiiIii
   I1IiIIi ( )
   time . sleep ( 10 )
   xbmc . executebuiltin ( 'SendClick(11)' )
   Ii1I1IIii1II = xbmcgui . Dialog ( )
   Ii1I1IIii1II . ok ( "[B]ITV Updater/Installer[/B]" , "Click ok to start the process!" , '' , '' )
   oO = xbmcgui . DialogProgress ( )
   oO . create ( "[B]ITV Updater/Installer[/B]" , "Wiping Infinity TV device..." , '' , 'Please wait as it will take a few minutes' )
   time . sleep ( 1 )
   oO . update ( 10 , "" , 'Preparing files...' , 'Please wait' )
   time . sleep ( 3 )
   try :
    for OO , iIiIIi1 , I1IIII1i in os . walk ( iiIiI , topdown = True ) :
     iIiIIi1 [ : ] = [ i111I1 for i111I1 in iIiIIi1 if i111I1 not in oOOo0 ]
     I1IIII1i [ : ] = [ II11 for II11 in I1IIII1i if II11 not in iIiIi11 ]
     for name in I1IIII1i :
      try :
       os . remove ( os . path . join ( OO , name ) )
       oO . update ( 30 , "" , 'Removing files...' , 'Please wait' )
       os . rmdir ( os . path . join ( OO , name ) )
      except : pass
      if 5 - 5: o00 . o00ooo0 . I1iII1iiII . OoooooooOO
     for name in iIiIIi1 :
      try : os . rmdir ( os . path . join ( OO , name ) ) ; os . rmdir ( OO )
      except : pass
   except : pass
   oO . update ( 60 , "" , "Removing folders..." )
   i1II1 ( )
   i1II1 ( )
   i1II1 ( )
   oO . update ( 75 , "" , "Removing folders..." )
   i1II1 ( )
   i1II1 ( )
   i1II1 ( )
   i1II1 ( )
   if 96 - 96: i11iIiiIii - Oo0oO0ooo % O0 / o0OO0
   if 100 - 100: i11iI / Ooo0 - OoooooooOO % I1iII1iiII - I1Ii111 % Oo0ooO0oo0oO
   oO . update ( 99 , "" , "Almost done..." )
   time . sleep ( 3 )
   ooOooo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
   oO = xbmcgui . DialogProgress ( )
   oO . create ( "ITV Updater/Installer" , "Wipe complete!" , 'Now Downloading...' , 'Please wait' )
   if 60 - 60: iIii1I11I1II1 + i1IIi
   oO0OO0 = os . path . join ( ooOooo0 , 'fullbackup.zip' )
   try :
    os . remove ( oO0OO0 )
   except :
    pass
   downloader . download ( url , oO0OO0 , oO )
   o0O0Oo00 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
   time . sleep ( 2 )
   oO . update ( 0 , "" , "Installing..." )
   extract . all ( oO0OO0 , o0O0Oo00 , oO )
   oO . update ( 0 , "" , "Finishing up..." )
   time . sleep ( 3 )
   xbmc . executebuiltin ( 'UpdateLocalAddons' )
   xbmc . executebuiltin ( "UpdateAddonRepos" )
   time . sleep ( 2 )
   Ii1I1IIii1II = xbmcgui . Dialog ( )
   Ii1I1IIii1II . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next pop-up window after you click OK below, will ask you if you want to \"Keep Skin?\". Always click YES to this." , "" , "Please note: If you take to long, it will automatically​ press YES for you as a fail safe." )
   try :
    os . remove ( oO0OO0 )
   except :
    pass
   if I1Ii == "17" :
    ii1iIi1II ( 'lookandfeel.skin' , 'skin.infinitytv-XK' )
   else :
    ii1iIi1II ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
   Ii1I1IIii1II = xbmcgui . Dialog ( )
   time . sleep ( 10 )
   xbmc . executebuiltin ( 'SendClick(11)' )
   Ii1I1IIii1II . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Installation is complete. [CR]Please press OK and wait while your Infinity TV app shuts down to apply the changes" )
   try :
    os . remove ( i1Iii1i1I )
   except :
    pass
    if 86 - 86: iIii1I11I1II1 + Oo0ooO0oo0oO . i11iIiiIii - Ooo0
   os . _exit ( 1 )
   if 51 - 51: Oo0ooO0oo0oO
   if 14 - 14: Oo0o0ooO0oOOO % o00 % OOo - i11iIiiIii
  elif oOO0OO0OO == 1 :
   if I1Ii == "17" :
    url = OoOooOOOO
    if 53 - 53: Ooo0 % OOo
   else :
    url = iIiiiI1IiI1I1
    if 59 - 59: Oo0oO0ooo % iIii1I11I1II1 . i1IIi + I1iII1iiII * Oo0o0ooO0oOOO
    if 41 - 41: Ooo0 % o00ooo0
   I1IiIIi ( )
   time . sleep ( 10 )
   xbmc . executebuiltin ( 'SendClick(11)' )
   Ii1I1IIii1II = xbmcgui . Dialog ( )
   Ii1I1IIii1II . ok ( "[B]ITV Updater/Installer[/B]" , "Click ok to start the process!" , '' , '' )
   oO = xbmcgui . DialogProgress ( )
   oO . create ( "[B]ITV Updater/Installer[/B]" , "Wiping Infinity TV device..." , '' , 'Please wait as it will take a few minutes' )
   time . sleep ( 1 )
   oO . update ( 10 , "" , 'Preparing files...' , 'Please wait' )
   time . sleep ( 3 )
   try :
    for OO , iIiIIi1 , I1IIII1i in os . walk ( iiIiI , topdown = True ) :
     iIiIIi1 [ : ] = [ i111I1 for i111I1 in iIiIIi1 if i111I1 not in oOOo0 ]
     I1IIII1i [ : ] = [ II11 for II11 in I1IIII1i if II11 not in iIiIi11 ]
     for name in I1IIII1i :
      try :
       os . remove ( os . path . join ( OO , name ) )
       oO . update ( 30 , "" , 'Removing files...' , 'Please wait' )
       os . rmdir ( os . path . join ( OO , name ) )
      except : pass
      if 12 - 12: Oo0oO0ooo
     for name in iIiIIi1 :
      try : os . rmdir ( os . path . join ( OO , name ) ) ; os . rmdir ( OO )
      except : pass
   except : pass
   oO . update ( 60 , "" , "Removing folders..." )
   i1II1 ( )
   i1II1 ( )
   i1II1 ( )
   oO . update ( 75 , "" , "Removing folders..." )
   i1II1 ( )
   i1II1 ( )
   i1II1 ( )
   i1II1 ( )
   if 69 - 69: OoooooooOO + Oo0oO0ooo
   if 26 - 26: OOo + Oo0oO0ooo / o0OO0 % Oo0ooO0oo0oO % o00ooo0 + I1iII1iiII
   oO . update ( 99 , "" , "Almost done..." )
   time . sleep ( 3 )
   ooOooo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
   oO = xbmcgui . DialogProgress ( )
   oO . create ( "ITV Updater/Installer" , "Wipe complete!" , 'Now Downloading...' , 'Please wait' )
   if 31 - 31: ooO0Oooo00 % Oo0oO0ooo * ooO0Oooo00
   oO0OO0 = os . path . join ( ooOooo0 , 'fullbackup.zip' )
   try :
    os . remove ( oO0OO0 )
   except :
    pass
   downloader . download ( url , oO0OO0 , oO )
   o0O0Oo00 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
   time . sleep ( 2 )
   oO . update ( 0 , "" , "Installing..." )
   extract . all ( oO0OO0 , o0O0Oo00 , oO )
   oO . update ( 0 , "" , "Finishing up..." )
   time . sleep ( 3 )
   xbmc . executebuiltin ( 'UpdateLocalAddons' )
   xbmc . executebuiltin ( "UpdateAddonRepos" )
   time . sleep ( 2 )
   Ii1I1IIii1II = xbmcgui . Dialog ( )
   Ii1I1IIii1II . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next pop-up window after you click OK below, will ask you if you want to \"Keep Skin?\". Always click YES to this." , "" , "Please note: If you take to long, it will automatically​ press YES for you as a fail safe." )
   try :
    os . remove ( oO0OO0 )
   except :
    pass
   if I1Ii == "17" :
    ii1iIi1II ( 'lookandfeel.skin' , 'skin.infinitytv-XK' )
   else :
    ii1iIi1II ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
   time . sleep ( 10 )
   xbmc . executebuiltin ( 'SendClick(11)' )
   Ii1I1IIii1II = xbmcgui . Dialog ( )
   Ii1I1IIii1II . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Installation is complete. [CR]Please press OK and wait while your Infinity TV app shuts down to apply the changes" )
   try :
    os . remove ( i1Iii1i1I )
   except :
    pass
    if 45 - 45: i1IIi . I1Ii111 + Oo0oO0ooo - OoooooooOO % OOoOoo00oo
   os . _exit ( 1 )
   if 1 - 1: iIii1I11I1II1
   if 93 - 93: i1IIi . i11iIiiIii . OOo
def O0O00OOo ( ) :
 OoOOo = [ ]
 iii1 = xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.GetFavourites", "params": {"type": null, "properties": ["path", "thumbnail", "window", "windowparameter"]}, "id": 1}' )
 iii1 = unicode ( iii1 , 'utf-8' , errors = 'ignore' )
 iii1 = simplejson . loads ( iii1 )
 if iii1 [ "result" ] [ "limits" ] [ "total" ] > 0 :
  for oOO0oo in iii1 [ "result" ] [ "favourites" ] :
   ooOooo0 = II1iIi1IiIii ( oOO0oo )
   I111I11I111 = { 'Label' : oOO0oo [ "title" ] ,
 'Thumb' : oOO0oo [ "thumbnail" ] ,
 'Type' : oOO0oo [ "type" ] ,
 'Builtin' : ooOooo0 ,
 'Path' : "plugin://script.extendedinfo/?info=action&&id=" + ooOooo0 }
   OoOOo . append ( I111I11I111 )
 print "ITEMS ################################################"
 print OoOOo
 return OoOOo
 if 46 - 46: i11iIiiIii - O0 . o00
def II1iIi1IiIii ( fav ) :
 if fav [ "type" ] == "media" :
  ooOooo0 = "PlayMedia(%s)" % ( fav [ "path" ] )
 elif fav [ "type" ] == "script" :
  ooOooo0 = "RunScript(%s)" % ( fav [ "path" ] )
 else :
  ooOooo0 = "ActivateWindow(%s,%s)" % (
 fav [ "window" ] , fav [ "windowparameter" ] )
 return ooOooo0
 if 100 - 100: I1Ii111 / I1i1iI1i * i11iI . O0 / Oo0oO0ooo
def oOO0o000Oo00o ( favtype ) :
 iii11II1I = O0O00OOo ( )
 iI111I11i = [ ]
 for oOO0oo in iii11II1I :
  if oOO0oo [ "Type" ] == favtype :
   iI111I11i . append ( oOO0oo )
 return iI111I11i
 if 23 - 23: Ooo0 . I1i1iI1i + OOo - Oo0oO0ooo
def II1iiIiIiI ( ) :
 from t0mm0 . common . net import Net
 import socket
 import time
 if 24 - 24: OOo - i1IIi + ooO0Oooo00
 IiiIi = Net ( )
 if 10 - 10: o0OO0 / OOo
 ooOooo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
 oO0OO0 = os . path . join ( ooOooo0 , 'fullbackup.zip' )
 import zipfile
 if 15 - 15: i11iI . Oo0ooO0oo0oO / i11iI * ooO0Oooo00 - I1Ii111 % o00ooo0
 oo0OOOOOO0 = zipfile . ZipFile ( oO0OO0 , "r" )
 for i11 in oo0OOOOOO0 . namelist ( ) :
  if 'favourites.xml' in i11 :
   Ii1I1I11I = oo0OOOOOO0 . read ( i11 )
   Ii1 = '<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
   if 34 - 34: i11iI - OoooooooOO . I1Ii111 / I1iII1iiII
   oo000 = re . compile ( Ii1 ) . findall ( Ii1I1I11I )
   print oo000
   for oOOoo00O00o , II1II , oo0O in oo000 :
    if 95 - 95: OoooooooOO . O0 . I1i1iI1i * OOo . Ooo0
    II1II = II1II . replace ( 'thumb://None' , '/mnt/internal_sd/Android/data/org.xbmc.xbmc/files/.xbmc/addons/script.1channel.themepak/art/themes/Glossy_Black/favourites.png' )
    oo0O = oo0O . replace ( '&quot;' , '' ) . replace ( '&amp;' , '&' )
    json . loads ( xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % ( oOOoo00O00o , oo0O , II1II ) ) )
    for iI1iIi1i , OO0Oo in enumerate ( fileinput . input ( O000OOo00oo , inplace = 1 ) ) :
     sys . stdout . write ( OO0Oo . replace ( 'RunScript(&quot;' , '' ) . replace ( '&quot;)' , '' ) )
  if 45 - 45: OoooooooOO % o00 - o00ooo0 - o00 - I1Ii111 / I1i1iI1i
  if 81 - 81: I1iII1iiII + i11iIiiIii / i11iI
  if 85 - 85: i11iIiiIii + I1 * Oo0ooO0oo0oO
  if 1 - 1: i1IIi / OOo . o0OO0
  if 57 - 57: ooO0Oooo00 . OOo + I1iII1iiII
  if 43 - 43: I1 % i11iI
  if 69 - 69: i11iI % o0OO0
  if 86 - 86: o00 / o00
  if 28 - 28: i11iIiiIii / I1i1iI1i . iIii1I11I1II1 / I1iII1iiII
  if 72 - 72: OoooooooOO / I1Ii111 + Ooo0 / Oo0ooO0oo0oO * Ooo0
  if 34 - 34: O0 * O0 % OoooooooOO + i11iI * iIii1I11I1II1 % Ooo0
  if 25 - 25: ooO0Oooo00 + Oo0ooO0oo0oO . I1i1iI1i % Oo0ooO0oo0oO * Oo0oO0ooo
  if 32 - 32: i11iIiiIii - I1
def oo00ooOoo ( ) :
 from t0mm0 . common . net import Net
 import socket
 import time
 if 28 - 28: Ooo0
 if ( os . path . isfile ( oo0OOo ) ) :
  IiiIi = Net ( )
  iIIIiiiI11I = ''
  II11 = open ( O000OOo00oo , mode = 'w' )
  II11 . write ( iIIIiiiI11I )
  II11 . close ( )
  if 6 - 6: Ooo0 % i1IIi . Ooo0 * Ooo0
  Ii1I1I11I = open ( oo0OOo ) . read ( )
  Ii1 = '<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
  oo000 = re . compile ( Ii1 ) . findall ( Ii1I1I11I )
  for o0Oo , oo0ooO0 , IIiiiiIiIIii in oo000 :
   json . loads ( xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % ( o0Oo , IIiiiiIiIIii , oo0ooO0 ) ) )
   for iI1iIi1i , OO0Oo in enumerate ( fileinput . input ( O000OOo00oo , inplace = 1 ) ) :
    sys . stdout . write ( OO0Oo . replace ( 'RunScript(&quot;' , '' ) . replace ( '&quot;)' , '' ) . replace ( '&amp;' , '&' ) )
    if 86 - 86: ooO0Oooo00 / I1i1iI1i - I1i1iI1i + o00ooo0 + o00
  ooOooo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , iIiiiI ) )
  IIi = os . path . join ( ooOooo0 , 'favourites.xml' )
  downloader . download ( Oo , IIi )
  time . sleep ( 2 )
  i11 = IIi
  if 84 - 84: Oo0o0ooO0oOOO
  Ii1 = '<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
  if 21 - 21: o00ooo0 . Oo0oO0ooo * I1i1iI1i
  oOo0oO = re . compile ( Ii1 ) . findall ( Ii1I1I11I )
  for oOOoo00O00o , II1II , oo0O in oOo0oO :
   Ii1I1I11I = open ( O000OOo00oo ) . read ( )
   if oOOoo00O00o in Ii1I1I11I : break
   if 89 - 89: i11iI
   if 7 - 7: o0OO0 * ooO0Oooo00 + I1iII1iiII % i11iIiiIii
   if 8 - 8: OOoOoo00oo * O0
   II1II = II1II . replace ( 'thumb://None' , '/mnt/internal_sd/Android/data/org.xbmc.xbmc/files/.xbmc/addons/script.1channel.themepak/art/themes/Glossy_Black/favourites.png' )
   oo0O = oo0O . replace ( '&quot;' , '' )
   if 73 - 73: I1i1iI1i / o00 / ooO0Oooo00 / o0OO0
   json . loads ( xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % ( oOOoo00O00o , oo0O , II1II ) ) )
   for iI1iIi1i , OO0Oo in enumerate ( fileinput . input ( O000OOo00oo , inplace = 1 ) ) :
    sys . stdout . write ( OO0Oo . replace ( 'RunScript(&quot;' , '' ) . replace ( '&quot;)' , '' ) )
 else :
  pass
  if 11 - 11: Oo0ooO0oo0oO + Oo0o0ooO0oOOO - OoooooooOO / o0OO0
  if 34 - 34: OOoOoo00oo
def i1iI1 ( ) :
 if 44 - 44: o00ooo0 - Ooo0 / I1iII1iiII * o0OO0 * OOo
 import time
 if 73 - 73: I1i1iI1i - I1Ii111 * i1IIi / i11iIiiIii * Oo0oO0ooo % I1iII1iiII
 try :
  oO = xbmcgui . DialogProgress ( )
  oO . create ( "ITV Updater/Installer" , "Retrieving backup file... " , '' , 'Please wait' )
  oO0OO0 = xbmc . translatePath ( os . path . join ( o00oooO0Oo , 'backup.zip' ) )
  o0O0Oo00 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
  time . sleep ( 2 )
  oO . update ( 0 , "" , "Installing..." )
  extract . all ( oO0OO0 , o0O0Oo00 , oO )
  oO . update ( 0 , "" , "Finishing up..." )
  time . sleep ( 5 )
  Ii1I1IIii1II = xbmcgui . Dialog ( )
  Ii1I1IIii1II . ok ( "ITV Updater/Installer" , "[COLOR yellow]Installation nearly complete but one important step remains. [/COLOR]" )
  Ii1I1IIii1II = xbmcgui . Dialog ( )
  Ii1I1IIii1II . ok ( "ITV Updater/Installer" , "[COLOR red]URGENT: Please unplug or power off your device immediately and then reboot to finish setup. [/COLOR]" )
  if 56 - 56: OoooooooOO * OOo . OOo . o00ooo0
 except :
  Ii1I1IIii1II = xbmcgui . Dialog ( )
  Ii1I1IIii1II . ok ( 'ITV Updater/Installer' , 'You need to backup your build first.\nTo backup your box press backup on main menu.' , '' , '' )
  if 24 - 24: OOo . ooO0Oooo00 * Ooo0 % i11iI / Oo0oO0ooo
  if 58 - 58: I1Ii111 - o00ooo0 % O0 . I1Ii111 % o0OO0 % Oo0o0ooO0oOOO
  if 87 - 87: o00 - i11iIiiIii
def O0OOO0OOooo00 ( name , url , mode , iconimage , fanart , description ) :
 ooOoO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 O0ii1ii1ii = True
 iIIIIiiIii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iIIIIiiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 iIIIIiiIii . setProperty ( "Fanart_Image" , fanart )
 O0ii1ii1ii = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ooOoO , listitem = iIIIIiiIii , isFolder = False )
 return O0ii1ii1ii
 if 58 - 58: OOo
def I111iIi1 ( name , url , mode , iconimage , fanart , description ) :
 ooOoO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 O0ii1ii1ii = True
 iIIIIiiIii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iIIIIiiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 iIIIIiiIii . setProperty ( "Fanart_Image" , fanart )
 O0ii1ii1ii = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ooOoO , listitem = iIIIIiiIii , isFolder = True )
 return O0ii1ii1ii
 if 9 - 9: iIii1I11I1II1 % o00ooo0 . Oo0oO0ooo + OoooooooOO
 if 62 - 62: O0 / I1Ii111 % O0 * o0OO0 % I1Ii111
 if 33 - 33: I1Ii111 . o00 * o0OO0 * iIii1I11I1II1
def II11i111i1iIiiIiI ( ) :
 ii1iIIiii1 = [ ]
 ooOo0O0o0 = sys . argv [ 2 ]
 if len ( ooOo0O0o0 ) >= 2 :
  o0oo0O = sys . argv [ 2 ]
  I1iiIII = o0oo0O . replace ( '?' , '' )
  if ( o0oo0O [ len ( o0oo0O ) - 1 ] == '/' ) :
   o0oo0O = o0oo0O [ 0 : len ( o0oo0O ) - 2 ]
  iIi1I1 = I1iiIII . split ( '&' )
  ii1iIIiii1 = { }
  for iI1iIi1i in range ( len ( iIi1I1 ) ) :
   O0oOoo0OoO0O = { }
   O0oOoo0OoO0O = iIi1I1 [ iI1iIi1i ] . split ( '=' )
   if ( len ( O0oOoo0OoO0O ) ) == 2 :
    ii1iIIiii1 [ O0oOoo0OoO0O [ 0 ] ] = O0oOoo0OoO0O [ 1 ]
    if 63 - 63: OoooooooOO / OOoOoo00oo
 return ii1iIIiii1
 if 91 - 91: i1IIi - iIii1I11I1II1
 if 55 - 55: I1Ii111 * I1i1iI1i % OOoOoo00oo . iIii1I11I1II1 * I1
o0oo0O = II11i111i1iIiiIiI ( )
Ii1i1i1i1I1Ii = None
oOOoo00O00o = None
o0oo0000 = None
iiiI1 = None
OOOoO0O = None
o0 = None
if 42 - 42: I1 + I1 * I1iII1iiII
if 78 - 78: OoooooooOO
try :
 Ii1i1i1i1I1Ii = urllib . unquote_plus ( o0oo0O [ "url" ] )
except :
 pass
try :
 oOOoo00O00o = urllib . unquote_plus ( o0oo0O [ "name" ] )
except :
 pass
try :
 iiiI1 = urllib . unquote_plus ( o0oo0O [ "iconimage" ] )
except :
 pass
try :
 o0oo0000 = int ( o0oo0O [ "mode" ] )
except :
 pass
try :
 OOOoO0O = urllib . unquote_plus ( o0oo0O [ "fanart" ] )
except :
 pass
try :
 o0 = urllib . unquote_plus ( o0oo0O [ "description" ] )
except :
 pass
 if 77 - 77: o00ooo0 / i1IIi / OOo % Oo0oO0ooo
 if 48 - 48: ooO0Oooo00 - Oo0o0ooO0oOOO + iIii1I11I1II1 + OoooooooOO
print str ( i1Ii ) + ': ' + str ( IiI111111IIII )
print "Mode: " + str ( o0oo0000 )
print "URL: " + str ( Ii1i1i1i1I1Ii )
print "Name: " + str ( oOOoo00O00o )
print "IconImage: " + str ( iiiI1 )
if 4 - 4: I1iII1iiII . ooO0Oooo00 + Ooo0 * I1 . OOoOoo00oo
if 87 - 87: Oo0ooO0oo0oO / o0OO0 / i11iIiiIii
def II11iI111i1 ( content , viewType ) :
 if 74 - 74: o00 / o00ooo0 % I1i1iI1i
 if content :
  xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , content )
 if i1 . getSetting ( 'auto-view' ) == 'true' :
  xbmc . executebuiltin ( "Container.SetViewMode(%s)" % i1 . getSetting ( viewType ) )
  if 88 - 88: Oo0ooO0oo0oO - i11iIiiIii % I1i1iI1i * ooO0Oooo00 + o00ooo0
  if 52 - 52: I1iII1iiII . I1Ii111 + Oo0ooO0oo0oO % o0OO0
if o0oo0000 == None or Ii1i1i1i1I1Ii == None or len ( Ii1i1i1i1I1Ii ) < 1 :
 ooo000o000 ( )
 if 62 - 62: I1i1iI1i
elif o0oo0000 == 1 :
 i11i1 ( oOOoo00O00o , Ii1i1i1i1I1Ii , o0 )
 if 15 - 15: ooO0Oooo00 + Ooo0 . Oo0oO0ooo * o0OO0 . Oo0ooO0oo0oO
elif o0oo0000 == 2 :
 OOO ( oOOoo00O00o , Ii1i1i1i1I1Ii , o0 )
 if 18 - 18: i1IIi % I1iII1iiII + I1 % Ooo0
elif o0oo0000 == 3 :
 oOo0 ( )
 if 72 - 72: iIii1I11I1II1
elif o0oo0000 == 4 :
 i1iI1 ( )
 if 45 - 45: OOo - I1i1iI1i % I1
elif o0oo0000 == 5 :
 o0O0o ( )
 if 38 - 38: I1 % Oo0oO0ooo - OoooooooOO
elif o0oo0000 == 6 :
 iIIIi1i1I11i ( oOOoo00O00o , Ii1i1i1i1I1Ii , o0 )
 if 87 - 87: o0OO0 % I1Ii111
elif o0oo0000 == 7 :
 I1I1iI ( )
 if 77 - 77: iIii1I11I1II1 - i1IIi . o00
elif o0oo0000 == 8 :
 Ii1I1IIii1II = xbmcgui . Dialog ( )
 Ii1I1IIii1II . ok ( "ITV Updater/Installer" , "[COLOR yellow]Important![/COLOR]" , "" , "Please POWER DOWN your Infinity TV, and then turn it back ON for the changes to take place." )
 try :
  os . remove ( lib )
 except :
  pass
 oo00ooOoo ( )
 if 26 - 26: I1i1iI1i * Oo0o0ooO0oOOO . i1IIi
 if 59 - 59: O0 + i1IIi - I1i1iI1i
 if 62 - 62: i11iIiiIii % Oo0oO0ooo . Oo0o0ooO0oOOO . Oo0oO0ooo
 if 84 - 84: i11iIiiIii * o0OO0
 if 18 - 18: Oo0oO0ooo - Ooo0 - Oo0ooO0oo0oO / I1 - O0
 try :
  os . remove ( oo0OOo )
 except :
  pass
  if 30 - 30: O0 + o00ooo0 + I1iII1iiII
elif o0oo0000 == 9 :
 Ii111 ( oOOoo00O00o , Ii1i1i1i1I1Ii , o0 )
 if 14 - 14: I1i1iI1i / Oo0oO0ooo - iIii1I11I1II1 - o00 % OOoOoo00oo
elif o0oo0000 == 10 :
 ooOO00oOOo000 ( oOOoo00O00o , Ii1i1i1i1I1Ii , o0 )
 if 49 - 49: OOoOoo00oo * o00 / I1i1iI1i / OOo * iIii1I11I1II1
elif o0oo0000 == 11 :
 oo0o0oooo ( oOOoo00O00o , Ii1i1i1i1I1Ii , o0 )
 if 57 - 57: Oo0ooO0oo0oO - o00 / OOoOoo00oo % i11iIiiIii
elif o0oo0000 == 12 :
 Oo0o0O ( oOOoo00O00o , Ii1i1i1i1I1Ii , o0 )
 if 3 - 3: i11iI . OOoOoo00oo % I1Ii111 + o00ooo0
elif o0oo0000 == 13 :
 I1ii ( oOOoo00O00o , Ii1i1i1i1I1Ii , o0 )
 if 64 - 64: i1IIi
elif o0oo0000 == 15 :
 oooOooooO0oOO ( oOOoo00O00o , Ii1i1i1i1I1Ii , o0 )
 if 29 - 29: I1i1iI1i / i11iIiiIii / I1Ii111 % o00 % i11iIiiIii
elif o0oo0000 == 16 :
 I11I1IIiiII1 ( oOOoo00O00o , Ii1i1i1i1I1Ii , o0 )
 if 18 - 18: Oo0oO0ooo + I1
elif o0oo0000 == 99 :
 O0O0Ooooo000 ( )
 if 80 - 80: o00 + I1i1iI1i * Ooo0 + o0OO0
 if 75 - 75: ooO0Oooo00 / I1i1iI1i / Oo0oO0ooo / Oo0o0ooO0oOOO % OOoOoo00oo + I1iII1iiII
 if 4 - 4: i11iI - OOo - Oo0o0ooO0oOOO - ooO0Oooo00 % i11iIiiIii / o0OO0
 if 50 - 50: OOoOoo00oo + i1IIi
 if 31 - 31: Ooo0
 if 78 - 78: i11iIiiIii + I1i1iI1i + I1 / I1i1iI1i % iIii1I11I1II1 % Oo0o0ooO0oOOO
 if 83 - 83: iIii1I11I1II1 % Oo0ooO0oo0oO % I1i1iI1i % I1 . o00ooo0 % O0
 if 47 - 47: I1i1iI1i
 if 66 - 66: I1Ii111 - Oo0o0ooO0oOOO
elif o0oo0000 == 98 :
 xbmc . executebuiltin ( "RunScript(script.speedtestnet)" )
 if 33 - 33: I1Ii111 / o0OO0
 if 12 - 12: I1iII1iiII
elif o0oo0000 == 97 :
 IiI11iII1 ( Ii1i1i1i1I1Ii )
 if 2 - 2: i1IIi - I1Ii111 + ooO0Oooo00 . I1iII1iiII
elif o0oo0000 == 96 :
 o00o0 ( )
 if 25 - 25: o00
elif o0oo0000 == 95 :
 Ii1I1IIii1II = xbmcgui . Dialog ( )
 Ii1I1IIii1II . ok ( "Update Add-ons" , "Press OK to make sure all your add-ons apps are up-to-date." , "" , "" )
 xbmc . executebuiltin ( 'UpdateLocalAddons' )
 xbmc . executebuiltin ( "UpdateAddonRepos" )
 if 34 - 34: Oo0ooO0oo0oO . iIii1I11I1II1 % O0
elif o0oo0000 == 90 :
 iI ( )
 if 43 - 43: o00ooo0 - i11iI
elif o0oo0000 == 80 :
 iI11I ( oOOoo00O00o , Ii1i1i1i1I1Ii , o0 )
 if 70 - 70: i11iI / Oo0oO0ooo % OOoOoo00oo - Ooo0
elif o0oo0000 == 81 :
 oO0oOOoo00000 ( oOOoo00O00o , Ii1i1i1i1I1Ii , o0 )
 if 47 - 47: i11iI
elif o0oo0000 == 82 :
 o00ooO00O ( oOOoo00O00o )
 if 92 - 92: Oo0oO0ooo + Oo0ooO0oo0oO % i1IIi
elif o0oo0000 == 83 :
 xbmc . executebuiltin ( "RunScript(script.cerebro.pairwith)" )
 if 23 - 23: I1 - Oo0oO0ooo + Ooo0 - Oo0ooO0oo0oO * Oo0ooO0oo0oO . OOo
 if 47 - 47: o00 % iIii1I11I1II1
 if 11 - 11: I1Ii111 % Ooo0 - o0OO0 - o00 + I1i1iI1i
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
if 98 - 98: i11iI + Ooo0 - o0OO0
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
