ooOOOoo = ''
def ttTTtt(i, t1, t2=[]):
 t = ooOOOoo
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0  
 for c in t2:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t

import xbmc , xbmcaddon , xbmcgui , xbmcplugin , os
import shutil
import urllib2 , urllib
import re
import extract
import downloader
import time
import sys , plugintools
import zipfile
import json
#import simplejson
import sys
import fileinput
import DialogITVTerms
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.itv_wizard_kodi'
Oo0Ooo = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
O0O0OO0O0O0 = xbmcaddon . Addon ( id = OO0o )
if 5 - 5: iiI / ii1I
if 61 - 61: iII111iiiii11 % I1IiiI
zip = O0O0OO0O0O0 . getSetting ( 'zip' )
IIi1IiiiI1Ii = xbmcgui . Dialog ( )
I11i11Ii = xbmcgui . DialogProgress ( )
oO00oOo = xbmc . translatePath ( os . path . join ( 'special://home/userdata' , '' ) )
OOOo0 = xbmc . translatePath ( os . path . join ( oO00oOo , 'addon_data' ) )
Oooo000o = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
IiIi11iIIi1Ii = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , 'packages' ) )
Oo0O = xbmc . translatePath ( os . path . join ( oO00oOo , 'guisettings.xml' ) )
IiI = xbmc . translatePath ( os . path . join ( oO00oOo , 'favourites.xml' ) )
ooOo = xbmc . translatePath ( os . path . join ( oO00oOo , 'favourites2.xml' ) )
Oo = xbmc . translatePath ( os . path . join ( oO00oOo , 'sources.xml' ) )
o0O = xbmc . translatePath ( os . path . join ( oO00oOo , 'advancedsettings.xml' ) )
IiiIII111iI = xbmc . translatePath ( os . path . join ( oO00oOo , 'RssFeeds.xml' ) )
IiII = xbmc . translatePath ( os . path . join ( oO00oOo , 'keymaps' , 'keyboard.xml' ) )
iI1Ii11111iIi = xbmc . translatePath ( os . path . join ( zip ) )
i1i1II = xbmc . getSkinDir ( )
O0oo0OO0 = xbmc . translatePath ( 'special://home/' )
I1i1iiI1 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OO0o ) )
iiIIIII1i1iI = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OO0o , 'resources' , 'skins' ) )
o0oO0 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OO0o , 'flag.xml' ) )
oo00 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , 'skin.infinitytv_demo' , 'addon.xml' ) )
o00 = xbmc . translatePath ( os . path . join ( 'special://home' , 'media' , 'launch.jpg' ) )
Oo0oO0ooo = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OO0o , 'disclaimer.xml' ) )
o0oOoO00o = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OO0o , 'addon.xml' ) )
i1 = "0.0.11"
oOOoo00O0O = "itv_wizard"
if 15 - 15: I11iii11IIi
if 93 - 93: O0 * O0o0o00o0Oo0 / i11iI / Oo0o0ooO0oOOO + I1 - O0OoOoo00o
if 31 - 31: i111IiI + iIIIiI11 . iII111ii
def i1iIIi1 ( setting , value ) :
 setting = '"%s"' % setting
 if 50 - 50: IiIi1Iii1I1 - O00O0O0O0
 if isinstance ( value , list ) :
  ooO0O = ''
  for oo in value :
   ooO0O += '"%s",' % str ( oo )
   if 28 - 28: i1iIIIiI1I - OOoO000O0OO
  ooO0O = ooO0O [ : - 1 ]
  ooO0O = '[%s]' % ooO0O
  value = ooO0O
  if 23 - 23: iIiIiIiIIi + i111IiI
 elif not isinstance ( value , int ) :
  value = '"%s"' % value
  if 14 - 14: O0o0o00o0Oo0 . O0 / IiIi1Iii1I1
 IiiiI1II1I1 = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % ( setting , value )
 xbmc . executeJSONRPC ( IiiiI1II1I1 )
 if 95 - 95: iII111iiiii11 . ii1I
def O00o ( setting ) :
 if 61 - 61: O00O0O0O0 . ii1I * O0 . iIiIiIiIIi % O0o0o00o0Oo0
 import json
 setting = '"%s"' % setting
 if 72 - 72: iIIIiI11
 IiiiI1II1I1 = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % ( setting )
 o0Oo00OOOOO = xbmc . executeJSONRPC ( IiiiI1II1I1 )
 if 85 - 85: iIiIiIiIIi . O00O0O0O0 - i11iI % iIiIiIiIIi % I11iii11IIi
 o0Oo00OOOOO = json . loads ( o0Oo00OOOOO )
 if 81 - 81: i11iI + I11iii11IIi % O00O0O0O0 * iiI
 if o0Oo00OOOOO . has_key ( 'result' ) :
  if o0Oo00OOOOO [ 'result' ] . has_key ( 'value' ) :
   return o0Oo00OOOOO [ 'result' ] [ 'value' ]
   if 89 - 89: i111IiI + O0o0o00o0Oo0
   if 3 - 3: I1IiiI / O0 % iII111ii * i11iIiiIii / iiI * iII111ii
III1ii1iII = OO0o ; oo0oooooO0 = "Total Wipe"
if 19 - 19: iII111ii + iIiIiIiIIi
ooo = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OO0o , 'first_start.xml' ) )
if 18 - 18: I1
if 28 - 28: iIIIiI11 - i1iIIIiI1I . i1iIIIiI1I + Oo0o0ooO0oOOO - iII111iiiii11 + iiI
def oOoOooOo0o0 ( ) :
 OOOO = 'lookandfeel.skin'
 i1i1II = O00o ( OOOO )
 IIi1IiiiI1Ii = xbmcgui . Dialog ( )
 IIi1IiiiI1Ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background." , "" , "" )
 i1iIIi1 ( 'lookandfeel.skin' , 'skin.infinitytv-X-demo' )
 if 87 - 87: i111IiI / iII111ii - I1IiiI * iIIIiI11 / iII111iiiii11 . iiI
 if 1 - 1: I11iii11IIi - iII111ii / iII111ii
if not ( os . path . isfile ( o0oOoO00o ) ) :
 I11i11Ii = xbmcgui . DialogProgress ( )
 I1II1III11iii = xbmcgui . Dialog ( ) . yesno ( "[COLOR white]Infinity TV[/COLOR]" , 'Please press YES to Setup your Infinity TV Box' , '' , '' , yeslabel = 'YES' , nolabel = 'NO' )
 if I1II1III11iii == 0 :
  xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
  if 75 - 75: ii1I / iIIIiI11 % I1 * Oo0o0ooO0oOOO
 elif I1II1III11iii == 1 :
  iiii11I = ttTTtt(603,[30,104],[149,116,246,116,98,112,187,58,179,47,9,47,144,105,156,110,121,102,137,105,188,110,177,105,47,116,189,121,35,116,21,118,24,46,89,99,92,97,146,47,104,100,120,111,77,119,162,110,192,108,113,111,94,97,41,100,165,115,215,95,246,107,219,111,114,100,89,105,16,47,216,100,163,101,179,102,17,97,8,117,164,108,160,116,48,95,132,98,51,117,221,105,94,108,188,100,190,118,7,46,163,122,185,105,35,112])
  oOoOooOo0o0 ( )
  time . sleep ( 5 )
  Ooo0OO0oOO = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , 'packages' ) )
  I11i11Ii = xbmcgui . DialogProgress ( )
  I11i11Ii . create ( "Infinity TV" , "Downloading..." , 'Please Wait' , '' )
  if 50 - 50: O0
  Ii1i11IIii1I = os . path . join ( Ooo0OO0oOO , 'fullbackup.zip' )
  try :
   os . remove ( Ii1i11IIii1I )
  except :
   pass
  downloader . download ( iiii11I , Ii1i11IIii1I , I11i11Ii )
  OOOoO0O0o = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
  time . sleep ( 2 )
  I11i11Ii . update ( 0 , "" , "Installing..." )
  extract . all ( Ii1i11IIii1I , OOOoO0O0o , I11i11Ii )
  I11i11Ii . update ( 0 , "" , "Finishing up..." )
  time . sleep ( 3 )
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  time . sleep ( 2 )
  time . sleep ( 2 )
  IIi1IiiiI1Ii = xbmcgui . Dialog ( )
  IIi1IiiiI1Ii . ok ( "[COLOR white]Infinity TV[/COLOR]" , "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background." , "" , "" )
  try :
   os . remove ( Ii1i11IIii1I )
  except :
   pass
  i1iIIi1 ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
  IIi1IiiiI1Ii = xbmcgui . Dialog ( )
  time . sleep ( 10 )
  if 55 - 55: iIIIiI11 + iIiIiIiIIi . I1IiiI - O0OoOoo00o . iiI - iIiIiIiIIi
  IIi1IiiiI1Ii . ok ( "[COLOR white]Infinity TV[/COLOR]" , "Installation is complete. " )
  xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
  if 92 - 92: O00O0O0O0 . iII111ii + I1
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
