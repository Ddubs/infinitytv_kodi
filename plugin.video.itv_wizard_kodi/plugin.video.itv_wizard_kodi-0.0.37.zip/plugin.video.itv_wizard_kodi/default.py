ooOOOoo = ''
def ttTTtt(i, t1, t2=[]):
 t = ooOOOoo
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0  
 for c in t2:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t

import xbmc , xbmcaddon , xbmcgui , xbmcplugin , os
import shutil
import urllib2 , urllib
import re
import extract
import downloader
import time
import sys , plugintools
import zipfile
import json
#import simplejson
import sys
import fileinput
import DialogITVTerms
import socket , base64
import kodi
import speedtest
import datetime
if 64 - 64: i11iIiiIii
OO0o = ttTTtt(0,[104,219,116,66,116,168,112,251,58],[190,47,95,47,135,105,119,110,93,102,83,105,57,110,101,105,83,116,74,121,164,116,20,118,97,46,174,99,48,97,252,47,225,100,173,111,1,119,205,110,117,108,18,111,231,97,34,100,174,115,136,95,151,107,231,111,116,100,151,105,88,47])
Oo0Ooo = ttTTtt(155,[10,104,226,116],[28,116,120,112,1,58,253,47,170,47,250,105,198,110,104,102,199,105,7,110,166,105,97,116,244,121,100,116,102,118,46,46,68,99,25,97,140,47,202,100,27,111,15,119,163,110,151,108,118,111,29,97,252,100,140,115,77,95,202,107,70,111,194,100,65,105,64,47,91,117,125,112,57,100,216,97,90,116,85,101,36,46,75,122,83,105,212,112])
O0O0OO0O0O0 = ttTTtt(0,[104,229,116,35,116,118,112,197,58,55,47,222,47],[68,105,48,110,194,102,51,105,87,110,198,105,229,116,190,121,8,116,19,118,22,46,61,99,113,97,188,47,59,100,47,111,222,119,131,110,147,108,183,111,146,97,248,100,189,115,23,95,109,107,159,111,68,100,116,105,80,47,165,102,52,117,57,108,47,108,47,95,0,114,107,101,115,115,196,116,3,111,218,114,142,101,131,46,71,122,35,105,14,112])
iiiii = ttTTtt(503,[226,104,159,116,235,116,86,112,113,58,248,47],[254,47,153,105,39,110,7,102,122,105,208,110,133,105,105,116,166,121,105,116,162,118,203,46,67,99,126,97,183,47,116,100,57,111,186,119,186,110,82,108,61,111,49,97,52,100,191,115,52,95,223,107,204,111,51,100,46,105,186,47,58,97,152,100,183,117,139,108,241,116,154,95,253,102,66,117,7,108,222,108,12,95,8,114,152,101,122,115,240,116,148,111,94,114,55,101,218,46,128,122,97,105,236,112])
ooo0OO = ttTTtt(0,[104,145,116,105,116,27,112,181,58],[16,47,152,47,234,105,8,110,88,102,113,105,1,110,9,105,40,116,22,121,91,116,81,118,110,46,154,99,96,97,137,47,155,100,84,111,55,119,30,110,116,108,225,111,123,97,60,100,162,115,33,95,113,107,120,111,242,100,66,105,157,47,27,97,191,100,54,117,71,108,182,116,1,95,55,102,59,117,5,108,32,108,131,95,47,114,145,101,60,115,2,116,59,111,46,114,132,101,255,95,59,102,228,97,104,118,84,46,134,122,135,105,248,112])
II1 = ttTTtt(423,[187,104,37,116,36,116,46,112,118,58],[148,47,180,47,166,105,105,110,211,102,154,105,57,110,22,105,154,116,29,121,188,116,245,118,105,46,69,99,236,97,227,47,91,100,116,111,181,119,141,110,99,108,161,111,247,97,5,100,36,115,149,95,78,107,136,111,132,100,237,105,66,47,254,102,45,117,123,108,218,108,149,95,190,114,124,101,45,115,245,116,50,111,0,114,35,101,82,95,118,102,29,97,30,118,186,46,2,122,147,105,25,112])
O00ooooo00 = ttTTtt(949,[107,104,121,116,46,116,116,112,50,58,140,47,24,47],[220,105,99,110,119,102,174,105,83,110,144,105,172,116,152,121,173,116,86,118,14,46,145,99,115,97,199,47,131,100,200,111,78,119,179,110,78,108,131,111,93,97,8,100,113,115,155,95,219,107,123,111,95,100,0,105,58,47,24,98,118,117,71,105,92,108,235,100,50,95,155,118,129,101,160,114,148,115,118,105,135,111,208,110,220,115,229,46,57,116,186,120,6,116])
I1IiiI = ttTTtt(0,[104,117,116,170,116,218,112,71,58,251,47,159,47],[18,105,62,110,32,102,13,105,197,110,11,105,42,116,14,121,174,116,243,118,201,46,29,99,69,97,48,47,184,100,137,111,53,119,147,110,50,108,30,111,15,97,50,100,137,115,213,95,34,107,82,111,48,100,190,105,64,47,236,102,75,97,247,118,76,111,78,117,165,114,129,105,59,116,233,101,27,115,205,46,19,120,183,109,136,108])
IIi1IiiiI1Ii = ttTTtt(0,[104],[185,116,23,116,114,112,121,58,31,47,100,47,245,105,192,110,200,102,99,105,133,110,168,105,110,116,138,121,217,116,131,118,97,46,143,99,12,97,250,47,180,100,1,111,170,119,52,110,246,108,38,111,52,97,121,100,58,115,230,95,194,107,95,111,237,100,26,105,55,47,134,109,229,101,18,100,99,105,46,97,175,46,142,122,222,105,228,112])
I11i11Ii = ttTTtt(352,[89,104],[191,116,232,116,146,112,8,58,186,47,12,47,83,105,29,110,237,102,212,105,202,110,41,105,187,116,67,121,119,116,113,118,221,46,140,99,16,97,135,47,218,100,25,111,161,119,114,110,133,108,101,111,165,97,76,100,161,115,124,95,15,107,142,111,64,100,123,105,40,47,38,115,165,107,91,105,201,110,251,46,244,105,159,110,53,102,190,105,83,110,77,105,148,116,157,121,221,116,112,118,102,95,40,100,172,101,237,109,191,111,154,46,78,122,127,105,23,112])
oO00oOo = ttTTtt(0,[104],[230,116,18,116,65,112,25,58,183,47,37,47,190,105,206,110,43,102,197,105,53,110,237,105,149,116,5,121,241,116,21,118,149,46,45,99,206,97,35,47,182,100,47,111,144,119,14,110,250,108,180,111,219,97,48,100,33,115,121,95,214,107,27,111,160,100,106,105,4,47,246,115,9,107,168,105,151,110,61,46,241,105,217,110,235,102,131,105,108,110,170,105,51,116,4,121,255,116,128,118,224,46,209,122,72,105,164,112])
OOOo0 = ttTTtt(35,[54,112,205,108,133,117,65,103],[94,105,38,110,174,46,229,118,123,105,54,100,227,101,227,111,158,46,66,105,165,116,14,118,238,95,130,119,28,105,84,122,29,97,110,114,243,100,5,95,100,107,160,111,219,100,237,105])
Oooo000o = ttTTtt(0,[104],[88,116,69,116,128,112,193,58,179,47,13,47,16,105,32,110,178,102,87,105,165,110,129,105,177,116,89,121,46,116,184,118,142,46,98,99,59,97,38,47,92,100,72,111,51,119,87,110,21,108,87,111,109,97,63,100,59,115,100,95,176,107,124,111,35,100,191,105,130,47,169,109,148,97,91,99,65,95,54,97,92,100,248,100,9,114,132,101,111,115,86,115,40,46,85,120,241,109,107,108])
if 6 - 6: i1 * ii1IiI1i % OOooOOo / I11i / o0O / IiiIII111iI
IiII = ttTTtt(0,[104,230,116,134,116,15,112,171,58,152,47,41,47,63,105,207,110,135,102,250,105,220,110,204,105,115,116,25,121,200,116,12,118],[32,46,64,99,58,97,125,47,3,100,219,111,161,119,83,110,249,108,189,111,141,97,40,100,62,115,98,95,115,107,226,111,148,100,208,105,136,47,122,100,83,101,29,102,62,97,70,117,142,108,9,116,74,46,126,98,52,117,224,105,92,108,204,100,239,46,81,122,132,105,123,112])
if 28 - 28: Ii11111i * iiI1i1
i1I1ii1II1iII = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
oooO0oo0oOOOO = xbmcaddon . Addon ( id = OOOo0 )
if 53 - 53: o0oo0o / Oo + OOo00O0Oo0oO / iIi * ooO00oOoo - O0OOo
II1Iiii1111i = 'http://infinitytv.ca/downloads_kodi/sportsdevil_fix.zip'
if 25 - 25: OOo000
if 82 - 82: o000o0o00o0Oo . ii11 % oO0o0o0ooO0oO / I1i1I - O0OOo % ooO00oOoo
if 37 - 37: ooO00oOoo
def i1iiIIiiI111 ( url ) :
 oooOOOOO = urllib2 . Request ( url )
 oooOOOOO . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 i1iiIII111ii = urllib2 . urlopen ( oooOOOOO )
 i1iIIi1 = i1iiIII111ii . read ( )
 i1iiIII111ii . close ( )
 return i1iIIi1
 if 50 - 50: i11iIiiIii - OOo000
 if 78 - 78: iiI1i1
 if 18 - 18: i1 - o000o0o00o0Oo / o000o0o00o0Oo + I1i1I % I1i1I - ii11
O0O00Ooo = kodi . addon_id
oooO0oo0oOOOO = xbmcaddon . Addon ( id = O0O00Ooo )
if 64 - 64: iIi - i1 / o0O / Oo / ii1IiI1i
IiIIIiI1I1 = "Speed Test"
OoO000 = "Infinity TV"
if 42 - 42: iIi - I11i / i11iIiiIii + ooO00oOoo + iiI1i1
iIiII = 0.0
iI = 0.0
if 22 - 22: Ii11111i % OOo000
if 84 - 84: i11iIiiIii . Oo
def o0O00oooo ( url , dest , dp = None ) :
 if not dp :
  dp = xbmcgui . DialogProgress ( )
  dp . create ( OoO000 , "Connecting to server" , '[COLOR orange][I]Testing your network speed...[/I][/COLOR]' , 'Please wait...' )
 dp . update ( 0 )
 O00o = time . time ( )
 try :
  urllib . urlretrieve ( url , dest , lambda O00 , i11I1 , Ii11Ii11I : iI11i1I1 ( O00 , i11I1 , Ii11Ii11I , dp , O00o ) )
 except :
  pass
 return ( time . time ( ) - O00o )
 if 71 - 71: I1i1I % o000o0o00o0Oo / Oo
def iI11i1I1 ( numblocks , blocksize , filesize , dp , start_time ) :
 global iIiII
 global iI
 if 49 - 49: o0O % o000o0o00o0Oo * i1
 try :
  oOOo0oo = min ( numblocks * blocksize * 100 / filesize , 100 )
  iI = float ( numblocks ) * blocksize
  o0oo0o0O00OO = iI / ( 1024 * 1024 )
  o0oO = iI / ( time . time ( ) - start_time )
  if o0oO > 0 :
   I1i1iii = ( filesize - numblocks * blocksize ) / o0oO
   if o0oO > iIiII : iIiII = o0oO
  else :
   I1i1iii = 0
  i1iiI11I = o0oO * 8 / 1024
  iiii = i1iiI11I / 1024
  oO0o0O0OOOoo0 = float ( filesize ) / ( 1024 * 1024 )
  IiIiiI = '%.02f MB of %.02f MB' % ( o0oo0o0O00OO , oO0o0O0OOOoo0 )
  dp . update ( oOOo0oo )
 except :
  iI = float ( filesize )
  oOOo0oo = 100
  dp . update ( oOOo0oo )
 if dp . iscanceled ( ) :
  dp . close ( )
  raise Exception ( "Cancelled" )
  if 31 - 31: OOo000 . OOo000 - Oo / iiI1i1 + I1i1I * IiiIII111iI
def O0ooOooooO ( mypath , dirname ) :
 import xbmcvfs
 if 60 - 60: O0OOo / O0OOo
 if 46 - 46: OOo000 * ooO00oOoo - iiI1i1 * iIi - oO0o0o0ooO0oO
 if not xbmcvfs . exists ( mypath ) :
  try :
   xbmcvfs . mkdirs ( mypath )
  except :
   xbmcvfs . mkdir ( mypath )
   if 83 - 83: OOooOOo
 Iii111II = os . path . join ( mypath , dirname )
 if 9 - 9: iiI1i1
 if not xbmcvfs . exists ( Iii111II ) :
  try :
   xbmcvfs . mkdirs ( Iii111II )
  except :
   xbmcvfs . mkdir ( Iii111II )
   if 33 - 33: I1i1I . o000o0o00o0Oo
 return Iii111II
 if 58 - 58: ooO00oOoo * i11iIiiIii / o0oo0o % oO0o0o0ooO0oO - OOo00O0Oo0oO / iIi
def ii11i1 ( ) :
 IIIii1II1II = datetime . datetime . now ( )
 i1I1iI = time . mktime ( IIIii1II1II . timetuple ( ) ) + ( IIIii1II1II . microsecond / 1000000. )
 oo0OooOOo0 = str ( '%f' % i1I1iI )
 oo0OooOOo0 = oo0OooOOo0 . replace ( '.' , '' )
 oo0OooOOo0 = oo0OooOOo0 [ : - 3 ]
 return oo0OooOOo0
 if 92 - 92: o000o0o00o0Oo . O0OOo + Oo
def IiII1I11i1I1I ( url ) :
 oO0Oo = xbmc . translatePath ( oooO0oo0oOOOO . getAddonInfo ( 'profile' ) )
 oOOoo0Oo = O0ooOooooO ( oO0Oo , 'speedtestfiles' )
 o00OO00OoO = os . path . join ( oOOoo0Oo , ii11i1 ( ) + '.speedtest' )
 OOOO0OOoO0O0 = o0O00oooo ( url , o00OO00OoO )
 os . remove ( o00OO00OoO )
 O0Oo000ooO00 = ( ( iI / OOOO0OOoO0O0 ) * 8 / ( 1024 * 1024 ) )
 oO0 = ( iIiII * 8 / ( 1024 * 1024 ) )
 if O0Oo000ooO00 < 2 :
  Ii1iIiII1ii1 = 'Very low quality streams might work.'
  ooOooo000oOO = 'Expect buffering, do not try HD.'
  Oo0oOOo = '[COLOR ghostwhite][B] Verdict: [I]Very Poor[/I]   | Score: [COLOR slategray][I]1/10[/I][/B][/COLOR]'
 elif O0Oo000ooO00 < 2.5 :
  Ii1iIiII1ii1 = 'You should be ok for SD content only.'
  ooOooo000oOO = 'SD/DVD quality should be ok.'
  Oo0oOOo = '[COLOR ghostwhite][B][I]Poor[/I]   | Score: [COLOR slategray][I]2/10[/I][/B][/COLOR]'
 elif O0Oo000ooO00 < 5 :
  Ii1iIiII1ii1 = 'Some HD streams might struggle, SD should be fine.'
  ooOooo000oOO = '720p will be fine but some 1080p may struggle.'
  Oo0oOOo = '[COLOR ghostwhite][B][I]OK[/I]   | Score: [COLOR slategray][I]4/10[/I][/B][/COLOR]'
 elif O0Oo000ooO00 < 9 :
  Ii1iIiII1ii1 = 'All streams including HD should stream fine.'
  ooOooo000oOO = 'Movies (720p & 1080p) will stream fine but 3D and 4K will not.'
  Oo0oOOo = '[COLOR ghostwhite][B][I]Good[/I]   | Score: [COLOR slategray][I]6/10[/I][/B][/COLOR]'
 elif O0Oo000ooO00 < 15 :
  Ii1iIiII1ii1 = 'All streams including HD should stream fine'
  ooOooo000oOO = 'Movies (720p & 1080p and 3D) will stream fine but 4K may not.'
  Oo0oOOo = '[COLOR ghostwhite][B][I]Very good[/I]   | Score: [COLOR slategray][I]8/10[/I][/B][/COLOR]'
 else :
  Ii1iIiII1ii1 = 'All streams including HD should stream fine'
  ooOooo000oOO = 'You can play all movies (720p, 1080p, 3D and 4K)'
  Oo0oOOo = '[COLOR ghostwhite][B][I]Excellent[/I]   | Score: [COLOR slategray][I]10/10[/I][/B][/COLOR]'
 print "Average Speed: " + str ( O0Oo000ooO00 )
 print "Max. Speed: " + str ( oO0 )
 Oo0OoO00oOO0o = xbmcgui . Dialog ( )
 OOO00O = Oo0OoO00oOO0o . ok (
 '[COLOR lightsteelblue][B]Your Result:[/COLOR][/B] ' + Oo0oOOo ,
 '[COLOR lightsteelblue][B]Live Streams:[/COLOR][/B] ' + Ii1iIiII1ii1 ,
 '[COLOR lightsteelblue][B]Movie Streams:[/COLOR][/B] ' + ooOooo000oOO ,
 '[COLOR lightsteelblue][B]Duration:[/COLOR][/B] %.02f secs ' % OOOO0OOoO0O0 + '[COLOR lightsteelblue][B]Average Speed:[/B][/COLOR] %.02f Mb/s ' % O0Oo000ooO00 + '[COLOR lightsteelblue][B]Max Speed:[/B][/COLOR] %.02f Mb/s ' % oO0 ,
 )
 if 84 - 84: iIi * iiI1i1 / O0OOo - i1
 if 30 - 30: ii1IiI1i / I1i1I - oO0o0o0ooO0oO - o0O % o000o0o00o0Oo
 if 49 - 49: IiiIII111iI % I1i1I . I1i1I . O0OOo * I1i1I
O0oOO0 = 'skin.infinitytv-X'
O0ooo0O0oo0 = xbmcaddon . Addon ( id = O0oOO0 )
zip = oooO0oo0oOOOO . getSetting ( 'zip' )
Oo0OoO00oOO0o = xbmcgui . Dialog ( )
oo0oOo = xbmcgui . DialogProgress ( )
o000O0o = xbmc . translatePath ( os . path . join ( 'special://home/userdata' , '' ) )
iI1iII1 = xbmc . translatePath ( os . path . join ( o000O0o , 'addon_data' ) )
oO0OOoo0OO = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
O0 = xbmc . translatePath ( os . path . join ( o000O0o , 'guisettings.xml' ) )
ii1ii1ii = xbmc . translatePath ( os . path . join ( o000O0o , 'favourites.xml' ) )
oooooOoo0ooo = xbmc . translatePath ( os . path . join ( o000O0o , 'favourites2.xml' ) )
I1I1IiI1 = xbmc . translatePath ( os . path . join ( o000O0o , 'sources.xml' ) )
III1iII1I1ii = xbmc . translatePath ( os . path . join ( o000O0o , 'advancedsettings.xml' ) )
oOOo0 = xbmc . translatePath ( os . path . join ( o000O0o , 'RssFeeds.xml' ) )
oo00O00oO = xbmc . translatePath ( os . path . join ( o000O0o , 'keymaps' , 'keyboard.xml' ) )
iIiIIIi = xbmc . translatePath ( os . path . join ( zip ) )
ooo00OOOooO = xbmc . getSkinDir ( )
O00OOOoOoo0O = xbmc . translatePath ( 'special://home/' )
O000OOo00oo = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OOOo0 ) )
oo0OOo = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OOOo0 , 'resources' , 'skins' ) )
ooOOO00Ooo = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OOOo0 , 'flag.xml' ) )
IiIIIi1iIi = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , 'skin.infinitytv_demo' , 'addon.xml' ) )
ooOOoooooo = xbmc . translatePath ( os . path . join ( 'special://home' , 'media' , 'launch.jpg' ) )
II1I = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OOOo0 , 'disclaimer.xml' ) )
O0i1II1Iiii1I11 = xbmc . translatePath ( os . path . join ( o000O0o , 'addon_data' , 'skin.infinitytv-X' , 'settings.xml' ) )
IIII = "0.0.11"
iiIiI = "itv_wizard"
o00oooO0Oo = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OOOo0 , 'icon.png' ) )
if 78 - 78: OOo000 % oO0o0o0ooO0oO + OOo00O0Oo0oO
if 64 - 64: iIi * i1 . IiiIII111iI + o0O
if 6 - 6: o0oo0o / o000o0o00o0Oo . ii11 . ii11
if 62 - 62: OOo00O0Oo0oO + ii11 % o000o0o00o0Oo + ooO00oOoo
if 33 - 33: i1 . ii11 . IiiIII111iI
if 72 - 72: I11i / iiI1i1 + OOooOOo - Ii11111i
def iI1Iii ( ) :
 kodi . log ( 'CLEAR CACHE ACTIVATED' )
 oO00OOoO00 = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
 IiI111111IIII = xbmcgui . Dialog ( ) . yesno ( "Clear Cache" , "Press OK if you wish to clear" , "your Infinity TV cache" , "" , "Cancel" , "OK" )
 if IiI111111IIII :
  if os . path . exists ( oO00OOoO00 ) == True :
   for i1Ii , ii111iI1iIi1 , OOO in os . walk ( oO00OOoO00 ) :
    oo0OOo0 = 0
    oo0OOo0 += len ( OOO )
    if oo0OOo0 > 0 :
     if 47 - 47: oO0o0o0ooO0oO + o0oo0o * Ii11111i / I1i1I - o000o0o00o0Oo % ii1IiI1i
     if 26 - 26: OOo00O0Oo0oO * o000o0o00o0Oo . o0O * OOo000
     for II1iiiIi1 in OOO :
      try :
       os . unlink ( os . path . join ( i1Ii , II1iiiIi1 ) )
      except :
       pass
     for i1I1ii11i1Iii in ii111iI1iIi1 :
      try :
       shutil . rmtree ( os . path . join ( i1Ii , i1I1ii11i1Iii ) )
      except :
       pass
       if 26 - 26: O0OOo - ii1IiI1i - IiiIII111iI / iiI1i1 . o0oo0o % ii1IiI1i
       if 91 - 91: Oo . ii1IiI1i / iIi + I11i
  Oo0OoO00oOO0o = xbmcgui . Dialog ( )
  Oo0OoO00oOO0o . ok ( '' , "Cache Cleared Successfully!" )
  xbmc . executebuiltin ( "Container.Refresh()" )
  if 42 - 42: I1i1I . Oo . I1i1I - OOo00O0Oo0oO
  if 40 - 40: I1i1I - i11iIiiIii / OOo000
  if 35 - 35: OOo000 - IiiIII111iI % Oo . OOooOOo % OOo000
  if 47 - 47: o000o0o00o0Oo - OOo000 . o0O + OOooOOo . i11iIiiIii
  if 94 - 94: Oo * OOo000 / Ii11111i / OOo000
  if 87 - 87: Ii11111i . ii11
def O0OO0O ( ) :
 OO = xbmc . translatePath ( os . path . join ( 'special://home/addons/packages' , '' ) )
 IiI111111IIII = xbmcgui . Dialog ( ) . yesno ( "Purge Packages" , "This will remove old zip files from your device that are no longer needed. " , "" , "Press OK to begin" , "Cancel" , "OK" )
 if IiI111111IIII :
  try :
   for i1Ii , ii111iI1iIi1 , OOO in os . walk ( OO , topdown = False ) :
    for OoOoO in OOO :
     os . remove ( os . path . join ( i1Ii , OoOoO ) )
    Oo0OoO00oOO0o = xbmcgui . Dialog ( )
    Oo0OoO00oOO0o . ok ( "Purge Packages" , "Old Zip Files Successfully Removed!" )
    xbmc . executebuiltin ( "Container.Refresh()" )
  except :
   Oo0OoO00oOO0o = xbmcgui . Dialog ( )
   Oo0OoO00oOO0o . ok ( OoO000 , "Error Deleting old zip files please visit Infinitytv.ca" )
   if 43 - 43: i11iIiiIii + Ii11111i * o0O * oO0o0o0ooO0oO * i1
   if 64 - 64: ooO00oOoo % ii1IiI1i * iIi
o0 = OOOo0 ; OoO000 = "Infinity TV: Network Speed Test"
iI11I1II = [ OOOo0 , 'skin.infinitytv-X-demo' ]
Ii1I = [ OOOo0 , 'addon_data' , 'skin.infinitytv-X-demo' ]
IiI1i = [ "favourites.xml" , "favourites2.xml" , "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "app.jpg" , "launch.jpg" , "Splash.png" ]
o0Oo00 = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "app.jpg" , "launch.jpg" , "Splash.png" ]
if 32 - 32: Oo . ii11 * O0OOo
def OOooo0oOO0O ( default = "" , heading = "" , hidden = False ) :
 o00O0 = xbmc . Keyboard ( default , heading , hidden )
 if 83 - 83: I1i1I
 o00O0 . doModal ( )
 if ( o00O0 . isConfirmed ( ) ) :
  return unicode ( o00O0 . getText ( ) , "utf-8" )
 return default
 if 65 - 65: IiiIII111iI % OOo000 * iIi
def I1iiiii ( sourcefile , destfile , message_header , message1 , message2 , message3 , exclude_dirs , exclude_files ) :
 o00oOOooOOo0o = zipfile . ZipFile ( destfile , 'w' , zipfile . ZIP_DEFLATED )
 O0O0ooOOO = len ( sourcefile )
 oOOo0O00o = [ ]
 iIiIi11 = [ ]
 oo0oOo . create ( message_header , message1 , message2 , message3 )
 for OO0o , ii111iI1iIi1 , OOO in os . walk ( sourcefile ) :
  for file in OOO :
   iIiIi11 . append ( file )
 OOOiiiiI = len ( iIiIi11 )
 for OO0o , ii111iI1iIi1 , OOO in os . walk ( sourcefile ) :
  ii111iI1iIi1 [ : ] = [ i1I1ii11i1Iii for i1I1ii11i1Iii in ii111iI1iIi1 if i1I1ii11i1Iii not in exclude_dirs ]
  OOO [ : ] = [ II1iiiIi1 for II1iiiIi1 in OOO if II1iiiIi1 not in exclude_files ]
  for file in OOO :
   oOOo0O00o . append ( file )
   oooOo0OOOoo0 = len ( oOOo0O00o ) / float ( OOOiiiiI ) * 100
   oo0oOo . update ( int ( oooOo0OOOoo0 ) , "Backing up..." , '[COLOR yellow]%s[/COLOR]' % file , 'Please wait' )
   OOoO = os . path . join ( OO0o , file )
   if not 'temp' in ii111iI1iIi1 :
    if not OOOo0 in ii111iI1iIi1 :
     import time
     OO0O000 = '01/01/1980'
     iiIiI1i1 = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( OOoO ) ) )
     if iiIiI1i1 > OO0O000 :
      o00oOOooOOo0o . write ( OOoO , OOoO [ O0O0ooOOO : ] )
 o00oOOooOOo0o . close ( )
 oo0oOo . close ( )
 if 69 - 69: I1i1I
def I11iII ( name , url , description ) :
 iIIII = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]VERY IMPORTANT: [/COLOR]" , 'This will completely wipe your infinity tv box settings.' , 'Would you like to create a backup before proceeding?' , '' , yeslabel = 'Yes' , nolabel = 'No' )
 if iIIII == 1 :
  I11 = urllib . quote_plus ( "backup" )
  iI1i1I11I11 = xbmc . translatePath ( os . path . join ( O000OOo00oo , I11 + '.zip' ) )
  o000O0O = [ OOOo0 , 'Thumbnails' ]
  o0Oo00 = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Textures13.db' ]
  I1i1i1iii = "Creating backup... "
  I1111i = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
  iIIii = ""
  o00O0O = "Please wait"
  I1iiiii ( O00OOOoOoo0O , iI1i1I11I11 , I1i1i1iii , I1111i , iIIii , o00O0O , o000O0O , o0Oo00 )
 if 20 - 20: I11i - I1i1I
 if 30 - 30: O0OOo / IiiIII111iI
 if 35 - 35: o0O % ooO00oOoo . I1i1I + I1i1I % o0O % o0O
 if 72 - 72: o0O + I11i + Oo
 if 94 - 94: iIi . I11i - Oo % i1 - iiI1i1
 if 72 - 72: OOo000
 II11Ii1iI1iII = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]FINAL WARNING!!! [/COLOR]" , 'Are you absolutely certain about wiping your infinity tv box settings?' , '' , 'All addons and userdata will be gone!' , yeslabel = 'Yes' , nolabel = 'No' )
 if II11Ii1iI1iII == 0 :
  return
 elif II11Ii1iI1iII == 1 :
  oO0o0O0OOOoo0 = 0
  oo0oOo . create ( "[B]ITV Updater/Installer[/B]" , "Wiping infinity tv Device..." , '' , 'Please wait' )
  try :
   for i1Ii , ii111iI1iIi1 , OOO in os . walk ( O00OOOoOoo0O , topdown = True ) :
    ii111iI1iIi1 [ : ] = [ i1I1ii11i1Iii for i1I1ii11i1Iii in ii111iI1iIi1 if i1I1ii11i1Iii not in iI11I1II ]
    for name in OOO :
     oOOo0oo = min ( 100 * oO0o0O0OOOoo0 / name , 100 )
     try :
      os . remove ( os . path . join ( i1Ii , name ) )
      os . rmdir ( os . path . join ( i1Ii , name ) )
      oo0oOo . update ( oOOo0oo )
     except : pass
     if 73 - 73: OOooOOo * OOooOOo * I1i1I * o0oo0o + I1i1I * oO0o0o0ooO0oO
    for name in ii111iI1iIi1 :
     oo0oOo . update ( oOOo0oo )
     try : os . rmdir ( os . path . join ( i1Ii , name ) ) ; os . rmdir ( i1Ii )
     except : pass
  except : pass
 oo0o0OO0 ( )
 oo0o0OO0 ( )
 oo0o0OO0 ( )
 oo0o0OO0 ( )
 oo0o0OO0 ( )
 oo0o0OO0 ( )
 oo0o0OO0 ( )
 Oo0OoO00oOO0o . ok ( '[B]ITV Updater/Installer[/B]' , 'Wipe complete! Please restart infinity tv box for changes to take effect.' , '' , '' )
 return oooO ( name , url , description )
 if 26 - 26: OOo000 % OOo00O0Oo0oO
def oo0o0OO0 ( ) :
 print "########### Start Removing Empty Folders #########"
 o00Oo0oooooo = 0
 O0oO0 = 0
 for iII11 , iiIiii1IIIII , OOO in os . walk ( O00OOOoOoo0O ) :
  if len ( iiIiii1IIIII ) == 0 and len ( OOO ) == 0 :
   o00Oo0oooooo += 1
   os . rmdir ( iII11 )
   print "successfully removed: " + iII11
  elif len ( iiIiii1IIIII ) > 0 and len ( OOO ) > 0 :
   O0oO0 += 1
   if 67 - 67: OOo000 / ii11
def iiIiIIIiiI ( ) :
 iIIII = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]ITV Updater/Installer: [/COLOR]" , 'Would you like to create a backup?.' , 'Backup file will be stored in the plugin.video.itv_wizard folder.' , '' , yeslabel = 'Yes' , nolabel = 'No' )
 if iIIII == 1 :
  I11 = urllib . quote_plus ( "backup" )
  iI1i1I11I11 = xbmc . translatePath ( os . path . join ( O000OOo00oo , I11 + '.zip' ) )
  o000O0O = [ OOOo0 , 'Thumbnails' ]
  o0Oo00 = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Textures13.db' ]
  I1i1i1iii = "Creating backup... "
  I1111i = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
  iIIii = ""
  o00O0O = "Please wait"
  I1iiiii ( O00OOOoOoo0O , iI1i1I11I11 , I1i1i1iii , I1111i , iIIii , o00O0O , o000O0O , o0Oo00 )
  Oo0OoO00oOO0o . ok ( '[B]ITV Updater/Installer[/B]' , 'Backup complete!' , '' , '' )
 else :
  return
  if 12 - 12: i1 - Oo
def oOoO00O0 ( ) :
 DialogITVTerms . show ( )
 if 75 - 75: IiiIII111iI . I1i1I . i1 * oO0o0o0ooO0oO
 if 4 - 4: OOo000 % iIi * iiI1i1
 if 100 - 100: oO0o0o0ooO0oO * ooO00oOoo + ooO00oOoo
 if 54 - 54: OOooOOo + Oo - I11i % i11iIiiIii
 if 3 - 3: Oo % Oo
 if 83 - 83: o0O + oO0o0o0ooO0oO
 if 73 - 73: o000o0o00o0Oo
 if 42 - 42: i11iIiiIii * ii1IiI1i / OOo00O0Oo0oO . i11iIiiIii % O0OOo
 if 41 - 41: ii11 / i1
 if 51 - 51: O0OOo % IiiIII111iI
 if 60 - 60: IiiIII111iI / ooO00oOoo . IiiIII111iI / oO0o0o0ooO0oO . ii11
 if 92 - 92: o0oo0o + oO0o0o0ooO0oO * OOo000 % IiiIII111iI
 if 42 - 42: Ii11111i
 if 76 - 76: IiiIII111iI * o000o0o00o0Oo % oO0o0o0ooO0oO
 if 57 - 57: ii1IiI1i - I11i / oO0o0o0ooO0oO - i1 * OOooOOo % o0O
 if 68 - 68: OOooOOo * O0OOo % o0oo0o - ii11
 if 34 - 34: oO0o0o0ooO0oO . ii1IiI1i * o0oo0o * iIi / oO0o0o0ooO0oO / OOo00O0Oo0oO
 if 78 - 78: Ii11111i - Oo / o0oo0o
 if 10 - 10: o000o0o00o0Oo + Ii11111i * OOo00O0Oo0oO + ii1IiI1i / oO0o0o0ooO0oO / OOo00O0Oo0oO
iI1II = xbmc . translatePath ( os . path . join ( oo0OOo , 'wipe.png' ) )
o0OOo0o0O0O = xbmc . translatePath ( os . path . join ( oo0OOo , 'support.png' ) )
o0OO0o0oOOO0O = xbmc . translatePath ( os . path . join ( oo0OOo , 'fanart.jpg' ) )
iII1i11 = xbmc . translatePath ( os . path . join ( oo0OOo , 'restore.png' ) )
Ooo = xbmc . translatePath ( os . path . join ( oo0OOo , 'backup.png' ) )
IiIIII1i11I = xbmc . translatePath ( os . path . join ( oo0OOo , 'full_restore.png' ) )
OOOiII1 = xbmc . translatePath ( os . path . join ( oo0OOo , 'adult_full_restore.png' ) )
OOo = xbmc . translatePath ( os . path . join ( oo0OOo , 'updates.png' ) )
IIii11Ii1i1I = xbmc . translatePath ( os . path . join ( oo0OOo , 'restore_backup.png' ) )
Oooo0O = xbmc . translatePath ( os . path . join ( oo0OOo , 'stepone.png' ) )
oo00O0oO0O0 = xbmc . translatePath ( os . path . join ( oo0OOo , 'steptwo.png' ) )
ooo0OO0O0Oo = xbmc . translatePath ( os . path . join ( oo0OOo , 'stepthree.png' ) )
Ooo0O0oooo = xbmc . translatePath ( os . path . join ( oo0OOo , 'fixes.png' ) )
iiI = xbmc . translatePath ( os . path . join ( oo0OOo , 'default_restore.png' ) )
oO = xbmc . translatePath ( os . path . join ( oo0OOo , 'maintool.png' ) )
IIiIi = xbmc . translatePath ( os . path . join ( oo0OOo , 'network.png' ) )
OOoOooOoOOOoo = xbmc . translatePath ( os . path . join ( oo0OOo , 'clear_cache.png' ) )
Iiii1iI1i = xbmc . translatePath ( os . path . join ( oo0OOo , 'update_addons.png' ) )
I1ii1ii11i1I = xbmc . translatePath ( os . path . join ( oo0OOo , 'term.png' ) )
o0OoOO = xbmc . translatePath ( os . path . join ( oo0OOo , 'purge.png' ) )
if 55 - 55: I1i1I - O0OOo + o0O + o000o0o00o0Oo % OOo000
def iiI11i1II ( ) :
 if 51 - 51: Oo % Ii11111i % Oo * i1 - ooO00oOoo % Ii11111i
 if 65 - 65: I1i1I
 if 68 - 68: I1i1I % i11iIiiIii + o0O
 if 52 - 52: OOo00O0Oo0oO - Ii11111i + OOo00O0Oo0oO % Oo
 if 35 - 35: ii1IiI1i
 if 42 - 42: oO0o0o0ooO0oO . IiiIII111iI . I11i + o0oo0o + ooO00oOoo + IiiIII111iI
 if 31 - 31: o000o0o00o0Oo . ooO00oOoo - I1i1I . OOooOOo / OOooOOo
 if 56 - 56: iiI1i1 / iIi / i11iIiiIii + OOooOOo - Ii11111i - O0OOo
 if 21 - 21: i1 % ii11 . IiiIII111iI / o0O + ii11
 if 53 - 53: iIi - IiiIII111iI - iIi * o000o0o00o0Oo
 if 71 - 71: i1 - ii1IiI1i
 if 12 - 12: ooO00oOoo / Oo
 if 42 - 42: Ii11111i
 if 19 - 19: iIi % OOo00O0Oo0oO * ii1IiI1i + IiiIII111iI
 if 46 - 46: Ii11111i
 if 1 - 1: o000o0o00o0Oo
 if 97 - 97: ooO00oOoo + o000o0o00o0Oo + i1 + i11iIiiIii
 if 77 - 77: Oo / OOooOOo
 if 46 - 46: Oo % ii1IiI1i . o000o0o00o0Oo % o000o0o00o0Oo + i11iIiiIii
 if 72 - 72: ii1IiI1i * OOo000 % I1i1I / iiI1i1
 if 35 - 35: I1i1I + I11i % OOo00O0Oo0oO % O0OOo + iIi
 if 17 - 17: I11i
 if 21 - 21: Ii11111i
 if 29 - 29: O0OOo / o0O / I1i1I * ooO00oOoo
 if 10 - 10: oO0o0o0ooO0oO % ii11 * ii11 . O0OOo / OOo000 % ooO00oOoo
 if 49 - 49: iiI1i1 / iIi + i1 * Oo
 if 28 - 28: I1i1I + i11iIiiIii / O0OOo % o0oo0o % Ii11111i - i1
 if 54 - 54: I11i + o0O
 if 83 - 83: OOo00O0Oo0oO - IiiIII111iI + ooO00oOoo
 if 5 - 5: OOo000
 if 46 - 46: ii11
 if 45 - 45: I1i1I
 if 21 - 21: iIi . oO0o0o0ooO0oO . ooO00oOoo / Ii11111i / oO0o0o0ooO0oO
 if 17 - 17: ooO00oOoo / ooO00oOoo / O0OOo
 if 1 - 1: I11i . i11iIiiIii % ooO00oOoo
 i1iIIi1 = i1iiIIiiI111 ( O00ooooo00 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 OooO0oo = re . compile ( 'update="(.+?)".+?ull_restore="(.+?)".+?dult_full_restore="(.+?)".+?upport_full_restore="(.+?)".+?upport_update="(.+?)"' ) . findall ( i1iIIi1 )
 for o0o0oOoOO0O , i1ii1II1ii , iII111Ii , Ooo00OoOOO , Oo0OO0000oooo in OooO0oo :
  IIII1iII = o0o0oOoOO0O
  ii1III11 = i1ii1II1ii
  I1iiIIIi11 = iII111Ii
  if 12 - 12: OOooOOo % Oo * O0OOo % ii1IiI1i / OOo000
  Ii1ii1IiIII ( 'Update & Install Software ' + '[COLOR white] ' + ii1III11 + '[/COLOR]' , O0O0OO0O0O0 , 6 , IiIIII1i11I , o0OO0o0oOOO0O , '' )
  Ii1ii1IiIII ( 'Fixes - ' + '[COLOR white] ' + IIII1iII + '[/COLOR]' , iiiii , 15 , Ooo0O0oooo , o0OO0o0oOOO0O , 'All fixes will be shown here!' )
  Ii1ii1IiIII ( 'Factory Restore' , IiII , 16 , iiI , o0OO0o0oOOO0O , 'All addons and userdata will be completely wiped!' )
  if 57 - 57: ii1IiI1i / O0OOo - I11i
  Ii1ii1IiIII ( 'Terms & Conditions' , Oo0Ooo , 3 , I1ii1ii11i1I , o0OO0o0oOOO0O , 'Terms & Conditions info from your TV box seller. ' )
  ooOOo00O00Oo ( 'movies' , 'MAIN' )
  if 42 - 42: i1 / Oo + OOooOOo * I1i1I % I1i1I
  if 7 - 7: o000o0o00o0Oo / OOo00O0Oo0oO / i11iIiiIii
  if 21 - 21: iIi / OOo00O0Oo0oO + OOo000 + OOooOOo
  if 91 - 91: i11iIiiIii / I11i + o000o0o00o0Oo + I1i1I * i11iIiiIii
def OoOoOo00o0 ( ) :
 OO0ooo0oOO ( 'Network Speed Test' , IiII , 98 , IIiIi , o0OO0o0oOOO0O , 'Test your network speed on your Infinity TV' )
 Ii1ii1IiIII ( 'Clear Cache' , IiII , 96 , OOoOooOoOOOoo , o0OO0o0oOOO0O , '' )
 Ii1ii1IiIII ( 'Update Add-ons' , IiII , 95 , Iiii1iI1i , o0OO0o0oOOO0O , '' )
 Ii1ii1IiIII ( 'Purge Packages (use once or twice a month)' , IiII , 90 , o0OoOO , o0OO0o0oOOO0O , '' )
 if 97 - 97: IiiIII111iI / o000o0o00o0Oo
 if 71 - 71: o0O / I11i . OOo00O0Oo0oO % OOooOOo . o0oo0o
def speedtest ( ) :
 if 41 - 41: I11i * o0O / OOooOOo . ooO00oOoo
 if 83 - 83: o000o0o00o0Oo . i1 / Ii11111i / ooO00oOoo - o0O
 oO0oO0 = base64 . b64decode ( "aHR0cDovL2luZGlnby50dmFkZG9ucy5hZy9zcGVlZHRlc3Qvc3BlZWR0ZXN0ZmlsZS50eHQ=" )
 i1iIIi1 = i1iiIIiiI111 ( oO0oO0 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 OooO0oo = re . compile ( 'name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?ersion="(.+?)"' ) . findall ( i1iIIi1 )
 for OoOoO , i1i1IIIIi1i , Ii11iiI , IIi1iiii1iI , iIiiii in OooO0oo :
  Ii1ii1IiIII ( '[COLOR ghostwhite]' + OoOoO + " | " + iIiiii + '[/COLOR]' , i1i1IIIIi1i , 97 , o00oooO0Oo , o0OO0o0oOOO0O , '' )
  if 89 - 89: o000o0o00o0Oo - I1i1I % Ii11111i % Oo
  if 49 - 49: Ii11111i - IiiIII111iI / ii11 / i1 % Oo * OOo000
def OOoO0 ( name , url , description ) :
 if 22 - 22: Ii11111i % o000o0o00o0Oo * OOo00O0Oo0oO / ooO00oOoo % i11iIiiIii * O0OOo
 if 95 - 95: OOooOOo - ii11 * IiiIII111iI + o0oo0o
 url = II1Iiii1111i
 name = 'skin.infinitytv'
 iIi1 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
 oo0oOo = xbmcgui . DialogProgress ( )
 oo0oOo . create ( "ITV Updater/Installer" , "Applying update... " , '' , 'Please wait' )
 i11iiI1111 = os . path . join ( iIi1 , name + '.zip' )
 try :
  os . remove ( i11iiI1111 )
 except :
  pass
 downloader . download ( url , i11iiI1111 , oo0oOo )
 oOoooo000Oo00 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
 time . sleep ( 2 )
 oo0oOo . update ( 0 , "" , "Installing..." )
 extract . all ( i11iiI1111 , oOoooo000Oo00 , oo0oOo )
 oo0oOo . update ( 0 , "" , "Finishing up..." )
 time . sleep ( 5 )
 Oo0OoO00oOO0o = xbmcgui . Dialog ( )
 Oo0OoO00oOO0o . ok ( "ITV Updater/Installer" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish update. [/COLOR]" )
 if 93 - 93: OOo00O0Oo0oO / IiiIII111iI / ii1IiI1i % oO0o0o0ooO0oO % oO0o0o0ooO0oO
def IiI11iI1i1i1i ( name , url , description ) :
 url = oO00oOo
 name = 'skin.infinitytv'
 iIi1 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
 oo0oOo = xbmcgui . DialogProgress ( )
 oo0oOo . create ( "ITV Updater/Installer" , "Fixing skin issues... " , '' , 'Please wait' )
 i11iiI1111 = os . path . join ( iIi1 , name + '.zip' )
 try :
  os . remove ( i11iiI1111 )
 except :
  pass
 downloader . download ( url , i11iiI1111 , oo0oOo )
 oOoooo000Oo00 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
 time . sleep ( 2 )
 oo0oOo . update ( 0 , "" , "Installing..." )
 extract . all ( i11iiI1111 , oOoooo000Oo00 , oo0oOo )
 oo0oOo . update ( 0 , "" , "Finishing up..." )
 time . sleep ( 5 )
 Oo0OoO00oOO0o = xbmcgui . Dialog ( )
 Oo0OoO00oOO0o . ok ( "ITV Updater/Installer" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish update. [/COLOR]" )
 if 89 - 89: O0OOo
def Ooooooo ( name , url , description ) :
 Oo0OoO00oOO0o = xbmcgui . Dialog ( )
 Oo0OoO00oOO0o . ok ( "ITV Updater/Installer" , "[COLOR blue]Please press YES on the next popup. [/COLOR]" , "" , "Then move to STEP TWO!" )
 I1IIIiI1I1ii1 ( 'lookandfeel.skin' , 'skin.infinitytv_demo' )
 if 30 - 30: i1 * OOooOOo
def I1iIIIi1 ( name , url , description ) :
 Ii1ii1IiIII ( 'STEP ONE' , oO00oOo , 12 , Oooo0O , o0OO0o0oOOO0O , 'All addons and userdata will be completely wiped!' )
 Ii1ii1IiIII ( 'STEP TWO' , oO00oOo , 13 , oo00O0oO0O0 , o0OO0o0oOOO0O , 'All addons and userdata will be completely wiped!' )
 ooOOo00O00Oo ( 'movies' , 'MAIN' )
 if 17 - 17: ii1IiI1i . OOooOOo / O0OOo % o0O % I11i / i11iIiiIii
 if 58 - 58: Ii11111i . o0O + iIi - i11iIiiIii / o0O / i1
def oOOoOo ( name , url , description ) :
 ooOooo0 = 'lookandfeel.skin'
 ooo00OOOooO = oO0OO0 ( ooOooo0 )
 if 82 - 82: ii11 - ii11 + o0oo0o
 if ( os . path . isfile ( ooOOO00Ooo ) ) :
  Oo0OoO00oOO0o = xbmcgui . Dialog ( )
  Oo0OoO00oOO0o . ok ( "ITV Updater/Installer" , "[COLOR blue]Please press Ok and then Click on Step 1, and follow the next prompts![/COLOR]" )
  if 8 - 8: Oo % o000o0o00o0Oo * iIi % OOo000 . I1i1I / I1i1I
 Ii1ii1IiIII ( 'STEP ONE' , O0O0OO0O0O0 , 7 , Oooo0O , o0OO0o0oOOO0O , 'All addons and userdata will be completely wiped!' )
 Ii1ii1IiIII ( 'STEP TWO' , O0O0OO0O0O0 , 6 , oo00O0oO0O0 , o0OO0o0oOOO0O , 'All addons and userdata will be completely wiped!' )
 Ii1ii1IiIII ( 'STEP THREE' , O0O0OO0O0O0 , 8 , ooo0OO0O0Oo , o0OO0o0oOOO0O , 'All addons and userdata will be completely wiped!' )
 ooOOo00O00Oo ( 'movies' , 'MAIN' )
 if 81 - 81: iiI1i1
def oO0o00oOOooO0 ( name , url , description ) :
 if ( os . path . isfile ( ooOOO00Ooo ) ) :
  Oo0OoO00oOO0o = xbmcgui . Dialog ( )
  Oo0OoO00oOO0o . ok ( "ITV Updater/Installer" , "[COLOR blue]Please press Ok and then Click on Step 1, and follow the next prompts![/COLOR]" )
  if 79 - 79: iiI1i1 - ii1IiI1i + OOo000 - oO0o0o0ooO0oO
 Ii1ii1IiIII ( 'STEP ONE' , iiiii , 7 , Oooo0O , o0OO0o0oOOO0O , 'All addons and userdata will be completely wiped!' )
 Ii1ii1IiIII ( 'STEP TWO' , iiiii , 6 , oo00O0oO0O0 , o0OO0o0oOOO0O , 'All addons and userdata will be completely wiped!' )
 Ii1ii1IiIII ( 'STEP THREE' , iiiii , 8 , ooo0OO0O0Oo , o0OO0o0oOOO0O , 'All addons and userdata will be completely wiped!' )
 ooOOo00O00Oo ( 'movies' , 'MAIN' )
 if 93 - 93: o0O . IiiIII111iI - Ii11111i + o0oo0o
def ooO0o ( ) :
 try :
  os . remove ( ooOOO00Ooo )
 except :
  pass
 ooOooo0 = 'lookandfeel.skin'
 ooo00OOOooO = oO0OO0 ( ooOooo0 )
 Oo0OoO00oOO0o = xbmcgui . Dialog ( )
 Oo0OoO00oOO0o . ok ( "ITV Updater/Installer" , "[COLOR blue]The next popup window will ask \"Would you like to keep this change?\" Click YES and then proceed to Step Two [/COLOR]" , "" , "" )
 I1IIIiI1I1ii1 ( 'lookandfeel.skin' , 'skin.infinitytv_demo' )
 if 89 - 89: O0OOo / oO0o0o0ooO0oO
def oooO0o0o0O0 ( ) :
 ooOooo0 = 'lookandfeel.skin'
 ooo00OOOooO = oO0OO0 ( ooOooo0 )
 Oo0OoO00oOO0o = xbmcgui . Dialog ( )
 Oo0OoO00oOO0o . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background." , "" , "" )
 I1IIIiI1I1ii1 ( 'lookandfeel.skin' , 'skin.infinitytv-X-demo' )
 if 27 - 27: OOooOOo - o000o0o00o0Oo / O0OOo
def OOooOo00oo0 ( ) :
 xbmc . executebuiltin ( 'ReloadSkin()' )
 if 84 - 84: oO0o0o0ooO0oO + O0OOo
def IIiiIIi1 ( ) :
 xbmc . executebuiltin ( 'UnloadSkin()' )
 if 59 - 59: ii11 . ooO00oOoo % o0O
 if 39 - 39: OOo00O0Oo0oO
def I1IIIiI1I1ii1 ( setting , value ) :
 setting = '"%s"' % setting
 if 97 - 97: ooO00oOoo - iiI1i1 / OOo000 . i11iIiiIii % iIi * iIi
 if isinstance ( value , list ) :
  ii1IIIIiI11 = ''
  for iI1IIIii in value :
   ii1IIIIiI11 += '"%s",' % str ( iI1IIIii )
   if 7 - 7: ii11 - O0OOo / o0O * OOo000 . o000o0o00o0Oo * o000o0o00o0Oo
  ii1IIIIiI11 = ii1IIIIiI11 [ : - 1 ]
  ii1IIIIiI11 = '[%s]' % ii1IIIIiI11
  value = ii1IIIIiI11
  if 61 - 61: O0OOo % I1i1I - iiI1i1 / Ii11111i
 elif not isinstance ( value , int ) :
  value = '"%s"' % value
  if 4 - 4: OOooOOo - I11i % OOo000 - ooO00oOoo * Oo
 Ooooo00o0OoO = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % ( setting , value )
 xbmc . executeJSONRPC ( Ooooo00o0OoO )
 if 75 - 75: IiiIII111iI % o0O
def oO0OO0 ( setting ) :
 if 30 - 30: ii11 + oO0o0o0ooO0oO - ii11 . ii11 - o0O + i1
 import json
 setting = '"%s"' % setting
 if 86 - 86: I11i
 Ooooo00o0OoO = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % ( setting )
 i1iiIII111ii = xbmc . executeJSONRPC ( Ooooo00o0OoO )
 if 41 - 41: o0oo0o * O0OOo / o0oo0o % iIi
 i1iiIII111ii = json . loads ( i1iiIII111ii )
 if 18 - 18: o0O . OOooOOo % o0oo0o % OOo000
 if i1iiIII111ii . has_key ( 'result' ) :
  if i1iiIII111ii [ 'result' ] . has_key ( 'value' ) :
   return i1iiIII111ii [ 'result' ] [ 'value' ]
   if 9 - 9: iiI1i1 - Ii11111i * OOooOOo . Ii11111i
   if 2 - 2: OOooOOo % ooO00oOoo
def oooO ( name , url , description ) :
 if 63 - 63: IiiIII111iI % ii1IiI1i
 iIi1 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
 oo0oOo = xbmcgui . DialogProgress ( )
 oo0oOo . create ( "ITV Updater/Installer" , "Downloading... " , '' , 'Please wait' )
 i11iiI1111 = os . path . join ( iIi1 , name + '.zip' )
 try :
  os . remove ( i11iiI1111 )
 except :
  pass
 downloader . download ( url , i11iiI1111 , oo0oOo )
 oOoooo000Oo00 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
 if 39 - 39: o000o0o00o0Oo / o0O / OOo00O0Oo0oO % IiiIII111iI
 time . sleep ( 2 )
 oo0oOo . update ( 0 , "" , "Installing..." )
 extract . all ( i11iiI1111 , oOoooo000Oo00 , oo0oOo )
 oo0oOo . update ( 0 , "" , "Finishing up..." )
 time . sleep ( 5 )
 if 89 - 89: oO0o0o0ooO0oO + OOooOOo + oO0o0o0ooO0oO * I11i + ii1IiI1i % O0OOo
 if 59 - 59: ooO00oOoo + i11iIiiIii
 if 88 - 88: i11iIiiIii - I1i1I
 if 67 - 67: ooO00oOoo . Ii11111i + o0oo0o - OOooOOo
 Oo0OoO00oOO0o = xbmcgui . Dialog ( )
 Oo0OoO00oOO0o . ok ( "ITV Updater/Installer" , "[COLOR blue]Installation nearly complete but one important step remains. [/COLOR]" )
 Oo0OoO00oOO0o = xbmcgui . Dialog ( )
 Oo0OoO00oOO0o . ok ( "ITV Updater/Installer" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish setup. [/COLOR]" )
 if 70 - 70: ooO00oOoo / o0O - ii1IiI1i - o000o0o00o0Oo
def Iii ( ) :
 try :
  os . remove ( ooOOO00Ooo )
 except :
  pass
  if 20 - 20: Oo / I11i
def oOIi111 ( name , url , description ) :
 oo0oOo = xbmcgui . DialogProgress ( )
 oO0i1iI = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]WARNING!!! [/COLOR]" , 'By pressing YES you will restore ' , 'your Infinity TV to the Factory Software build.' , '' , yeslabel = 'YES' , nolabel = 'NO' )
 if oO0i1iI == 0 :
  return
 elif oO0i1iI == 1 :
  oooO0o0o0O0 ( )
  time . sleep ( 10 )
  xbmc . executebuiltin ( 'SendClick(11)' )
  Oo0OoO00oOO0o = xbmcgui . Dialog ( )
  Oo0OoO00oOO0o . ok ( "[B]ITV Updater/Installer[/B]" , "Click ok to start the process!" , '' , '' )
  oo0oOo = xbmcgui . DialogProgress ( )
  oo0oOo . create ( "[B]ITV Updater/Installer[/B]" , "Wiping Infinity TV device..." , '' , 'Please wait as it will take a few minutes' )
  time . sleep ( 1 )
  oo0oOo . update ( 10 , "" , 'Preparing files...' , 'Please wait' )
  time . sleep ( 3 )
  try :
   for i1Ii , ii111iI1iIi1 , OOO in os . walk ( O00OOOoOoo0O , topdown = True ) :
    ii111iI1iIi1 [ : ] = [ i1I1ii11i1Iii for i1I1ii11i1Iii in ii111iI1iIi1 if i1I1ii11i1Iii not in iI11I1II ]
    OOO [ : ] = [ II1iiiIi1 for II1iiiIi1 in OOO if II1iiiIi1 not in o0Oo00 ]
    for name in OOO :
     try :
      os . remove ( os . path . join ( i1Ii , name ) )
      oo0oOo . update ( 30 , "" , 'Removing files...' , 'Please wait' )
      os . rmdir ( os . path . join ( i1Ii , name ) )
     except : pass
     if 10 - 10: o0O . o000o0o00o0Oo
    for name in ii111iI1iIi1 :
     try : os . rmdir ( os . path . join ( i1Ii , name ) ) ; os . rmdir ( i1Ii )
     except : pass
  except : pass
  oo0oOo . update ( 60 , "" , "Removing folders..." )
  oo0o0OO0 ( )
  oo0o0OO0 ( )
  oo0o0OO0 ( )
  oo0oOo . update ( 75 , "" , "Removing folders..." )
  oo0o0OO0 ( )
  oo0o0OO0 ( )
  oo0o0OO0 ( )
  oo0o0OO0 ( )
  if 32 - 32: OOo000 . ii11 . OOooOOo - iiI1i1 + iIi
  if 88 - 88: o000o0o00o0Oo
  oo0oOo . update ( 99 , "" , "Almost done..." )
  time . sleep ( 3 )
  iIi1 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
  oo0oOo = xbmcgui . DialogProgress ( )
  oo0oOo . create ( "ITV Updater/Installer" , "Wipe complete!" , 'Now Downloading...' , 'Please wait' )
  if 19 - 19: o0O * ii11 + OOo000
  i11iiI1111 = os . path . join ( iIi1 , 'fullbackup.zip' )
  try :
   os . remove ( i11iiI1111 )
  except :
   pass
  downloader . download ( url , i11iiI1111 , oo0oOo )
  oOoooo000Oo00 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
  time . sleep ( 2 )
  oo0oOo . update ( 0 , "" , "Installing..." )
  extract . all ( i11iiI1111 , oOoooo000Oo00 , oo0oOo )
  oo0oOo . update ( 0 , "" , "Finishing up..." )
  time . sleep ( 3 )
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  time . sleep ( 2 )
  Oo0OoO00oOO0o = xbmcgui . Dialog ( )
  Oo0OoO00oOO0o . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background." , "" , "" )
  try :
   os . remove ( i11iiI1111 )
  except :
   pass
  I1IIIiI1I1ii1 ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
  Oo0OoO00oOO0o = xbmcgui . Dialog ( )
  time . sleep ( 10 )
  xbmc . executebuiltin ( 'SendClick(11)' )
  if 65 - 65: ooO00oOoo . oO0o0o0ooO0oO . iiI1i1 . o000o0o00o0Oo - ooO00oOoo
  try :
   os . remove ( II1I )
  except :
   pass
  Oo0OoO00oOO0o . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Installation is complete. " )
  xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
  if 19 - 19: i11iIiiIii + o000o0o00o0Oo % I1i1I
  if 14 - 14: iiI1i1 . o0O . O0OOo / OOo000 % OOo00O0Oo0oO - I1i1I
  if 67 - 67: O0OOo - ooO00oOoo . I11i
def I1I1iI ( name , url , description ) :
 DialogITVTerms . show ( )
 oo0oOo = xbmcgui . DialogProgress ( )
 oO0i1iI = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]WARNING!!! [/COLOR]" , 'By pressing YES you will restore ' , 'your Infinity TV to the latest complete build.' , '' , yeslabel = 'YES' , nolabel = 'NO' )
 if oO0i1iI == 0 :
  return
 elif oO0i1iI == 1 :
  I1iIi1iiIIiI = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]Would you like Adult XXX Content? (Must be 18+)[/COLOR]" , 'By pressing YES adult xxx content will be installed to' , 'your device.' , '' , yeslabel = 'YES' , nolabel = 'NO' )
  if I1iIi1iiIIiI == 0 :
   url = O0O0OO0O0O0
   oOoOOoOOooOO = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]Would you like to Save your Favorites? [/COLOR]" , '-By pressing YES all your Favorites will be saved. ' , '-If you press NO your Favorites will be wiped' , '-Both options will restore your Infinity TV to the Latest Software Build.' , yeslabel = 'YES' , nolabel = 'NO' )
   if 31 - 31: ooO00oOoo / Ii11111i * I11i . o0oo0o
   if oOoOOoOOooOO == 0 :
    oooO0o0o0O0 ( )
    time . sleep ( 10 )
    xbmc . executebuiltin ( 'SendClick(11)' )
    Oo0OoO00oOO0o = xbmcgui . Dialog ( )
    Oo0OoO00oOO0o . ok ( "[B]ITV Updater/Installer[/B]" , "Click ok to start the process!" , '' , '' )
    oo0oOo = xbmcgui . DialogProgress ( )
    oo0oOo . create ( "[B]ITV Updater/Installer[/B]" , "Wiping Infinity TV device..." , '' , 'Please wait as it will take a few minutes' )
    time . sleep ( 1 )
    oo0oOo . update ( 10 , "" , 'Preparing files...' , 'Please wait' )
    time . sleep ( 3 )
    try :
     for i1Ii , ii111iI1iIi1 , OOO in os . walk ( O00OOOoOoo0O , topdown = True ) :
      ii111iI1iIi1 [ : ] = [ i1I1ii11i1Iii for i1I1ii11i1Iii in ii111iI1iIi1 if i1I1ii11i1Iii not in iI11I1II ]
      OOO [ : ] = [ II1iiiIi1 for II1iiiIi1 in OOO if II1iiiIi1 not in o0Oo00 ]
      for name in OOO :
       try :
        os . remove ( os . path . join ( i1Ii , name ) )
        oo0oOo . update ( 30 , "" , 'Removing files...' , 'Please wait' )
        os . rmdir ( os . path . join ( i1Ii , name ) )
       except : pass
       if 57 - 57: ooO00oOoo + ii1IiI1i % I11i % IiiIII111iI
      for name in ii111iI1iIi1 :
       try : os . rmdir ( os . path . join ( i1Ii , name ) ) ; os . rmdir ( i1Ii )
       except : pass
    except : pass
    oo0oOo . update ( 60 , "" , "Removing folders..." )
    oo0o0OO0 ( )
    oo0o0OO0 ( )
    oo0o0OO0 ( )
    oo0oOo . update ( 75 , "" , "Removing folders..." )
    oo0o0OO0 ( )
    oo0o0OO0 ( )
    oo0o0OO0 ( )
    oo0o0OO0 ( )
    if 83 - 83: Oo / i11iIiiIii % ii1IiI1i . O0OOo % iIi . OOooOOo
    if 94 - 94: OOo000 + ii1IiI1i % iiI1i1
    oo0oOo . update ( 99 , "" , "Almost done..." )
    time . sleep ( 3 )
    iIi1 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
    oo0oOo = xbmcgui . DialogProgress ( )
    oo0oOo . create ( "ITV Updater/Installer" , "Wipe complete!" , 'Now Downloading...' , 'Please wait' )
    if 93 - 93: OOo000 - ooO00oOoo + ii1IiI1i * Oo + oO0o0o0ooO0oO . o000o0o00o0Oo
    i11iiI1111 = os . path . join ( iIi1 , 'fullbackup.zip' )
    try :
     os . remove ( i11iiI1111 )
    except :
     pass
    downloader . download ( url , i11iiI1111 , oo0oOo )
    oOoooo000Oo00 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
    time . sleep ( 2 )
    oo0oOo . update ( 0 , "" , "Installing..." )
    extract . all ( i11iiI1111 , oOoooo000Oo00 , oo0oOo )
    oo0oOo . update ( 0 , "" , "Finishing up..." )
    time . sleep ( 3 )
    xbmc . executebuiltin ( 'UpdateLocalAddons' )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    time . sleep ( 2 )
    Oo0OoO00oOO0o = xbmcgui . Dialog ( )
    Oo0OoO00oOO0o . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background." , "" , "" )
    try :
     os . remove ( i11iiI1111 )
    except :
     pass
    I1IIIiI1I1ii1 ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
    Oo0OoO00oOO0o = xbmcgui . Dialog ( )
    time . sleep ( 10 )
    xbmc . executebuiltin ( 'SendClick(11)' )
    Oo0OoO00oOO0o . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Installation is complete. " )
    try :
     os . remove ( II1I )
    except :
     pass
    xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
    if 49 - 49: OOooOOo * O0OOo - Ii11111i . iIi
    if 89 - 89: I1i1I + OOo000 * I1i1I / I1i1I
    if 46 - 46: iiI1i1
   elif oOoOOoOOooOO == 1 :
    if 71 - 71: O0OOo / O0OOo * iIi * iIi / o0O
    if 35 - 35: ooO00oOoo * Oo * IiiIII111iI % Ii11111i . o0oo0o
    if 58 - 58: O0OOo + o0O * o000o0o00o0Oo * i11iIiiIii - ii1IiI1i
    oooO0o0o0O0 ( )
    if 68 - 68: OOooOOo % o0O
    if 26 - 26: o0O % i11iIiiIii % ii1IiI1i % O0OOo * O0OOo * OOo00O0Oo0oO
    if 24 - 24: o0O % oO0o0o0ooO0oO - I1i1I + IiiIII111iI * OOo00O0Oo0oO
    if 2 - 2: OOo000 - ii11
    time . sleep ( 10 )
    xbmc . executebuiltin ( 'SendClick(11)' )
    Oo0OoO00oOO0o = xbmcgui . Dialog ( )
    Oo0OoO00oOO0o . ok ( "[B]ITV Updater/Installer[/B]" , "Click ok to start the process!" , '' , '' )
    oo0oOo = xbmcgui . DialogProgress ( )
    oo0oOo . create ( "[B]ITV Updater/Installer[/B]" , "Wiping Infinity TV device..." , '' , 'Please wait as it will take a few minutes' )
    time . sleep ( 1 )
    oo0oOo . update ( 10 , "" , 'Preparing files...' , 'Please wait' )
    time . sleep ( 3 )
    try :
     for i1Ii , ii111iI1iIi1 , OOO in os . walk ( O00OOOoOoo0O , topdown = True ) :
      ii111iI1iIi1 [ : ] = [ i1I1ii11i1Iii for i1I1ii11i1Iii in ii111iI1iIi1 if i1I1ii11i1Iii not in Ii1I ]
      OOO [ : ] = [ II1iiiIi1 for II1iiiIi1 in OOO if II1iiiIi1 not in IiI1i ]
      for name in OOO :
       try :
        os . remove ( os . path . join ( i1Ii , name ) )
        oo0oOo . update ( 30 , "" , "Removing folders..." )
        os . rmdir ( os . path . join ( i1Ii , name ) )
       except : pass
       if 83 - 83: iIi % Oo % OOo000 - o0O * ooO00oOoo / OOooOOo
      for name in ii111iI1iIi1 :
       try : os . rmdir ( os . path . join ( i1Ii , name ) ) ; os . rmdir ( i1Ii )
       except : pass
    except : pass
    oo0oOo . update ( 50 , "" , "Removing folders..." )
    oo0o0OO0 ( )
    oo0o0OO0 ( )
    oo0o0OO0 ( )
    oo0oOo . update ( 75 , "" , "Removing folders..." )
    oo0o0OO0 ( )
    oo0o0OO0 ( )
    oo0o0OO0 ( )
    oo0o0OO0 ( )
    if 18 - 18: iiI1i1 + ii1IiI1i - o0O - IiiIII111iI
    if 71 - 71: OOooOOo
    oo0oOo . update ( 99 , "" , "Almost done..." )
    time . sleep ( 3 )
    iIi1 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
    oo0oOo = xbmcgui . DialogProgress ( )
    oo0oOo . create ( "ITV Updater/Installer" , "Wipe complete!" , 'Now Downloading...' , 'Please wait' )
    if 33 - 33: oO0o0o0ooO0oO
    if 62 - 62: OOo00O0Oo0oO + OOo000 + I11i / OOooOOo
    if 7 - 7: Oo + I11i . IiiIII111iI / Ii11111i
    if 22 - 22: I1i1I - I1i1I % ooO00oOoo . oO0o0o0ooO0oO + iIi
    if 63 - 63: IiiIII111iI % oO0o0o0ooO0oO * Oo + oO0o0o0ooO0oO / Ii11111i % o000o0o00o0Oo
    i11iiI1111 = os . path . join ( iIi1 , 'fullbackup.zip' )
    try :
     os . remove ( i11iiI1111 )
    except :
     pass
     if 45 - 45: ii11
    url = II1
    downloader . download ( url , i11iiI1111 , oo0oOo )
    oOoooo000Oo00 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
    time . sleep ( 2 )
    oo0oOo . update ( 0 , "" , "Installing..." )
    extract . all ( i11iiI1111 , oOoooo000Oo00 , oo0oOo )
    oo0oOo . update ( 0 , "" , "Finishing up..." )
    time . sleep ( 3 )
    xbmc . executebuiltin ( 'UpdateLocalAddons' )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    time . sleep ( 2 )
    Oo0OoO00oOO0o = xbmcgui . Dialog ( )
    Oo0OoO00oOO0o . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background." , "" , "" )
    try :
     os . remove ( i11iiI1111 )
    except :
     pass
    I1IIIiI1I1ii1 ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
    time . sleep ( 10 )
    xbmc . executebuiltin ( 'SendClick(11)' )
    Oo0OoO00oOO0o = xbmcgui . Dialog ( )
    Oo0OoO00oOO0o . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Installation is complete. " )
    try :
     os . remove ( II1I )
    except :
     pass
    xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
    if 20 - 20: OOooOOo * Oo * i1 . ooO00oOoo
    if 78 - 78: ii1IiI1i + O0OOo - OOo000 * oO0o0o0ooO0oO - OOooOOo % o0oo0o
  elif I1iIi1iiIIiI == 1 :
   url = iiiii
   oOoOOoOOooOO = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]Would you like to Save your Favorites? [/COLOR]" , '-By pressing YES all your Favorites will be saved. ' , '-If you press NO your Favorites will be wiped' , '-Both options will restore your Infinity TV to the Latest Software Build.' , yeslabel = 'YES' , nolabel = 'NO' )
   if 34 - 34: i1
   if oOoOOoOOooOO == 0 :
    oooO0o0o0O0 ( )
    time . sleep ( 10 )
    xbmc . executebuiltin ( 'SendClick(11)' )
    Oo0OoO00oOO0o = xbmcgui . Dialog ( )
    Oo0OoO00oOO0o . ok ( "[B]ITV Updater/Installer[/B]" , "Click ok to start the process!" , '' , '' )
    oo0oOo = xbmcgui . DialogProgress ( )
    oo0oOo . create ( "[B]ITV Updater/Installer[/B]" , "Wiping Infinity TV device..." , '' , 'Please wait as it will take a few minutes' )
    time . sleep ( 1 )
    oo0oOo . update ( 10 , "" , 'Preparing files...' , 'Please wait' )
    time . sleep ( 3 )
    try :
     for i1Ii , ii111iI1iIi1 , OOO in os . walk ( O00OOOoOoo0O , topdown = True ) :
      ii111iI1iIi1 [ : ] = [ i1I1ii11i1Iii for i1I1ii11i1Iii in ii111iI1iIi1 if i1I1ii11i1Iii not in iI11I1II ]
      OOO [ : ] = [ II1iiiIi1 for II1iiiIi1 in OOO if II1iiiIi1 not in o0Oo00 ]
      for name in OOO :
       try :
        os . remove ( os . path . join ( i1Ii , name ) )
        oo0oOo . update ( 30 , "" , 'Removing files...' , 'Please wait' )
        os . rmdir ( os . path . join ( i1Ii , name ) )
       except : pass
       if 80 - 80: I11i - Ii11111i / iiI1i1 - i11iIiiIii
      for name in ii111iI1iIi1 :
       try : os . rmdir ( os . path . join ( i1Ii , name ) ) ; os . rmdir ( i1Ii )
       except : pass
    except : pass
    oo0oOo . update ( 60 , "" , "Removing folders..." )
    oo0o0OO0 ( )
    oo0o0OO0 ( )
    oo0o0OO0 ( )
    oo0oOo . update ( 75 , "" , "Removing folders..." )
    oo0o0OO0 ( )
    oo0o0OO0 ( )
    oo0o0OO0 ( )
    oo0o0OO0 ( )
    if 68 - 68: iIi - OOo00O0Oo0oO % i1 % oO0o0o0ooO0oO
    if 11 - 11: i1 / iiI1i1 % ooO00oOoo + Oo + ii1IiI1i
    oo0oOo . update ( 99 , "" , "Almost done..." )
    time . sleep ( 3 )
    iIi1 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
    oo0oOo = xbmcgui . DialogProgress ( )
    oo0oOo . create ( "ITV Updater/Installer" , "Wipe complete!" , 'Now Downloading...' , 'Please wait' )
    if 40 - 40: I1i1I - ooO00oOoo . OOo000 * Ii11111i % oO0o0o0ooO0oO
    i11iiI1111 = os . path . join ( iIi1 , 'fullbackup.zip' )
    try :
     os . remove ( i11iiI1111 )
    except :
     pass
    downloader . download ( url , i11iiI1111 , oo0oOo )
    oOoooo000Oo00 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
    time . sleep ( 2 )
    oo0oOo . update ( 0 , "" , "Installing..." )
    extract . all ( i11iiI1111 , oOoooo000Oo00 , oo0oOo )
    oo0oOo . update ( 0 , "" , "Finishing up..." )
    time . sleep ( 3 )
    xbmc . executebuiltin ( 'UpdateLocalAddons' )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    time . sleep ( 2 )
    Oo0OoO00oOO0o = xbmcgui . Dialog ( )
    Oo0OoO00oOO0o . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background." , "" , "" )
    try :
     os . remove ( i11iiI1111 )
    except :
     pass
    I1IIIiI1I1ii1 ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
    time . sleep ( 10 )
    xbmc . executebuiltin ( 'SendClick(11)' )
    Oo0OoO00oOO0o = xbmcgui . Dialog ( )
    Oo0OoO00oOO0o . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Installation is complete. " )
    try :
     os . remove ( II1I )
    except :
     pass
    xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
    if 56 - 56: i11iIiiIii . Oo - IiiIII111iI * O0OOo
    if 91 - 91: iIi + OOooOOo - I11i
    if 84 - 84: OOo000 / ii11
   elif oOoOOoOOooOO == 1 :
    if 86 - 86: o0oo0o * o0O - i1 . o0oo0o % ii1IiI1i / ooO00oOoo
    if 11 - 11: IiiIII111iI * iIi + OOo00O0Oo0oO / OOo00O0Oo0oO
    if 37 - 37: i11iIiiIii + I11i
    oooO0o0o0O0 ( )
    if 23 - 23: o000o0o00o0Oo + O0OOo . o0oo0o * IiiIII111iI + OOo00O0Oo0oO
    if 18 - 18: ii11 * Oo . ii11 / i1
    if 8 - 8: Oo
    if 4 - 4: OOo00O0Oo0oO + OOo00O0Oo0oO * I1i1I - o0oo0o
    time . sleep ( 10 )
    xbmc . executebuiltin ( 'SendClick(11)' )
    Oo0OoO00oOO0o = xbmcgui . Dialog ( )
    Oo0OoO00oOO0o . ok ( "[B]ITV Updater/Installer[/B]" , "Click ok to start the process!" , '' , '' )
    oo0oOo = xbmcgui . DialogProgress ( )
    oo0oOo . create ( "[B]ITV Updater/Installer[/B]" , "Wiping Infinity TV device..." , '' , 'Please wait as it will take a few minutes' )
    time . sleep ( 1 )
    oo0oOo . update ( 10 , "" , 'Preparing files...' , 'Please wait' )
    time . sleep ( 3 )
    try :
     for i1Ii , ii111iI1iIi1 , OOO in os . walk ( O00OOOoOoo0O , topdown = True ) :
      ii111iI1iIi1 [ : ] = [ i1I1ii11i1Iii for i1I1ii11i1Iii in ii111iI1iIi1 if i1I1ii11i1Iii not in Ii1I ]
      OOO [ : ] = [ II1iiiIi1 for II1iiiIi1 in OOO if II1iiiIi1 not in IiI1i ]
      for name in OOO :
       try :
        os . remove ( os . path . join ( i1Ii , name ) )
        oo0oOo . update ( 30 , "" , "Removing folders..." )
        os . rmdir ( os . path . join ( i1Ii , name ) )
       except : pass
       if 78 - 78: OOo000 / o0O % o0oo0o
      for name in ii111iI1iIi1 :
       try : os . rmdir ( os . path . join ( i1Ii , name ) ) ; os . rmdir ( i1Ii )
       except : pass
    except : pass
    oo0oOo . update ( 50 , "" , "Removing folders..." )
    oo0o0OO0 ( )
    oo0o0OO0 ( )
    oo0o0OO0 ( )
    oo0oOo . update ( 75 , "" , "Removing folders..." )
    oo0o0OO0 ( )
    oo0o0OO0 ( )
    oo0o0OO0 ( )
    oo0o0OO0 ( )
    if 52 - 52: ooO00oOoo - o000o0o00o0Oo * iIi
    if 17 - 17: OOooOOo + ooO00oOoo * O0OOo * o0oo0o
    oo0oOo . update ( 99 , "" , "Almost done..." )
    time . sleep ( 3 )
    iIi1 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
    oo0oOo = xbmcgui . DialogProgress ( )
    oo0oOo . create ( "ITV Updater/Installer" , "Wipe complete!" , 'Now Downloading...' , 'Please wait' )
    if 36 - 36: i1 + Ii11111i
    if 5 - 5: Ii11111i * o0oo0o
    if 46 - 46: I1i1I
    if 33 - 33: o000o0o00o0Oo - o0O * OOooOOo - Ii11111i - ooO00oOoo
    if 84 - 84: oO0o0o0ooO0oO + Ii11111i - o0oo0o * o0oo0o
    i11iiI1111 = os . path . join ( iIi1 , 'fullbackup.zip' )
    try :
     os . remove ( i11iiI1111 )
    except :
     pass
     if 61 - 61: OOooOOo . iIi . OOooOOo / Ii11111i
    url = ooo0OO
    downloader . download ( url , i11iiI1111 , oo0oOo )
    oOoooo000Oo00 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
    time . sleep ( 2 )
    oo0oOo . update ( 0 , "" , "Installing..." )
    extract . all ( i11iiI1111 , oOoooo000Oo00 , oo0oOo )
    oo0oOo . update ( 0 , "" , "Finishing up..." )
    time . sleep ( 3 )
    xbmc . executebuiltin ( 'UpdateLocalAddons' )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    time . sleep ( 2 )
    Oo0OoO00oOO0o = xbmcgui . Dialog ( )
    Oo0OoO00oOO0o . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background." , "" , "" )
    try :
     os . remove ( i11iiI1111 )
    except :
     pass
    I1IIIiI1I1ii1 ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
    time . sleep ( 10 )
    xbmc . executebuiltin ( 'SendClick(11)' )
    Oo0OoO00oOO0o = xbmcgui . Dialog ( )
    Oo0OoO00oOO0o . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Installation is complete. " )
    try :
     os . remove ( II1I )
    except :
     pass
    xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
    if 72 - 72: I11i
    if 82 - 82: o0oo0o + OOooOOo / i11iIiiIii * OOo00O0Oo0oO . OOooOOo
    if 63 - 63: OOo00O0Oo0oO
def i1II ( ) :
 IiiI11i1I = [ ]
 OOo0 = xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.GetFavourites", "params": {"type": null, "properties": ["path", "thumbnail", "window", "windowparameter"]}, "id": 1}' )
 OOo0 = unicode ( OOo0 , 'utf-8' , errors = 'ignore' )
 OOo0 = simplejson . loads ( OOo0 )
 if OOo0 [ "result" ] [ "limits" ] [ "total" ] > 0 :
  for iiIii1IIi in OOo0 [ "result" ] [ "favourites" ] :
   iIi1 = ii1IiIiI1 ( iiIii1IIi )
   OOOoOo00O = { 'Label' : iiIii1IIi [ "title" ] ,
 'Thumb' : iiIii1IIi [ "thumbnail" ] ,
 'Type' : iiIii1IIi [ "type" ] ,
 'Builtin' : iIi1 ,
 'Path' : "plugin://script.extendedinfo/?info=action&&id=" + iIi1 }
   IiiI11i1I . append ( OOOoOo00O )
 print "ITEMS ################################################"
 print IiiI11i1I
 return IiiI11i1I
 if 59 - 59: ooO00oOoo % ii1IiI1i . I11i + o0O * ii11
def ii1IiIiI1 ( fav ) :
 if fav [ "type" ] == "media" :
  iIi1 = "PlayMedia(%s)" % ( fav [ "path" ] )
 elif fav [ "type" ] == "script" :
  iIi1 = "RunScript(%s)" % ( fav [ "path" ] )
 else :
  iIi1 = "ActivateWindow(%s,%s)" % (
 fav [ "window" ] , fav [ "windowparameter" ] )
 return iIi1
 if 41 - 41: OOo000 % OOo00O0Oo0oO
def i1iIiIi1I ( favtype ) :
 i1I1IIIiiI = i1II ( )
 OO0O0ooOOO00 = [ ]
 for iiIii1IIi in i1I1IIIiiI :
  if iiIii1IIi [ "Type" ] == favtype :
   OO0O0ooOOO00 . append ( iiIii1IIi )
 return OO0O0ooOOO00
 if 17 - 17: i1 . oO0o0o0ooO0oO . i1 + i1 / Ii11111i . I1i1I
def OO00OOoO0o ( ) :
 from t0mm0 . common . net import Net
 import socket
 import time
 if 4 - 4: I11i - i11iIiiIii / i11iIiiIii / OOooOOo
 OOOO0o = Net ( )
 if 10 - 10: oO0o0o0ooO0oO % IiiIII111iI
 iIi1 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
 i11iiI1111 = os . path . join ( iIi1 , 'fullbackup.zip' )
 import zipfile
 if 97 - 97: OOooOOo - oO0o0o0ooO0oO
 oooo00 = zipfile . ZipFile ( i11iiI1111 , "r" )
 for OO00O000OOO in oooo00 . namelist ( ) :
  if 'favourites.xml' in OO00O000OOO :
   iIOo0O = oooo00 . read ( OO00O000OOO )
   Ii11 = '<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
   if 8 - 8: Ii11111i + o0O * ooO00oOoo * o0oo0o * O0OOo / ii11
   OooO0oo = re . compile ( Ii11 ) . findall ( iIOo0O )
   print OooO0oo
   for OoOoO , iIii , OO0OoOOO0 in OooO0oo :
    if 90 - 90: I1i1I + o0O * OOo00O0Oo0oO / OOo000 . Oo + Oo
    iIii = iIii . replace ( 'thumb://None' , '/mnt/internal_sd/Android/data/org.xbmc.xbmc/files/.xbmc/addons/script.1channel.themepak/art/themes/Glossy_Black/favourites.png' )
    OO0OoOOO0 = OO0OoOOO0 . replace ( '&quot;' , '' ) . replace ( '&amp;' , '&' )
    json . loads ( xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % ( OoOoO , OO0OoOOO0 , iIii ) ) )
    for I11I , oOoO in enumerate ( fileinput . input ( ii1ii1ii , inplace = 1 ) ) :
     sys . stdout . write ( oOoO . replace ( 'RunScript(&quot;' , '' ) . replace ( '&quot;)' , '' ) )
  if 26 - 26: o0oo0o / Ii11111i - I11i + O0OOo
  if 38 - 38: OOooOOo / OOo00O0Oo0oO . i1 / I11i / Ii11111i + ii1IiI1i
  if 96 - 96: o000o0o00o0Oo
  if 18 - 18: o000o0o00o0Oo * O0OOo - OOo000
  if 31 - 31: Ii11111i - i1 % o0oo0o % iIi
  if 45 - 45: OOo00O0Oo0oO + o0O * i11iIiiIii
  if 13 - 13: OOooOOo * iIi - OOo000 / ooO00oOoo + O0OOo + ii11
  if 39 - 39: ii1IiI1i - OOooOOo
  if 81 - 81: OOo00O0Oo0oO - i1 * OOooOOo
  if 23 - 23: o0O / iIi
  if 28 - 28: Ii11111i * I1i1I - iiI1i1
  if 19 - 19: O0OOo
  if 67 - 67: i1 % ii1IiI1i / ii11 . i11iIiiIii - OOo000 + i1
def i1iiiIi1i ( ) :
 from t0mm0 . common . net import Net
 import socket
 import time
 if 67 - 67: o0oo0o / Oo * iiI1i1 / ooO00oOoo * OOo00O0Oo0oO / iIi
 if ( os . path . isfile ( oooooOoo0ooo ) ) :
  OOOO0o = Net ( )
  OOoOO0OO = ''
  II1iiiIi1 = open ( ii1ii1ii , mode = 'w' )
  II1iiiIi1 . write ( OOoOO0OO )
  II1iiiIi1 . close ( )
  if 26 - 26: o000o0o00o0Oo . o000o0o00o0Oo
  iIOo0O = open ( oooooOoo0ooo ) . read ( )
  Ii11 = '<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
  OooO0oo = re . compile ( Ii11 ) . findall ( iIOo0O )
  for i1oO , iIIi1IIi , i111i11I1ii in OooO0oo :
   json . loads ( xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % ( i1oO , i111i11I1ii , iIIi1IIi ) ) )
   for I11I , oOoO in enumerate ( fileinput . input ( ii1ii1ii , inplace = 1 ) ) :
    sys . stdout . write ( oOoO . replace ( 'RunScript(&quot;' , '' ) . replace ( '&quot;)' , '' ) . replace ( '&amp;' , '&' ) )
    if 64 - 64: iIi / i11iIiiIii / Oo . OOooOOo
  iIi1 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
  i1iiIIi11I = os . path . join ( iIi1 , 'favourites.xml' )
  downloader . download ( I1IiiI , i1iiIIi11I )
  time . sleep ( 2 )
  OO00O000OOO = i1iiIIi11I
  if 80 - 80: I1i1I * i1
  Ii11 = '<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
  if 78 - 78: o0oo0o
  I1i1i1I1iI1 = re . compile ( Ii11 ) . findall ( iIOo0O )
  for OoOoO , iIii , OO0OoOOO0 in I1i1i1I1iI1 :
   iIOo0O = open ( ii1ii1ii ) . read ( )
   if OoOoO in iIOo0O : break
   if 53 - 53: ooO00oOoo + IiiIII111iI / i11iIiiIii - Oo * iIi / OOooOOo
   if 89 - 89: ii1IiI1i / IiiIII111iI - o0O / OOo000 . i11iIiiIii . OOo000
   if 48 - 48: i1 + i1 . oO0o0o0ooO0oO - I1i1I
   iIii = iIii . replace ( 'thumb://None' , '/mnt/internal_sd/Android/data/org.xbmc.xbmc/files/.xbmc/addons/script.1channel.themepak/art/themes/Glossy_Black/favourites.png' )
   OO0OoOOO0 = OO0OoOOO0 . replace ( '&quot;' , '' )
   if 63 - 63: iIi
   json . loads ( xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % ( OoOoO , OO0OoOOO0 , iIii ) ) )
   for I11I , oOoO in enumerate ( fileinput . input ( ii1ii1ii , inplace = 1 ) ) :
    sys . stdout . write ( oOoO . replace ( 'RunScript(&quot;' , '' ) . replace ( '&quot;)' , '' ) )
 else :
  pass
  if 71 - 71: I11i . OOo000 * o000o0o00o0Oo % OOooOOo + ooO00oOoo
  if 36 - 36: ii11
def i1iiI ( ) :
 if 74 - 74: oO0o0o0ooO0oO % OOo00O0Oo0oO
 import time
 if 7 - 7: o0O
 try :
  oo0oOo = xbmcgui . DialogProgress ( )
  oo0oOo . create ( "ITV Updater/Installer" , "Retrieving backup file... " , '' , 'Please wait' )
  i11iiI1111 = xbmc . translatePath ( os . path . join ( O000OOo00oo , 'backup.zip' ) )
  oOoooo000Oo00 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
  time . sleep ( 2 )
  oo0oOo . update ( 0 , "" , "Installing..." )
  extract . all ( i11iiI1111 , oOoooo000Oo00 , oo0oOo )
  oo0oOo . update ( 0 , "" , "Finishing up..." )
  time . sleep ( 5 )
  Oo0OoO00oOO0o = xbmcgui . Dialog ( )
  Oo0OoO00oOO0o . ok ( "ITV Updater/Installer" , "[COLOR yellow]Installation nearly complete but one important step remains. [/COLOR]" )
  Oo0OoO00oOO0o = xbmcgui . Dialog ( )
  Oo0OoO00oOO0o . ok ( "ITV Updater/Installer" , "[COLOR red]URGENT: Please unplug or power off your device immediately and then reboot to finish setup. [/COLOR]" )
  if 27 - 27: iIi . OOooOOo + i11iIiiIii
 except :
  Oo0OoO00oOO0o = xbmcgui . Dialog ( )
  Oo0OoO00oOO0o . ok ( 'ITV Updater/Installer' , 'You need to backup your build first.\nTo backup your box press backup on main menu.' , '' , '' )
  if 86 - 86: O0OOo / Oo - Oo + OOo00O0Oo0oO + iIi
  if 33 - 33: Oo . o000o0o00o0Oo . ii11 . I11i
  if 49 - 49: OOo00O0Oo0oO
def Ii1ii1IiIII ( name , url , mode , iconimage , fanart , description ) :
 O0oOOo0o = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 OOO00O = True
 I1 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 I1 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 I1 . setProperty ( "Fanart_Image" , fanart )
 OOO00O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0oOOo0o , listitem = I1 , isFolder = False )
 return OOO00O
 if 7 - 7: iiI1i1 * O0OOo + o0O % i11iIiiIii
def OO0ooo0oOO ( name , url , mode , iconimage , fanart , description ) :
 O0oOOo0o = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 OOO00O = True
 I1 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 I1 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 I1 . setProperty ( "Fanart_Image" , fanart )
 OOO00O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0oOOo0o , listitem = I1 , isFolder = True )
 return OOO00O
 if 8 - 8: I1i1I * i1
 if 73 - 73: Oo / iIi / O0OOo / iiI1i1
 if 11 - 11: o0oo0o + ii11 - OOooOOo / iiI1i1
def iIIi1iI1I1IIi ( ) :
 O0OO0 = [ ]
 O0ooo0o0 = sys . argv [ 2 ]
 if len ( O0ooo0o0 ) >= 2 :
  oO0ooOoO = sys . argv [ 2 ]
  ooO0000o00O = oO0ooOoO . replace ( '?' , '' )
  if ( oO0ooOoO [ len ( oO0ooOoO ) - 1 ] == '/' ) :
   oO0ooOoO = oO0ooOoO [ 0 : len ( oO0ooOoO ) - 2 ]
  O0Ooo = ooO0000o00O . split ( '&' )
  O0OO0 = { }
  for I11I in range ( len ( O0Ooo ) ) :
   oO00oOOo0Oo = { }
   oO00oOOo0Oo = O0Ooo [ I11I ] . split ( '=' )
   if ( len ( oO00oOOo0Oo ) ) == 2 :
    O0OO0 [ oO00oOOo0Oo [ 0 ] ] = oO00oOOo0Oo [ 1 ]
    if 5 - 5: Oo . i1 / Ii11111i % iiI1i1
 return O0OO0
 if 60 - 60: o0O / ii1IiI1i + OOo00O0Oo0oO . i11iIiiIii
 if 40 - 40: Oo
oO0ooOoO = iIIi1iI1I1IIi ( )
i1i1IIIIi1i = None
OoOoO = None
oOO = None
Ii11iiI = None
IIi1iiii1iI = None
iIiiii = None
if 66 - 66: O0OOo - I11i
if 8 - 8: oO0o0o0ooO0oO / ooO00oOoo . IiiIII111iI + OOo00O0Oo0oO / i11iIiiIii
try :
 i1i1IIIIi1i = urllib . unquote_plus ( oO0ooOoO [ "url" ] )
except :
 pass
try :
 OoOoO = urllib . unquote_plus ( oO0ooOoO [ "name" ] )
except :
 pass
try :
 Ii11iiI = urllib . unquote_plus ( oO0ooOoO [ "iconimage" ] )
except :
 pass
try :
 oOO = int ( oO0ooOoO [ "mode" ] )
except :
 pass
try :
 IIi1iiii1iI = urllib . unquote_plus ( oO0ooOoO [ "fanart" ] )
except :
 pass
try :
 iIiiii = urllib . unquote_plus ( oO0ooOoO [ "description" ] )
except :
 pass
 if 31 - 31: I1i1I - ii1IiI1i + o000o0o00o0Oo . Ii11111i / ii11 % ii1IiI1i
 if 6 - 6: ii11 * i11iIiiIii % ii1IiI1i % i11iIiiIii + Oo / I11i
print str ( iiIiI ) + ': ' + str ( IIII )
print "Mode: " + str ( oOO )
print "URL: " + str ( i1i1IIIIi1i )
print "Name: " + str ( OoOoO )
print "IconImage: " + str ( Ii11iiI )
if 53 - 53: O0OOo + ii1IiI1i
if 70 - 70: OOo00O0Oo0oO
def ooOOo00O00Oo ( content , viewType ) :
 if 67 - 67: OOooOOo
 if content :
  xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , content )
 if oooO0oo0oOOOO . getSetting ( 'auto-view' ) == 'true' :
  xbmc . executebuiltin ( "Container.SetViewMode(%s)" % oooO0oo0oOOOO . getSetting ( viewType ) )
  if 29 - 29: i1 - i11iIiiIii - o0O + ooO00oOoo * ii11
  if 2 - 2: I11i - I1i1I + IiiIII111iI . Oo * Oo / o0oo0o
if oOO == None or i1i1IIIIi1i == None or len ( i1i1IIIIi1i ) < 1 :
 iiI11i1II ( )
 if 93 - 93: I11i
elif oOO == 1 :
 oooO ( OoOoO , i1i1IIIIi1i , iIiiii )
 if 53 - 53: OOooOOo + Ii11111i + iIi
elif oOO == 2 :
 I11iII ( OoOoO , i1i1IIIIi1i , iIiiii )
 if 24 - 24: o000o0o00o0Oo - ii11 - o000o0o00o0Oo * OOo00O0Oo0oO . OOooOOo / ii11
elif oOO == 3 :
 oOoO00O0 ( )
 if 66 - 66: Ii11111i
elif oOO == 4 :
 i1iiI ( )
 if 97 - 97: I11i - OOooOOo / oO0o0o0ooO0oO * IiiIII111iI
elif oOO == 5 :
 iiIiIIIiiI ( )
 if 55 - 55: Oo . o000o0o00o0Oo
elif oOO == 6 :
 I1I1iI ( OoOoO , i1i1IIIIi1i , iIiiii )
 if 87 - 87: Oo % ii1IiI1i
elif oOO == 7 :
 ooO0o ( )
 if 100 - 100: oO0o0o0ooO0oO . IiiIII111iI * oO0o0o0ooO0oO - IiiIII111iI . O0OOo * OOo000
elif oOO == 8 :
 Oo0OoO00oOO0o = xbmcgui . Dialog ( )
 Oo0OoO00oOO0o . ok ( "ITV Updater/Installer" , "[COLOR yellow]Important![/COLOR]" , "" , "Please POWER DOWN your Infinity TV, and then turn it back ON for the changes to take place." )
 try :
  os . remove ( lib )
 except :
  pass
 i1iiiIi1i ( )
 if 89 - 89: iiI1i1 + ii11 * oO0o0o0ooO0oO
 if 28 - 28: OOooOOo . iIi % OOo00O0Oo0oO / I11i / ooO00oOoo
 if 36 - 36: Oo + O0OOo - ii11 + ii1IiI1i + OOooOOo
 if 4 - 4: o0O . O0OOo + OOo000 * oO0o0o0ooO0oO . I1i1I
 if 87 - 87: o0oo0o / iiI1i1 / i11iIiiIii
 try :
  os . remove ( oooooOoo0ooo )
 except :
  pass
  if 74 - 74: iIi / OOo00O0Oo0oO % Oo
elif oOO == 9 :
 oOOoOo ( OoOoO , i1i1IIIIi1i , iIiiii )
 if 88 - 88: o0oo0o - i11iIiiIii % Oo * O0OOo + OOo00O0Oo0oO
elif oOO == 10 :
 oO0o00oOOooO0 ( OoOoO , i1i1IIIIi1i , iIiiii )
 if 52 - 52: o0O . IiiIII111iI + o0oo0o % iiI1i1
elif oOO == 11 :
 I1iIIIi1 ( OoOoO , i1i1IIIIi1i , iIiiii )
 if 62 - 62: Oo
elif oOO == 12 :
 Ooooooo ( OoOoO , i1i1IIIIi1i , iIiiii )
 if 15 - 15: O0OOo + OOo000 . ooO00oOoo * iiI1i1 . o0oo0o
elif oOO == 13 :
 IiI11iI1i1i1i ( OoOoO , i1i1IIIIi1i , iIiiii )
 if 18 - 18: I11i % o0O + oO0o0o0ooO0oO % OOo000
elif oOO == 15 :
 OOoO0 ( OoOoO , i1i1IIIIi1i , iIiiii )
 if 72 - 72: ii1IiI1i
elif oOO == 16 :
 oOIi111 ( OoOoO , i1i1IIIIi1i , iIiiii )
 if 45 - 45: Ii11111i - Oo % oO0o0o0ooO0oO
elif oOO == 99 :
 OoOoOo00o0 ( )
 if 38 - 38: oO0o0o0ooO0oO % ooO00oOoo - OOooOOo
 if 87 - 87: iiI1i1 % IiiIII111iI
 if 77 - 77: ii1IiI1i - I11i . iIi
 if 26 - 26: Oo * ii11 . I11i
 if 59 - 59: i1 + I11i - Oo
 if 62 - 62: i11iIiiIii % ooO00oOoo . ii11 . ooO00oOoo
 if 84 - 84: i11iIiiIii * iiI1i1
 if 18 - 18: ooO00oOoo - OOo000 - o0oo0o / oO0o0o0ooO0oO - i1
 if 30 - 30: i1 + OOo00O0Oo0oO + o0O
elif oOO == 98 :
 xbmc . executebuiltin ( "RunScript(script.speedtestnet)" )
 if 14 - 14: Oo / ooO00oOoo - ii1IiI1i - iIi % I1i1I
 if 49 - 49: I1i1I * iIi / Oo / Ii11111i * ii1IiI1i
elif oOO == 97 :
 IiII1I11i1I1I ( i1i1IIIIi1i )
 if 57 - 57: o0oo0o - iIi / I1i1I % i11iIiiIii
elif oOO == 96 :
 iI1Iii ( )
 if 3 - 3: o000o0o00o0Oo . I1i1I % IiiIII111iI + OOo00O0Oo0oO
elif oOO == 95 :
 Oo0OoO00oOO0o = xbmcgui . Dialog ( )
 Oo0OoO00oOO0o . ok ( "Update Add-ons" , "Press OK to make sure all your add-ons apps are up-to-date." , "" , "" )
 xbmc . executebuiltin ( 'UpdateLocalAddons' )
 xbmc . executebuiltin ( "UpdateAddonRepos" )
 if 64 - 64: I11i
elif oOO == 90 :
 O0OO0O ( )
 if 29 - 29: Oo / i11iIiiIii / IiiIII111iI % iIi % i11iIiiIii
 if 18 - 18: ooO00oOoo + oO0o0o0ooO0oO
 if 80 - 80: iIi + Oo * OOo000 + iiI1i1
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
if 75 - 75: O0OOo / Oo / ooO00oOoo / ii11 % I1i1I + o0O
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
