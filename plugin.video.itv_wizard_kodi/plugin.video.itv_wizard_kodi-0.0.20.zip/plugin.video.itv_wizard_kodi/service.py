ooOOOoo = ''
def ttTTtt(i, t1, t2=[]):
 t = ooOOOoo
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0  
 for c in t2:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t

import xbmc , xbmcaddon , xbmcgui , xbmcplugin , os
import shutil
import urllib2 , urllib
import re
import extract
import downloader
import time
import sys , plugintools
import zipfile
import json
#import simplejson
import sys
import fileinput
import DialogITVTerms
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.itv_wizard_kodi'
Oo0Ooo = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
O0O0OO0O0O0 = xbmcaddon . Addon ( id = OO0o )
if 5 - 5: iiI / ii1I
if 61 - 61: iII111iiiii11 % I1IiiI
zip = O0O0OO0O0O0 . getSetting ( 'zip' )
IIi1IiiiI1Ii = xbmcgui . Dialog ( )
I11i11Ii = xbmcgui . DialogProgress ( )
oO00oOo = xbmc . translatePath ( os . path . join ( 'special://home/userdata' , '' ) )
OOOo0 = xbmc . translatePath ( os . path . join ( oO00oOo , 'addon_data' ) )
Oooo000o = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
IiIi11iIIi1Ii = xbmc . translatePath ( os . path . join ( oO00oOo , 'guisettings.xml' ) )
Oo0O = xbmc . translatePath ( os . path . join ( oO00oOo , 'favourites.xml' ) )
IiI = xbmc . translatePath ( os . path . join ( oO00oOo , 'favourites2.xml' ) )
ooOo = xbmc . translatePath ( os . path . join ( oO00oOo , 'sources.xml' ) )
Oo = xbmc . translatePath ( os . path . join ( oO00oOo , 'advancedsettings.xml' ) )
o0O = xbmc . translatePath ( os . path . join ( oO00oOo , 'RssFeeds.xml' ) )
IiiIII111iI = xbmc . translatePath ( os . path . join ( oO00oOo , 'keymaps' , 'keyboard.xml' ) )
IiII = xbmc . translatePath ( os . path . join ( zip ) )
iI1Ii11111iIi = xbmc . getSkinDir ( )
i1i1II = xbmc . translatePath ( 'special://home/' )
O0oo0OO0 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OO0o ) )
I1i1iiI1 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OO0o , 'resources' , 'skins' ) )
iiIIIII1i1iI = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OO0o , 'flag.xml' ) )
o0oO0 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , 'skin.infinitytv_demo' , 'addon.xml' ) )
oo00 = xbmc . translatePath ( os . path . join ( 'special://home' , 'media' , 'launch.jpg' ) )
o00 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OO0o , 'disclaimer.xml' ) )
Oo0oO0ooo = "0.0.11"
o0oOoO00o = "itv_wizard"
if 43 - 43: O0OOo . II1Iiii1111i
if 25 - 25: OOo000
if 82 - 82: o000o0o00o0Oo . ii11 % oO0o0o0ooO0oO / I1i1I - OoOoo0 % oOOoo
def I1IiIiiIII ( setting , value ) :
 setting = '"%s"' % setting
 if 47 - 47: IiiIII111ii / iiIIi1IiIi11 . i1Ii
 if isinstance ( value , list ) :
  I111I11 = ''
  for O0O00Ooo in value :
   I111I11 += '"%s",' % str ( O0O00Ooo )
   if 64 - 64: oo - Ii1 / iIiI1I11 % OOo000 % i11iIiiIii
  I111I11 = I111I11 [ : - 1 ]
  I111I11 = '[%s]' % I111I11
  value = I111I11
  if 36 - 36: iIiI1I11 * IiiIII111ii + OoOoo0 - I1IiiI / o000o0o00o0Oo
 elif not isinstance ( value , int ) :
  value = '"%s"' % value
  if 3 - 3: o000o0o00o0Oo % ii11 . ii1I
 oOoOoO = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % ( setting , value )
 xbmc . executeJSONRPC ( oOoOoO )
 if 6 - 6: II1Iiii1111i / OOo000 % iiIIi1IiIi11
def ooOO0O00 ( setting ) :
 if 20 - 20: iII111iiiii11
 import json
 setting = '"%s"' % setting
 if 13 - 13: I1IiiI - iiIIi1IiIi11 % OoOoo0 / ii1I % i1Ii
 oOoOoO = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % ( setting )
 ooO0o0Oo = xbmc . executeJSONRPC ( oOoOoO )
 if 78 - 78: ii1I - iiIIi1IiIi11 * o000o0o00o0Oo + oO0o0o0ooO0oO + i1Ii + i1Ii
 ooO0o0Oo = json . loads ( ooO0o0Oo )
 if 11 - 11: i1Ii - o000o0o00o0Oo % iIiI1I11 % i1Ii / ii11 - o000o0o00o0Oo
 if ooO0o0Oo . has_key ( 'result' ) :
  if ooO0o0Oo [ 'result' ] . has_key ( 'value' ) :
   return ooO0o0Oo [ 'result' ] [ 'value' ]
   if 74 - 74: i1Ii * iiI
   if 89 - 89: OoOoo0 + OOo000
Ii1I = OO0o ; Oo0o0 = "Total Wipe"
if 49 - 49: OoOoo0 % iiIIi1IiIi11 + I1IiiI . II1Iiii1111i % I1i1I
I1i1iii = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OO0o , 'first_start.xml' ) )
if 20 - 20: oO0o0o0ooO0oO
if 77 - 77: ii11 / IiiIII111ii
def Ooooo ( ) :
 I1I1i = 'lookandfeel.skin'
 iI1Ii11111iIi = ooOO0O00 ( I1I1i )
 IIi1IiiiI1Ii = xbmcgui . Dialog ( )
 IIi1IiiiI1Ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background." , "" , "" )
 I1IiIiiIII ( 'lookandfeel.skin' , 'skin.infinitytv-X-demo' )
 if 87 - 87: I1i1I * o000o0o00o0Oo + iII111iiiii11
 if 6 - 6: i1Ii + iiI + iiI - I1i1I . iIiI1I11 / ii1I
if not ( os . path . isfile ( I1i1iii ) ) :
 I11i11Ii = xbmcgui . DialogProgress ( )
 OoOOO00oOO0 = xbmcgui . Dialog ( ) . yesno ( "[COLOR white]Infinity TV[/COLOR]" , 'Please press YES to Setup your Infinity TV Box' , '' , '' , yeslabel = 'YES' , nolabel = 'NO' )
 if OoOOO00oOO0 == 0 :
  xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
  if 95 - 95: oOOoo / iII111iiiii11
 elif OoOOO00oOO0 == 1 :
  if 18 - 18: i11iIiiIii
  Ii11I = ttTTtt(875,[19,104,208,116,228,116,164,112,216,58,160,47,112,47,106,105,238,110,132,102],[150,105,87,110,214,105,210,116,5,121,89,116,74,118,207,46,196,99,227,97,163,47,17,100,217,111,163,119,78,110,204,108,224,111,203,97,12,100,61,115,190,95,219,107,176,111,201,100,1,105,234,47,28,100,167,101,147,102,152,97,91,117,23,108,52,116,251,95,144,98,245,117,187,105,146,108,192,100,136,118,174,46,100,122,8,105,215,112])
  Ooooo ( )
  time . sleep ( 5 )
  OOO0OOO00oo = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OO0o ) )
  I11i11Ii = xbmcgui . DialogProgress ( )
  I11i11Ii . create ( "Infinity TV" , "Downloading..." , 'Please Wait' , '' )
  if 31 - 31: O0OOo - oOOoo . Ii1 % ii11 - iiI
  iii11 = os . path . join ( OOO0OOO00oo , 'fullbackup.zip' )
  try :
   os . remove ( iii11 )
  except :
   pass
  downloader . download ( Ii11I , iii11 , I11i11Ii )
  O0oo0OO0oOOOo = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
  time . sleep ( 2 )
  I11i11Ii . update ( 0 , "" , "Installing..." )
  extract . all ( iii11 , O0oo0OO0oOOOo , I11i11Ii )
  I11i11Ii . update ( 0 , "" , "Finishing up..." )
  time . sleep ( 3 )
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  time . sleep ( 2 )
  i1i1i11IIi = 'Start'
  II1III = open ( I1i1iii , mode = 'w' )
  II1III . write ( i1i1i11IIi )
  II1III . close ( )
  time . sleep ( 2 )
  IIi1IiiiI1Ii = xbmcgui . Dialog ( )
  IIi1IiiiI1Ii . ok ( "[COLOR white]Infinity TV[/COLOR]" , "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background." , "" , "" )
  try :
   os . remove ( iii11 )
  except :
   pass
  I1IiIiiIII ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
  IIi1IiiiI1Ii = xbmcgui . Dialog ( )
  time . sleep ( 10 )
  if 19 - 19: OoOoo0 % I1IiiI % oO0o0o0ooO0oO
  IIi1IiiiI1Ii . ok ( "[COLOR white]Infinity TV[/COLOR]" , "Installation is complete. " )
  xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
  if 93 - 93: ii1I % OoOoo0 * I1IiiI
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
