import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import sys,plugintools
import zipfile
import json
#import simplejson
import sys
import fileinput
import DialogITVTerms

itv_wizard_addon = 'plugin.video.itv_wizard_kodi'
USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
ADDON=xbmcaddon.Addon(id=itv_wizard_addon)


zip          =  ADDON.getSetting('zip')
dialog       =  xbmcgui.Dialog()
dp           =  xbmcgui.DialogProgress()
USERDATA     =  xbmc.translatePath(os.path.join('special://home/userdata',''))
ADDON_DATA   =  xbmc.translatePath(os.path.join(USERDATA,'addon_data'))
ADDONS       =  xbmc.translatePath(os.path.join('special://home','addons'))
PACKAGES     =  xbmc.translatePath(os.path.join('special://home','addons','packages'))
GUI          =  xbmc.translatePath(os.path.join(USERDATA,'guisettings.xml'))
FAVS         =  xbmc.translatePath(os.path.join(USERDATA,'favourites.xml'))
FAVS2         =  xbmc.translatePath(os.path.join(USERDATA,'favourites2.xml'))
SOURCE       =  xbmc.translatePath(os.path.join(USERDATA,'sources.xml'))
ADVANCED     =  xbmc.translatePath(os.path.join(USERDATA,'advancedsettings.xml'))
RSS          =  xbmc.translatePath(os.path.join(USERDATA,'RssFeeds.xml'))
KEYMAPS      =  xbmc.translatePath(os.path.join(USERDATA,'keymaps','keyboard.xml'))
USB          =  xbmc.translatePath(os.path.join(zip))
skin         =  xbmc.getSkinDir()
HOME         =  xbmc.translatePath('special://home/')
infinitypath  =  xbmc.translatePath(os.path.join('special://home','addons',itv_wizard_addon))
skinspath  =  xbmc.translatePath(os.path.join('special://home','addons',itv_wizard_addon,'resources','skins'))
flag = xbmc.translatePath(os.path.join('special://home','addons',itv_wizard_addon,'flag.xml'))
demo       =  xbmc.translatePath(os.path.join('special://home','addons','skin.infinitytv_demo','addon.xml'))
media       =  xbmc.translatePath(os.path.join('special://home','media','launch.jpg'))
disclaimer = xbmc.translatePath(os.path.join('special://home','addons',itv_wizard_addon,'disclaimer.xml'))
addonxmlfile = xbmc.translatePath(os.path.join('special://home','addons',itv_wizard_addon,'addon.xml'))
VERSION = "0.0.11"
PATH = "itv_wizard"

#########################################################################################################################################################

def setSetting(setting, value):
    setting = '"%s"' % setting

    if isinstance(value, list):
        text = ''
        for item in value:
            text += '"%s",' % str(item)

        text  = text[:-1]
        text  = '[%s]' % text
        value = text

    elif not isinstance(value, int):
        value = '"%s"' % value

    query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % (setting, value)
    xbmc.executeJSONRPC(query)

def getSetting(setting):
  
        import json
        setting = '"%s"' % setting
 
        query = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % (setting)
        response = xbmc.executeJSONRPC(query)

        response = json.loads(response)                

        if response.has_key('result'):
            if response['result'].has_key('value'):
                return response ['result']['value']
        

AddonID=itv_wizard_addon; AddonTitle="Total Wipe"

first_start  = xbmc.translatePath(os.path.join('special://home','addons',itv_wizard_addon,'first_start.xml'))


def switchTodemo():
    setting = 'lookandfeel.skin'
    skin = getSetting(setting)
    dialog = xbmcgui.Dialog()
    dialog.ok("[COLOR yellow]ITV Updater/Installer[/COLOR]", "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background.","","")
    if xbmc_version == "17.3 Git:20170524-147cec4":
        setSetting('lookandfeel.skin', 'skin.infinitytv-XK-demo')
    else:
        setSetting('lookandfeel.skin', 'skin.infinitytv-X-demo')

    
if not(os.path.isfile(addonxmlfile)):
    dp = xbmcgui.DialogProgress()
    choice_complete_build = xbmcgui.Dialog().yesno("[COLOR white]Infinity TV[/COLOR]", 'Please press YES to Setup your Infinity TV Box', '', '', yeslabel='YES',nolabel='NO')
    if choice_complete_build == 0:
        xbmc.executebuiltin("XBMC.ActivateWindow(Home)")
        
    elif choice_complete_build == 1:
        if xbmc_version == "17.3 Git:20170524-147cec4":
            url = 'http://infinitytv.ca/downloads_kodi/default_buildv_kypton.zip'
        else:
            url = 'http://infinitytv.ca/downloads_kodi/default_buildv.zip'
        switchTodemo()
        time.sleep(5)
        path = xbmc.translatePath(os.path.join('special://home','addons','packages'))
        dp = xbmcgui.DialogProgress()
        dp.create("Infinity TV","Downloading...",'Please Wait', '')
        
        lib=os.path.join(path, 'fullbackup.zip')
        try:
           os.remove(lib)
        except:
           pass
        downloader.download(url, lib, dp)
        addonfolder = xbmc.translatePath(os.path.join('special://','home'))
        time.sleep(2)
        dp.update(0,"", "Installing...")
        extract.all(lib,addonfolder,dp)
        dp.update(0,"", "Finishing up...")
        time.sleep(3)
        xbmc.executebuiltin('UpdateLocalAddons') 
        xbmc.executebuiltin("UpdateAddonRepos")
        time.sleep(2)
        time.sleep(2)
        dialog = xbmcgui.Dialog()
        dialog.ok("[COLOR white]Infinity TV[/COLOR]", "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background.","","")
        try:
           os.remove(lib)
        except:
           pass
        if xbmc_version == "17.3 Git:20170524-147cec4":
            setSetting('lookandfeel.skin', 'skin.infinitytv-XK')
        else:
            setSetting('lookandfeel.skin', 'skin.infinitytv-X')
        dialog = xbmcgui.Dialog()
        time.sleep(10)
        #reloadskin()
        dialog.ok("[COLOR white]Infinity TV[/COLOR]", "Installation is complete. ")
        xbmc.executebuiltin("XBMC.ActivateWindow(Home)")
            
