ooOOOoo = ''
def ttTTtt(i, t1, t2=[]):
 t = ooOOOoo
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0  
 for c in t2:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t

import xbmc , xbmcaddon , xbmcgui , xbmcplugin , os
import shutil
import urllib2 , urllib
import re
import extract
import downloader
import time
import sys , plugintools
import zipfile
import json
#import simplejson
import sys
import fileinput
import DialogITVTerms
if 64 - 64: i11iIiiIii
OO0o = ttTTtt(0,[104,219,116,66,116,168,112,251,58],[190,47,95,47,135,105,119,110,93,102,83,105,57,110,101,105,83,116,74,121,164,116,20,118,97,46,174,99,48,97,252,47,225,100,173,111,1,119,205,110,117,108,18,111,231,97,34,100,174,115,136,95,151,107,231,111,116,100,151,105,88,47])
Oo0Ooo = ttTTtt(155,[10,104,226,116],[28,116,120,112,1,58,253,47,170,47,250,105,198,110,104,102,199,105,7,110,166,105,97,116,244,121,100,116,102,118,46,46,68,99,25,97,140,47,202,100,27,111,15,119,163,110,151,108,118,111,29,97,252,100,140,115,77,95,202,107,70,111,194,100,65,105,64,47,91,117,125,112,57,100,216,97,90,116,85,101,36,46,75,122,83,105,212,112])
O0O0OO0O0O0 = ttTTtt(0,[104,229,116,35,116,118,112,197,58,55,47,222,47],[68,105,48,110,194,102,51,105,87,110,198,105,229,116,190,121,8,116,19,118,22,46,61,99,113,97,188,47,59,100,47,111,222,119,131,110,147,108,183,111,146,97,248,100,189,115,23,95,109,107,159,111,68,100,116,105,80,47,165,102,52,117,57,108,47,108,47,95,0,114,107,101,115,115,196,116,3,111,218,114,142,101,131,46,71,122,35,105,14,112])
iiiii = ttTTtt(503,[226,104,159,116,235,116,86,112,113,58,248,47],[254,47,153,105,39,110,7,102,122,105,208,110,133,105,105,116,166,121,105,116,162,118,203,46,67,99,126,97,183,47,116,100,57,111,186,119,186,110,82,108,61,111,49,97,52,100,191,115,52,95,223,107,204,111,51,100,46,105,186,47,58,97,152,100,183,117,139,108,241,116,154,95,253,102,66,117,7,108,222,108,12,95,8,114,152,101,122,115,240,116,148,111,94,114,55,101,218,46,128,122,97,105,236,112])
ooo0OO = ttTTtt(0,[104,145,116,105,116,27,112,181,58],[16,47,152,47,234,105,8,110,88,102,113,105,1,110,9,105,40,116,22,121,91,116,81,118,110,46,154,99,96,97,137,47,155,100,84,111,55,119,30,110,116,108,225,111,123,97,60,100,162,115,33,95,113,107,120,111,242,100,66,105,157,47,27,97,191,100,54,117,71,108,182,116,1,95,55,102,59,117,5,108,32,108,131,95,47,114,145,101,60,115,2,116,59,111,46,114,132,101,255,95,59,102,228,97,104,118,84,46,134,122,135,105,248,112])
II1 = ttTTtt(423,[187,104,37,116,36,116,46,112,118,58],[148,47,180,47,166,105,105,110,211,102,154,105,57,110,22,105,154,116,29,121,188,116,245,118,105,46,69,99,236,97,227,47,91,100,116,111,181,119,141,110,99,108,161,111,247,97,5,100,36,115,149,95,78,107,136,111,132,100,237,105,66,47,254,102,45,117,123,108,218,108,149,95,190,114,124,101,45,115,245,116,50,111,0,114,35,101,82,95,118,102,29,97,30,118,186,46,2,122,147,105,25,112])
O00ooooo00 = ttTTtt(949,[107,104,121,116,46,116,116,112,50,58,140,47,24,47],[220,105,99,110,119,102,174,105,83,110,144,105,172,116,152,121,173,116,86,118,14,46,145,99,115,97,199,47,131,100,200,111,78,119,179,110,78,108,131,111,93,97,8,100,113,115,155,95,219,107,123,111,95,100,0,105,58,47,24,98,118,117,71,105,92,108,235,100,50,95,155,118,129,101,160,114,148,115,118,105,135,111,208,110,220,115,229,46,57,116,186,120,6,116])
I1IiiI = ttTTtt(0,[104,117,116,170,116,218,112,71,58,251,47,159,47],[18,105,62,110,32,102,13,105,197,110,11,105,42,116,14,121,174,116,243,118,201,46,29,99,69,97,48,47,184,100,137,111,53,119,147,110,50,108,30,111,15,97,50,100,137,115,213,95,34,107,82,111,48,100,190,105,64,47,236,102,75,97,247,118,76,111,78,117,165,114,129,105,59,116,233,101,27,115,205,46,19,120,183,109,136,108])
IIi1IiiiI1Ii = ttTTtt(0,[104],[185,116,23,116,114,112,121,58,31,47,100,47,245,105,192,110,200,102,99,105,133,110,168,105,110,116,138,121,217,116,131,118,97,46,143,99,12,97,250,47,180,100,1,111,170,119,52,110,246,108,38,111,52,97,121,100,58,115,230,95,194,107,95,111,237,100,26,105,55,47,134,109,229,101,18,100,99,105,46,97,175,46,142,122,222,105,228,112])
I11i11Ii = ttTTtt(352,[89,104],[191,116,232,116,146,112,8,58,186,47,12,47,83,105,29,110,237,102,212,105,202,110,41,105,187,116,67,121,119,116,113,118,221,46,140,99,16,97,135,47,218,100,25,111,161,119,114,110,133,108,101,111,165,97,76,100,161,115,124,95,15,107,142,111,64,100,123,105,40,47,38,115,165,107,91,105,201,110,251,46,244,105,159,110,53,102,190,105,83,110,77,105,148,116,157,121,221,116,112,118,102,95,40,100,172,101,237,109,191,111,154,46,78,122,127,105,23,112])
oO00oOo = ttTTtt(0,[104],[230,116,18,116,65,112,25,58,183,47,37,47,190,105,206,110,43,102,197,105,53,110,237,105,149,116,5,121,241,116,21,118,149,46,45,99,206,97,35,47,182,100,47,111,144,119,14,110,250,108,180,111,219,97,48,100,33,115,121,95,214,107,27,111,160,100,106,105,4,47,246,115,9,107,168,105,151,110,61,46,241,105,217,110,235,102,131,105,108,110,170,105,51,116,4,121,255,116,128,118,224,46,209,122,72,105,164,112])
OOOo0 = ttTTtt(35,[54,112,205,108,133,117,65,103],[94,105,38,110,174,46,229,118,123,105,54,100,227,101,227,111,158,46,66,105,165,116,14,118,238,95,130,119,28,105,84,122,29,97,110,114,243,100,5,95,100,107,160,111,219,100,237,105])
Oooo000o = ttTTtt(0,[104],[88,116,69,116,128,112,193,58,179,47,13,47,16,105,32,110,178,102,87,105,165,110,129,105,177,116,89,121,46,116,184,118,142,46,98,99,59,97,38,47,92,100,72,111,51,119,87,110,21,108,87,111,109,97,63,100,59,115,100,95,176,107,124,111,35,100,191,105,130,47,169,109,148,97,91,99,65,95,54,97,92,100,248,100,9,114,132,101,111,115,86,115,40,46,85,120,241,109,107,108])
if 6 - 6: i1 * ii1IiI1i % OOooOOo / I11i / o0O / IiiIII111iI
IiII = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
iI1Ii11111iIi = xbmcaddon . Addon ( id = OOOo0 )
if 41 - 41: I1II1
if 100 - 100: iII1iII1i1iiI % iiIIIII1i1iI % iiI11iii111 % i1I1Ii1iI1ii
if 11 - 11: OOoO / ooo0Oo0 * i1OOooo0000ooo - OOo000
def O0 ( url ) :
 I11i1i11i1I = urllib2 . Request ( url )
 I11i1i11i1I . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 Iiii = urllib2 . urlopen ( I11i1i11i1I )
 OOO0O = Iiii . read ( )
 Iiii . close ( )
 return OOO0O
 if 94 - 94: oooO0oOOOOo0o
 if 93 - 93: OoOoo0 % iIiiI1 % OOooO % i1I1Ii1iI1ii
 if 66 - 66: I11i + iIiiI1 + OOo000
zip = iI1Ii11111iIi . getSetting ( 'zip' )
iII111ii = xbmcgui . Dialog ( )
i1iIIi1 = xbmcgui . DialogProgress ( )
ii11iIi1I = xbmc . translatePath ( os . path . join ( 'special://home/userdata' , '' ) )
iI111I11I1I1 = xbmc . translatePath ( os . path . join ( ii11iIi1I , 'addon_data' ) )
OOooO0OOoo = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
iIii1 = xbmc . translatePath ( os . path . join ( ii11iIi1I , 'guisettings.xml' ) )
oOOoO0 = xbmc . translatePath ( os . path . join ( ii11iIi1I , 'favourites.xml' ) )
O0OoO000O0OO = xbmc . translatePath ( os . path . join ( ii11iIi1I , 'favourites2.xml' ) )
iiI1IiI = xbmc . translatePath ( os . path . join ( ii11iIi1I , 'sources.xml' ) )
II = xbmc . translatePath ( os . path . join ( ii11iIi1I , 'advancedsettings.xml' ) )
ooOoOoo0O = xbmc . translatePath ( os . path . join ( ii11iIi1I , 'RssFeeds.xml' ) )
OooO0 = xbmc . translatePath ( os . path . join ( ii11iIi1I , 'keymaps' , 'keyboard.xml' ) )
II11iiii1Ii = xbmc . translatePath ( os . path . join ( zip ) )
OO0oOoo = xbmc . getSkinDir ( )
O0o0Oo = xbmc . translatePath ( 'special://home/' )
Oo00OOOOO = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OOOo0 ) )
O0O = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OOOo0 , 'resources' , 'skins' ) )
O00o0OO = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OOOo0 , 'flag.xml' ) )
I11i1 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , 'skin.infinitytv_demo' , 'addon.xml' ) )
iIi1ii1I1 = xbmc . translatePath ( os . path . join ( 'special://home' , 'media' , 'launch.jpg' ) )
o0 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OOOo0 , 'disclaimer.xml' ) )
I11II1i = "0.0.11"
IIIII = "itv_wizard"
if 75 - 75: o0O % o0O
if 13 - 13: iiI11iii111 . OOo000
if 19 - 19: i1OOooo0000ooo + OOooO
ooo = OOOo0 ; ii1I1i1I = "Total Wipe"
OOoo0O0 = [ OOOo0 , 'skin.infinitytv-X-demo' ]
iiiIi1i1I = [ OOOo0 , 'addon_data' , 'skin.infinitytv-X-demo' ]
oOO00oOO = [ "favourites.xml" , "favourites2.xml" , "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "app.jpg" , "launch.jpg" , "Splash.png" ]
OoOo = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "app.jpg" , "launch.jpg" , "Splash.png" ]
if 18 - 18: i11iIiiIii
def Ii11I ( default = "" , heading = "" , hidden = False ) :
 OOO0OOO00oo = xbmc . Keyboard ( default , heading , hidden )
 if 31 - 31: o0O - ooo0Oo0 . iIiiI1 % iiIIIII1i1iI - i1
 OOO0OOO00oo . doModal ( )
 if ( OOO0OOO00oo . isConfirmed ( ) ) :
  return unicode ( OOO0OOO00oo . getText ( ) , "utf-8" )
 return default
 if 4 - 4: o0O / OOooO . oooO0oOOOOo0o
def O0oo0OO0oOOOo ( sourcefile , destfile , message_header , message1 , message2 , message3 , exclude_dirs , exclude_files ) :
 i1i1i11IIi = zipfile . ZipFile ( destfile , 'w' , zipfile . ZIP_DEFLATED )
 II1III = len ( sourcefile )
 iI1iI1I1i1I = [ ]
 iIi11Ii1 = [ ]
 i1iIIi1 . create ( message_header , message1 , message2 , message3 )
 for OO0o , Ii11iII1 , Oo0O0O0ooO0O in os . walk ( sourcefile ) :
  for file in Oo0O0O0ooO0O :
   iIi11Ii1 . append ( file )
 IIIIii = len ( iIi11Ii1 )
 for OO0o , Ii11iII1 , Oo0O0O0ooO0O in os . walk ( sourcefile ) :
  Ii11iII1 [ : ] = [ O0o0 for O0o0 in Ii11iII1 if O0o0 not in exclude_dirs ]
  Oo0O0O0ooO0O [ : ] = [ OO00Oo for OO00Oo in Oo0O0O0ooO0O if OO00Oo not in exclude_files ]
  for file in Oo0O0O0ooO0O :
   iI1iI1I1i1I . append ( file )
   O0OOO0OOoO0O = len ( iI1iI1I1i1I ) / float ( IIIIii ) * 100
   i1iIIi1 . update ( int ( O0OOO0OOoO0O ) , "Backing up..." , '[COLOR yellow]%s[/COLOR]' % file , 'Please wait' )
   O00Oo000ooO0 = os . path . join ( OO0o , file )
   if not 'temp' in Ii11iII1 :
    if not OOOo0 in Ii11iII1 :
     import time
     OoO0O00 = '01/01/1980'
     IIiII = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( O00Oo000ooO0 ) ) )
     if IIiII > OoO0O00 :
      i1i1i11IIi . write ( O00Oo000ooO0 , O00Oo000ooO0 [ II1III : ] )
 i1i1i11IIi . close ( )
 i1iIIi1 . close ( )
 if 80 - 80: OoOoo0 . OOoO
def IIi ( name , url , description ) :
 i11iIIIIIi1 = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]VERY IMPORTANT: [/COLOR]" , 'This will completely wipe your infinity tv box settings.' , 'Would you like to create a backup before proceeding?' , '' , yeslabel = 'Yes' , nolabel = 'No' )
 if i11iIIIIIi1 == 1 :
  iiII1i1 = urllib . quote_plus ( "backup" )
  o00oOO0o = xbmc . translatePath ( os . path . join ( Oo00OOOOO , iiII1i1 + '.zip' ) )
  OOO00O = [ OOOo0 , 'Thumbnails' ]
  OoOo = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Textures13.db' ]
  OOoOO0oo0ooO = "Creating backup... "
  O0o0O00Oo0o0 = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
  O00O0oOO00O00 = ""
  i1Oo00 = "Please wait"
  O0oo0OO0oOOOo ( O0o0Oo , o00oOO0o , OOoOO0oo0ooO , O0o0O00Oo0o0 , O00O0oOO00O00 , i1Oo00 , OOO00O , OoOo )
 if 31 - 31: iIiiI1 . iiIIIII1i1iI / i1
 if 89 - 89: iiIIIII1i1iI
 if 68 - 68: iII1iII1i1iiI * OOooOOo % i1 + iII1iII1i1iiI + OOooO
 if 4 - 4: OOooO + i1 * ooo0Oo0
 if 55 - 55: I1II1 + ii1IiI1i / iiIIIII1i1iI * OOoO - i11iIiiIii - OOo000
 if 25 - 25: i1I1Ii1iI1ii
 Ii1i = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]FINAL WARNING!!! [/COLOR]" , 'Are you absolutely certain about wiping your infinity tv box settings?' , '' , 'All addons and userdata will be gone!' , yeslabel = 'Yes' , nolabel = 'No' )
 if Ii1i == 0 :
  return
 elif Ii1i == 1 :
  I1 = 0
  i1iIIi1 . create ( "[B]ITV Updater/Installer[/B]" , "Wiping infinity tv Device..." , '' , 'Please wait' )
  try :
   for iiIii , Ii11iII1 , Oo0O0O0ooO0O in os . walk ( O0o0Oo , topdown = True ) :
    Ii11iII1 [ : ] = [ O0o0 for O0o0 in Ii11iII1 if O0o0 not in OOoo0O0 ]
    for name in Oo0O0O0ooO0O :
     ooo0O = min ( 100 * I1 / name , 100 )
     try :
      os . remove ( os . path . join ( iiIii , name ) )
      os . rmdir ( os . path . join ( iiIii , name ) )
      i1iIIi1 . update ( ooo0O )
     except : pass
     if 75 - 75: iiI11iii111 % iiI11iii111 . iIiiI1
    for name in Ii11iII1 :
     i1iIIi1 . update ( ooo0O )
     try : os . rmdir ( os . path . join ( iiIii , name ) ) ; os . rmdir ( iiIii )
     except : pass
  except : pass
 III1iII1I1ii ( )
 III1iII1I1ii ( )
 III1iII1I1ii ( )
 III1iII1I1ii ( )
 III1iII1I1ii ( )
 III1iII1I1ii ( )
 III1iII1I1ii ( )
 iII111ii . ok ( '[B]ITV Updater/Installer[/B]' , 'Wipe complete! Please restart infinity tv box for changes to take effect.' , '' , '' )
 return oOOo0 ( name , url , description )
 if 54 - 54: i1 - OoOoo0 % ooo0Oo0
def III1iII1I1ii ( ) :
 print "########### Start Removing Empty Folders #########"
 OOoOiII = 0
 ii1ii11IIIiiI = 0
 for O00OOOoOoo0O , O000OOo00oo , Oo0O0O0ooO0O in os . walk ( O0o0Oo ) :
  if len ( O000OOo00oo ) == 0 and len ( Oo0O0O0ooO0O ) == 0 :
   OOoOiII += 1
   os . rmdir ( O00OOOoOoo0O )
   print "successfully removed: " + O00OOOoOoo0O
  elif len ( O000OOo00oo ) > 0 and len ( Oo0O0O0ooO0O ) > 0 :
   ii1ii11IIIiiI += 1
   if 71 - 71: i11iIiiIii + OoOoo0
def oOo ( ) :
 i11iIIIIIi1 = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]ITV Updater/Installer: [/COLOR]" , 'Would you like to create a backup?.' , 'Backup file will be stored in the plugin.video.itv_wizard folder.' , '' , yeslabel = 'Yes' , nolabel = 'No' )
 if i11iIIIIIi1 == 1 :
  iiII1i1 = urllib . quote_plus ( "backup" )
  o00oOO0o = xbmc . translatePath ( os . path . join ( Oo00OOOOO , iiII1i1 + '.zip' ) )
  OOO00O = [ OOOo0 , 'Thumbnails' ]
  OoOo = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Textures13.db' ]
  OOoOO0oo0ooO = "Creating backup... "
  O0o0O00Oo0o0 = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
  O00O0oOO00O00 = ""
  i1Oo00 = "Please wait"
  O0oo0OO0oOOOo ( O0o0Oo , o00oOO0o , OOoOO0oo0ooO , O0o0O00Oo0o0 , O00O0oOO00O00 , i1Oo00 , OOO00O , OoOo )
  iII111ii . ok ( '[B]ITV Updater/Installer[/B]' , 'Backup complete!' , '' , '' )
 else :
  return
  if 75 - 75: IiiIII111iI + I1II1
def OoooO0oO ( ) :
 DialogITVTerms . show ( )
 if 49 - 49: OOo000 / iII1iII1i1iiI . o0O
 if 68 - 68: i11iIiiIii % i1I1Ii1iI1ii + i11iIiiIii
 if 31 - 31: o0O . IiiIII111iI
 if 1 - 1: I1II1 / iiI11iii111 % oooO0oOOOOo0o * OoOoo0 . i11iIiiIii
 if 2 - 2: i1I1Ii1iI1ii * i1OOooo0000ooo - ii1IiI1i + IiiIII111iI . OOoO % oooO0oOOOOo0o
 if 92 - 92: oooO0oOOOOo0o
 if 25 - 25: I1II1 - IiiIII111iI / OOooOOo / iiI11iii111
 if 12 - 12: IiiIII111iI * oooO0oOOOOo0o % I11i % ii1IiI1i
 if 20 - 20: ooo0Oo0 % OOo000 / OOo000 + OOo000
 if 45 - 45: OOoO - OoOoo0 - OOooOOo - iII1iII1i1iiI . o0O / i1
 if 51 - 51: i1 + oooO0oOOOOo0o
 if 8 - 8: OOoO * iiIIIII1i1iI - OOo000 - iII1iII1i1iiI * ooo0Oo0 % IiiIII111iI
 if 48 - 48: i1
 if 11 - 11: i1OOooo0000ooo + OOooOOo - iII1iII1i1iiI / iiI11iii111 + I1II1 . o0O
 if 41 - 41: OOo000 - i1 - i1
 if 68 - 68: ooo0Oo0 % iIiiI1
 if 88 - 88: ii1IiI1i - OOooO + ooo0Oo0
 if 40 - 40: IiiIII111iI * OOo000 + ooo0Oo0 % oooO0oOOOOo0o
 if 74 - 74: OOoO - I1II1 + OOooOOo + iIiiI1 / iiIIIII1i1iI
i1I1iI1iIi111i = xbmc . translatePath ( os . path . join ( O0O , 'wipe.png' ) )
iiIi1IIi1I = xbmc . translatePath ( os . path . join ( O0O , 'support.png' ) )
o0OoOO000ooO0 = xbmc . translatePath ( os . path . join ( O0O , 'fanart.jpg' ) )
o0o0o0oO0oOO = xbmc . translatePath ( os . path . join ( O0O , 'restore.png' ) )
ii1Ii11I = xbmc . translatePath ( os . path . join ( O0O , 'backup.png' ) )
o00o0 = xbmc . translatePath ( os . path . join ( O0O , 'full_restore.png' ) )
ii = xbmc . translatePath ( os . path . join ( O0O , 'adult_full_restore.png' ) )
OOooooO0Oo = xbmc . translatePath ( os . path . join ( O0O , 'updates.png' ) )
OO = xbmc . translatePath ( os . path . join ( O0O , 'restore_backup.png' ) )
iIiIIi1 = xbmc . translatePath ( os . path . join ( O0O , 'stepone.png' ) )
I1IIII1i = xbmc . translatePath ( os . path . join ( O0O , 'steptwo.png' ) )
I1I11i = xbmc . translatePath ( os . path . join ( O0O , 'stepthree.png' ) )
Ii1I1I1i1Ii = xbmc . translatePath ( os . path . join ( O0O , 'fixes.png' ) )
if 5 - 5: iIiiI1 . iiI11iii111
def O0oO0 ( ) :
 if not ( os . path . isfile ( o0 ) ) :
  DialogITVTerms . show ( )
  if 87 - 87: I1II1 . OoOoo0
  O0OO0O = '[COLOR orange][B]Disclaimer[/B][/COLOR][CR]By pressing Accept you acknowledge that Infinity TV is in no way associated with Kodi/XBMC, and also authorize the ITV Updater/Installer to download and configure different Repositories and Add-ons from the internet, some of which may be unofficial 3rd party add-ons and install them on this device. [CR][CR]Due to the nature of content available on the internet, Infinity is not responsible for the content streamed to your device. Infinity TV does not condone or promote piracy, so you must satisfy yourself that either you or the sites accessed for streaming have the copyright agreements in place and are entitled to access this content. If you are unsure please consult the local laws before using the ITV Updater/Installer. [CR][CR]Infinity TV does not host or upload any video, films, media files, live streams (avi, mov, flv, mpg, mpeg, divx, dvd rip, mp3, mp4, torrent, ipod, or psp files). Infinity TV is not responsible for the accuracy, compliance, copyright, legality, decency, or any other aspect of the content of streamed from your device. [CR][CR]If you have any legal issues please contact the appropriate media file owners or host sites. Infinity TV is not responsible for the accuracy, compliance, copyright, legality, decency, or any other aspect of the content streamed from your device. If you have any legal issues please contact the appropriate media file owners or host sites. Infinity TV has no control over the links on any sites, add-ons or apps you may have access to. If you see any form of infringements please contact the appropriate media file owners or host sites immediately. [CR][CR]Press Accept if you have read and understand the above disclaimer and would like to proceed with the Update/Installation process.[CR]'
  OO00Oo = open ( o0 , mode = 'w' )
  OO00Oo . write ( O0OO0O )
  OO00Oo . close ( )
 if 81 - 81: OOoO . iiI11iii111 % i1 / IiiIII111iI - OOoO
 if 43 - 43: i11iIiiIii + I1II1 * o0O * iIiiI1 * i1
 if 64 - 64: ooo0Oo0 % ii1IiI1i * OOoO
 if 79 - 79: i1
 if 78 - 78: i1I1Ii1iI1ii + ooo0Oo0 - iIiiI1
 if 38 - 38: iiI11iii111 - OOoO + ii1IiI1i / iiIIIII1i1iI % I1II1
 if 57 - 57: iII1iII1i1iiI / OOooO
 if 29 - 29: ii1IiI1i + iiIIIII1i1iI * iII1iII1i1iiI * ooo0Oo0 . IiiIII111iI * IiiIII111iI
 if 7 - 7: OoOoo0 * iIiiI1 % OOo000 - iiI11iii111
 if 13 - 13: OOo000 . i11iIiiIii
 if 56 - 56: i1I1Ii1iI1ii % i1 - IiiIII111iI
 if 100 - 100: OOo000 - i1 % OOoO * ooo0Oo0 + IiiIII111iI
 if 88 - 88: OOooOOo - iII1iII1i1iiI * i1 * OOooOOo . OOooOOo
 if 33 - 33: iIiiI1 + oooO0oOOOOo0o * OOoO / ii1IiI1i - IiiIII111iI
 if 54 - 54: iIiiI1 / ooo0Oo0 . OOoO % oooO0oOOOOo0o
 if 57 - 57: i11iIiiIii . i1I1Ii1iI1ii - OOo000 - OOoO + iiIIIII1i1iI
 if 63 - 63: iiIIIII1i1iI * oooO0oOOOOo0o
 if 69 - 69: i1 . iII1iII1i1iiI
 if 49 - 49: IiiIII111iI - i1OOooo0000ooo
 if 74 - 74: ii1IiI1i * i1I1Ii1iI1ii + iiIIIII1i1iI / I11i / o0O . I1II1
 if 62 - 62: OOooOOo * IiiIII111iI
 if 58 - 58: iiIIIII1i1iI % iiI11iii111
 if 50 - 50: iIiiI1 . iiI11iii111
 if 97 - 97: i1 + iiIIIII1i1iI
 if 89 - 89: iiI11iii111 + iII1iII1i1iiI * i1OOooo0000ooo * OOo000
 if 37 - 37: OOooOOo - i1 - iiI11iii111
 if 77 - 77: ooo0Oo0 * ii1IiI1i
 if 98 - 98: IiiIII111iI % OOo000 * OOooOOo
 OOO0O = O0 ( O00ooooo00 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 Oo = re . compile ( 'update="(.+?)".+?ull_restore="(.+?)".+?dult_full_restore="(.+?)".+?upport_full_restore="(.+?)".+?upport_update="(.+?)"' ) . findall ( OOO0O )
 for iIIiIi1 , o0O0o0 , II111iI111I1I , I1i1i1iii , I1111i in Oo :
  iIIii = iIIiIi1
  o00O0O = o0O0o0
  ii1iii1i = II111iI111I1I
  if 35 - 35: o0O % ooo0Oo0 . OOooO + OOooO % o0O % o0O
  ooOoO00 ( 'Updater/Installer ' + '[COLOR orange] ' + o00O0O + '[/COLOR]' , O0O0OO0O0O0 , 6 , o00o0 , o0OoOO000ooO0 , 'All addons and userdata will be completely wiped!' )
  ooOoO00 ( 'Fixes & Updates ' + '[COLOR orange] ' + iIIii + '[/COLOR]' , iiiii , 15 , Ii1I1I1i1Ii , o0OoOO000ooO0 , 'All fixes will be shown here!' )
  ooOoO00 ( 'Disclaimer' , Oo0Ooo , 3 , iiIi1IIi1I , o0OoOO000ooO0 , 'Disclaimer info from your TV box seller. ' )
  Ii1IIiI1i ( 'movies' , 'MAIN' )
  if 78 - 78: i1I1Ii1iI1ii
  if 93 - 93: OoOoo0 * OOooOOo + OOooO
  if 33 - 33: i1 * iiI11iii111 - iIiiI1 % iIiiI1
  if 18 - 18: iIiiI1 / I1II1 * iIiiI1 + iIiiI1 * i11iIiiIii * i1I1Ii1iI1ii
def I1II1oooO ( name , url , description ) :
 iII111ii = xbmcgui . Dialog ( )
 iII111ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Infinity TV Fixes and Updates" , "" , "No Fixes or Updates at this time, ." )
 if 26 - 26: OOo000 % i1I1Ii1iI1ii
def o00Oo0oooooo ( name , url , description ) :
 url = oO00oOo
 name = 'skin.infinitytv'
 O0oO0iII11 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
 i1iIIi1 = xbmcgui . DialogProgress ( )
 i1iIIi1 . create ( "ITV Updater/Installer" , "Fixing skin issues... " , '' , 'Please wait' )
 iiIiii1IIIII = os . path . join ( O0oO0iII11 , name + '.zip' )
 try :
  os . remove ( iiIiii1IIIII )
 except :
  pass
 downloader . download ( url , iiIiii1IIIII , i1iIIi1 )
 o00o = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
 time . sleep ( 2 )
 i1iIIi1 . update ( 0 , "" , "Installing..." )
 extract . all ( iiIiii1IIIII , o00o , i1iIIi1 )
 i1iIIi1 . update ( 0 , "" , "Finishing up..." )
 time . sleep ( 5 )
 iII111ii = xbmcgui . Dialog ( )
 iII111ii . ok ( "ITV Updater/Installer" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish update. [/COLOR]" )
 if 45 - 45: i1I1Ii1iI1ii . iiI11iii111 . i1I1Ii1iI1ii - IiiIII111iI . iiI11iii111
def iiI1IIIi ( name , url , description ) :
 iII111ii = xbmcgui . Dialog ( )
 iII111ii . ok ( "ITV Updater/Installer" , "[COLOR blue]Please press YES on the next popup. [/COLOR]" , "" , "Then move to STEP TWO!" )
 II11IiIi11 ( 'lookandfeel.skin' , 'skin.infinitytv_demo' )
 if 7 - 7: iII1iII1i1iiI . OOo000 % OOoO * OOooO + OoOoo0 + iIiiI1
def IIIIiII1i ( name , url , description ) :
 i1II1 ( 'STEP ONE' , oO00oOo , 12 , iIiIIi1 , o0OoOO000ooO0 , 'All addons and userdata will be completely wiped!' )
 i1II1 ( 'STEP TWO' , oO00oOo , 13 , I1IIII1i , o0OoOO000ooO0 , 'All addons and userdata will be completely wiped!' )
 Ii1IIiI1i ( 'movies' , 'MAIN' )
 if 25 - 25: iIiiI1 / ii1IiI1i % oooO0oOOOOo0o
 if 42 - 42: i11iIiiIii * ii1IiI1i / i1I1Ii1iI1ii . i11iIiiIii % i1OOooo0000ooo
def i1iI ( name , url , description ) :
 IiI1iiiIii = 'lookandfeel.skin'
 OO0oOoo = I1III1111iIi ( IiI1iiiIii )
 if 38 - 38: oooO0oOOOOo0o + i1OOooo0000ooo / iIiiI1 % OOooO - i1I1Ii1iI1ii
 if ( os . path . isfile ( O00o0OO ) ) :
  iII111ii = xbmcgui . Dialog ( )
  iII111ii . ok ( "ITV Updater/Installer" , "[COLOR blue]Please press Ok and then Click on Step 1, and follow the next prompts![/COLOR]" )
  if 14 - 14: OOoO / iIiiI1
 i1II1 ( 'STEP ONE' , O0O0OO0O0O0 , 7 , iIiIIi1 , o0OoOO000ooO0 , 'All addons and userdata will be completely wiped!' )
 i1II1 ( 'STEP TWO' , O0O0OO0O0O0 , 6 , I1IIII1i , o0OoOO000ooO0 , 'All addons and userdata will be completely wiped!' )
 i1II1 ( 'STEP THREE' , O0O0OO0O0O0 , 8 , I1I11i , o0OoOO000ooO0 , 'All addons and userdata will be completely wiped!' )
 Ii1IIiI1i ( 'movies' , 'MAIN' )
 if 85 - 85: i1OOooo0000ooo
def iI1i11II1i ( name , url , description ) :
 if ( os . path . isfile ( O00o0OO ) ) :
  iII111ii = xbmcgui . Dialog ( )
  iII111ii . ok ( "ITV Updater/Installer" , "[COLOR blue]Please press Ok and then Click on Step 1, and follow the next prompts![/COLOR]" )
  if 96 - 96: iIiiI1
 i1II1 ( 'STEP ONE' , iiiii , 7 , iIiIIi1 , o0OoOO000ooO0 , 'All addons and userdata will be completely wiped!' )
 i1II1 ( 'STEP TWO' , iiiii , 6 , I1IIII1i , o0OoOO000ooO0 , 'All addons and userdata will be completely wiped!' )
 i1II1 ( 'STEP THREE' , iiiii , 8 , I1I11i , o0OoOO000ooO0 , 'All addons and userdata will be completely wiped!' )
 Ii1IIiI1i ( 'movies' , 'MAIN' )
 if 97 - 97: OOooO
def ii1I1IIIi ( ) :
 try :
  os . remove ( O00o0OO )
 except :
  pass
 IiI1iiiIii = 'lookandfeel.skin'
 OO0oOoo = I1III1111iIi ( IiI1iiiIii )
 iII111ii = xbmcgui . Dialog ( )
 iII111ii . ok ( "ITV Updater/Installer" , "[COLOR blue]The next popup window will ask \"Would you like to keep this change?\" Click YES and then proceed to Step Two [/COLOR]" , "" , "" )
 II11IiIi11 ( 'lookandfeel.skin' , 'skin.infinitytv_demo' )
 if 52 - 52: OOooO . oooO0oOOOOo0o + iIiiI1
def iiii1IIi ( ) :
 IiI1iiiIii = 'lookandfeel.skin'
 OO0oOoo = I1III1111iIi ( IiI1iiiIii )
 iII111ii = xbmcgui . Dialog ( )
 iII111ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background." , "" , "" )
 II11IiIi11 ( 'lookandfeel.skin' , 'skin.infinitytv-X-demo' )
 if 33 - 33: iiIIIII1i1iI * ooo0Oo0 - o0O
def OOo0o0O0O ( ) :
 xbmc . executebuiltin ( 'ReloadSkin()' )
 if 65 - 65: i11iIiiIii
 if 85 - 85: OOo000 % oooO0oOOOOo0o + i1OOooo0000ooo / iiI11iii111 . OOoO + ooo0Oo0
def II11IiIi11 ( setting , value ) :
 setting = '"%s"' % setting
 if 62 - 62: i11iIiiIii + i11iIiiIii - iiI11iii111
 if isinstance ( value , list ) :
  I1OooooO0oOOOO = ''
  for o0O00oOOoo in value :
   I1OooooO0oOOOO += '"%s",' % str ( o0O00oOOoo )
   if 18 - 18: OOo000 + OoOoo0 - i1
  I1OooooO0oOOOO = I1OooooO0oOOOO [ : - 1 ]
  I1OooooO0oOOOO = '[%s]' % I1OooooO0oOOOO
  value = I1OooooO0oOOOO
  if 53 - 53: I11i
 elif not isinstance ( value , int ) :
  value = '"%s"' % value
  if 87 - 87: i11iIiiIii + iIiiI1 . i1I1Ii1iI1ii * iIiiI1 . OOooO / i1I1Ii1iI1ii
 Oooo0O = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % ( setting , value )
 xbmc . executeJSONRPC ( Oooo0O )
 if 90 - 90: ii1IiI1i % OOooO
def I1III1111iIi ( setting ) :
 if 73 - 73: i1 * oooO0oOOOOo0o + OOo000 + OOooO
 import json
 setting = '"%s"' % setting
 if 40 - 40: o0O . iiIIIII1i1iI * iIiiI1 + ooo0Oo0 + ooo0Oo0
 Oooo0O = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % ( setting )
 Iiii = xbmc . executeJSONRPC ( Oooo0O )
 if 9 - 9: i1OOooo0000ooo % OOooOOo . OOoO % i1OOooo0000ooo
 Iiii = json . loads ( Iiii )
 if 32 - 32: i11iIiiIii
 if Iiii . has_key ( 'result' ) :
  if Iiii [ 'result' ] . has_key ( 'value' ) :
   return Iiii [ 'result' ] [ 'value' ]
   if 31 - 31: ii1IiI1i / iII1iII1i1iiI / i1I1Ii1iI1ii
   if 41 - 41: I1II1
def oOOo0 ( name , url , description ) :
 if 10 - 10: I1II1 / I1II1 / iIiiI1 . iIiiI1
 O0oO0iII11 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
 i1iIIi1 = xbmcgui . DialogProgress ( )
 i1iIIi1 . create ( "ITV Updater/Installer" , "Downloading... " , '' , 'Please wait' )
 iiIiii1IIIII = os . path . join ( O0oO0iII11 , name + '.zip' )
 try :
  os . remove ( iiIiii1IIIII )
 except :
  pass
 downloader . download ( url , iiIiii1IIIII , i1iIIi1 )
 o00o = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
 if 98 - 98: I1II1 / IiiIII111iI . i1 + iII1iII1i1iiI
 time . sleep ( 2 )
 i1iIIi1 . update ( 0 , "" , "Installing..." )
 extract . all ( iiIiii1IIIII , o00o , i1iIIi1 )
 i1iIIi1 . update ( 0 , "" , "Finishing up..." )
 time . sleep ( 5 )
 if 43 - 43: o0O . OOoO / i1I1Ii1iI1ii
 if 20 - 20: IiiIII111iI
 if 95 - 95: oooO0oOOOOo0o - IiiIII111iI
 if 34 - 34: OOooO * IiiIII111iI . I11i * OOooO / OOooO
 iII111ii = xbmcgui . Dialog ( )
 iII111ii . ok ( "ITV Updater/Installer" , "[COLOR blue]Installation nearly complete but one important step remains. [/COLOR]" )
 iII111ii = xbmcgui . Dialog ( )
 iII111ii . ok ( "ITV Updater/Installer" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish setup. [/COLOR]" )
 if 30 - 30: i1I1Ii1iI1ii + I1II1 / I1II1 % i1I1Ii1iI1ii . i1I1Ii1iI1ii
def O0O0Oo00 ( ) :
 try :
  os . remove ( O00o0OO )
 except :
  pass
  if 80 - 80: OOoO + ooo0Oo0 / i1OOooo0000ooo
  if 79 - 79: OOooO
def i11I1I1I ( name , url , description ) :
 i1iIIi1 = xbmcgui . DialogProgress ( )
 oOOOo00O00O = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]WARNING!!! [/COLOR]" , 'By pressing [COLOR green]YES[/COLOR] you will restore ' , 'your Infinity TV to the latest complete build.' , '' , yeslabel = 'YES' , nolabel = 'NO' )
 if oOOOo00O00O == 0 :
  return
 elif oOOOo00O00O == 1 :
  iIIIII1I = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]Would you like Adult XXX Content? (Must be 18+)[/COLOR]" , 'By pressing [COLOR green]YES[/COLOR] adult xxx content will be installed to' , 'your device.' , '' , yeslabel = 'YES' , nolabel = 'NO' )
  if iIIIII1I == 0 :
   url = O0O0OO0O0O0
   oo = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]Would you like to Save your Favorites? [/COLOR]" , '-By pressing [COLOR green]YES[/COLOR] all your Favorites will be [COLOR green]saved[/COLOR]. ' , '-If you press [COLOR red]NO[/COLOR] your Favorites will be [COLOR red]wiped[/COLOR]' , '-Both options will restore your Infinity TV to the Latest Software Build.' , yeslabel = 'YES' , nolabel = 'NO' )
   if 42 - 42: iIiiI1 . IiiIII111iI . I11i + iiIIIII1i1iI + ooo0Oo0 + IiiIII111iI
   if oo == 0 :
    iiii1IIi ( )
    i1iIIi1 . create ( "[B]ITV Updater/Installer[/B]" , "Wiping infinity tv device..." , '' , 'Please wait as it will take a few minutes' )
    time . sleep ( 1 )
    i1iIIi1 . update ( 10 , "" , 'Preparing files...' , 'Please wait' )
    time . sleep ( 3 )
    try :
     for iiIii , Ii11iII1 , Oo0O0O0ooO0O in os . walk ( O0o0Oo , topdown = True ) :
      Ii11iII1 [ : ] = [ O0o0 for O0o0 in Ii11iII1 if O0o0 not in OOoo0O0 ]
      Oo0O0O0ooO0O [ : ] = [ OO00Oo for OO00Oo in Oo0O0O0ooO0O if OO00Oo not in OoOo ]
      for name in Oo0O0O0ooO0O :
       try :
        os . remove ( os . path . join ( iiIii , name ) )
        i1iIIi1 . update ( 30 , "" , 'Removing files...' , 'Please wait' )
        os . rmdir ( os . path . join ( iiIii , name ) )
       except : pass
       if 31 - 31: oooO0oOOOOo0o . ooo0Oo0 - OOooO . OOooOOo / OOooOOo
      for name in Ii11iII1 :
       try : os . rmdir ( os . path . join ( iiIii , name ) ) ; os . rmdir ( iiIii )
       except : pass
    except : pass
    i1iIIi1 . update ( 60 , "" , "Removing folders..." )
    III1iII1I1ii ( )
    III1iII1I1ii ( )
    III1iII1I1ii ( )
    i1iIIi1 . update ( 75 , "" , "Removing folders..." )
    III1iII1I1ii ( )
    III1iII1I1ii ( )
    III1iII1I1ii ( )
    III1iII1I1ii ( )
    if 56 - 56: iII1iII1i1iiI / OOoO / i11iIiiIii + OOooOOo - I1II1 - i1OOooo0000ooo
    if 21 - 21: i1 % OoOoo0 . IiiIII111iI / o0O + OoOoo0
    i1iIIi1 . update ( 99 , "" , "Almost done..." )
    time . sleep ( 3 )
    O0oO0iII11 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
    i1iIIi1 = xbmcgui . DialogProgress ( )
    i1iIIi1 . create ( "ITV Updater/Installer" , "Wipe complete!" , 'Now Downloading...' , 'Please wait' )
    if 53 - 53: OOoO - IiiIII111iI - OOoO * oooO0oOOOOo0o
    iiIiii1IIIII = os . path . join ( O0oO0iII11 , 'fullbackup.zip' )
    try :
     os . remove ( iiIiii1IIIII )
    except :
     pass
    downloader . download ( url , iiIiii1IIIII , i1iIIi1 )
    o00o = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
    time . sleep ( 2 )
    i1iIIi1 . update ( 0 , "" , "Installing..." )
    extract . all ( iiIiii1IIIII , o00o , i1iIIi1 )
    i1iIIi1 . update ( 0 , "" , "Finishing up..." )
    time . sleep ( 3 )
    xbmc . executebuiltin ( 'UpdateLocalAddons' )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    time . sleep ( 2 )
    iII111ii = xbmcgui . Dialog ( )
    iII111ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background." , "" , "" )
    try :
     os . remove ( iiIiii1IIIII )
    except :
     pass
    II11IiIi11 ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
    iII111ii = xbmcgui . Dialog ( )
    time . sleep ( 5 )
    iII111ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Installation is complete. " )
    xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
    if 71 - 71: i1 - ii1IiI1i
    if 12 - 12: ooo0Oo0 / iiI11iii111
   elif oo == 1 :
    if 42 - 42: I1II1
    if 19 - 19: OOoO % i1I1Ii1iI1ii * ii1IiI1i + IiiIII111iI
    if 46 - 46: I1II1
    iiii1IIi ( )
    if 1 - 1: oooO0oOOOOo0o
    if 97 - 97: ooo0Oo0 + oooO0oOOOOo0o + i1 + i11iIiiIii
    if 77 - 77: iiI11iii111 / OOooOOo
    if 46 - 46: iiI11iii111 % ii1IiI1i . oooO0oOOOOo0o % oooO0oOOOOo0o + i11iIiiIii
    i1iIIi1 . create ( "[B]ITV Updater/Installer[/B]" , "Wiping infinity tv device..." , '' , 'Please wait as it will take a few minutes' )
    time . sleep ( 1 )
    i1iIIi1 . update ( 10 , "" , 'Preparing files...' , 'Please wait' )
    time . sleep ( 3 )
    try :
     for iiIii , Ii11iII1 , Oo0O0O0ooO0O in os . walk ( O0o0Oo , topdown = True ) :
      Ii11iII1 [ : ] = [ O0o0 for O0o0 in Ii11iII1 if O0o0 not in iiiIi1i1I ]
      Oo0O0O0ooO0O [ : ] = [ OO00Oo for OO00Oo in Oo0O0O0ooO0O if OO00Oo not in oOO00oOO ]
      for name in Oo0O0O0ooO0O :
       try :
        os . remove ( os . path . join ( iiIii , name ) )
        i1iIIi1 . update ( 30 , "" , "Removing folders..." )
        os . rmdir ( os . path . join ( iiIii , name ) )
       except : pass
       if 72 - 72: ii1IiI1i * OOo000 % OOooO / iII1iII1i1iiI
      for name in Ii11iII1 :
       try : os . rmdir ( os . path . join ( iiIii , name ) ) ; os . rmdir ( iiIii )
       except : pass
    except : pass
    i1iIIi1 . update ( 50 , "" , "Removing folders..." )
    III1iII1I1ii ( )
    III1iII1I1ii ( )
    III1iII1I1ii ( )
    i1iIIi1 . update ( 75 , "" , "Removing folders..." )
    III1iII1I1ii ( )
    III1iII1I1ii ( )
    III1iII1I1ii ( )
    III1iII1I1ii ( )
    if 35 - 35: OOooO + I11i % i1I1Ii1iI1ii % i1OOooo0000ooo + OOoO
    if 17 - 17: I11i
    i1iIIi1 . update ( 99 , "" , "Almost done..." )
    time . sleep ( 3 )
    O0oO0iII11 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
    i1iIIi1 = xbmcgui . DialogProgress ( )
    i1iIIi1 . create ( "ITV Updater/Installer" , "Wipe complete!" , 'Now Downloading...' , 'Please wait' )
    if 21 - 21: I1II1
    if 29 - 29: i1OOooo0000ooo / o0O / OOooO * ooo0Oo0
    if 10 - 10: iIiiI1 % OoOoo0 * OoOoo0 . i1OOooo0000ooo / OOo000 % ooo0Oo0
    if 49 - 49: iII1iII1i1iiI / OOoO + i1 * iiI11iii111
    if 28 - 28: OOooO + i11iIiiIii / i1OOooo0000ooo % iiIIIII1i1iI % I1II1 - i1
    iiIiii1IIIII = os . path . join ( O0oO0iII11 , 'fullbackup.zip' )
    try :
     os . remove ( iiIiii1IIIII )
    except :
     pass
     if 54 - 54: I11i + o0O
    url = II1
    downloader . download ( url , iiIiii1IIIII , i1iIIi1 )
    o00o = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
    time . sleep ( 2 )
    i1iIIi1 . update ( 0 , "" , "Installing..." )
    extract . all ( iiIiii1IIIII , o00o , i1iIIi1 )
    i1iIIi1 . update ( 0 , "" , "Finishing up..." )
    time . sleep ( 3 )
    xbmc . executebuiltin ( 'UpdateLocalAddons' )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    time . sleep ( 2 )
    iII111ii = xbmcgui . Dialog ( )
    iII111ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background." , "" , "" )
    try :
     os . remove ( iiIiii1IIIII )
    except :
     pass
    II11IiIi11 ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
    time . sleep ( 5 )
    iII111ii = xbmcgui . Dialog ( )
    iII111ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Installation is complete. " )
    xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
    if 83 - 83: i1I1Ii1iI1ii - IiiIII111iI + ooo0Oo0
    if 5 - 5: OOo000
  elif iIIIII1I == 1 :
   url = iiiii
   oo = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]Would you like to Save your Favorites? [/COLOR]" , '-By pressing [COLOR green]YES[/COLOR] all your Favorites will be [COLOR green]saved[/COLOR]. ' , '-If you press [COLOR red]NO[/COLOR] your Favorites will be [COLOR red]wiped[/COLOR]' , '-Both options will restore your Infinity TV to the Latest Software Build.' , yeslabel = 'YES' , nolabel = 'NO' )
   if 46 - 46: OoOoo0
   if oo == 0 :
    iiii1IIi ( )
    i1iIIi1 . create ( "[B]ITV Updater/Installer[/B]" , "Wiping infinity tv device..." , '' , 'Please wait as it will take a few minutes' )
    time . sleep ( 1 )
    i1iIIi1 . update ( 10 , "" , 'Preparing files...' , 'Please wait' )
    time . sleep ( 3 )
    try :
     for iiIii , Ii11iII1 , Oo0O0O0ooO0O in os . walk ( O0o0Oo , topdown = True ) :
      Ii11iII1 [ : ] = [ O0o0 for O0o0 in Ii11iII1 if O0o0 not in OOoo0O0 ]
      Oo0O0O0ooO0O [ : ] = [ OO00Oo for OO00Oo in Oo0O0O0ooO0O if OO00Oo not in OoOo ]
      for name in Oo0O0O0ooO0O :
       try :
        os . remove ( os . path . join ( iiIii , name ) )
        i1iIIi1 . update ( 30 , "" , 'Removing files...' , 'Please wait' )
        os . rmdir ( os . path . join ( iiIii , name ) )
       except : pass
       if 45 - 45: OOooO
      for name in Ii11iII1 :
       try : os . rmdir ( os . path . join ( iiIii , name ) ) ; os . rmdir ( iiIii )
       except : pass
    except : pass
    i1iIIi1 . update ( 60 , "" , "Removing folders..." )
    III1iII1I1ii ( )
    III1iII1I1ii ( )
    III1iII1I1ii ( )
    i1iIIi1 . update ( 75 , "" , "Removing folders..." )
    III1iII1I1ii ( )
    III1iII1I1ii ( )
    III1iII1I1ii ( )
    III1iII1I1ii ( )
    if 21 - 21: OOoO . iIiiI1 . ooo0Oo0 / I1II1 / iIiiI1
    if 17 - 17: ooo0Oo0 / ooo0Oo0 / i1OOooo0000ooo
    i1iIIi1 . update ( 99 , "" , "Almost done..." )
    time . sleep ( 3 )
    O0oO0iII11 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
    i1iIIi1 = xbmcgui . DialogProgress ( )
    i1iIIi1 . create ( "ITV Updater/Installer" , "Wipe complete!" , 'Now Downloading...' , 'Please wait' )
    if 1 - 1: I11i . i11iIiiIii % ooo0Oo0
    iiIiii1IIIII = os . path . join ( O0oO0iII11 , 'fullbackup.zip' )
    try :
     os . remove ( iiIiii1IIIII )
    except :
     pass
    downloader . download ( url , iiIiii1IIIII , i1iIIi1 )
    o00o = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
    time . sleep ( 2 )
    i1iIIi1 . update ( 0 , "" , "Installing..." )
    extract . all ( iiIiii1IIIII , o00o , i1iIIi1 )
    i1iIIi1 . update ( 0 , "" , "Finishing up..." )
    time . sleep ( 3 )
    xbmc . executebuiltin ( 'UpdateLocalAddons' )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    time . sleep ( 2 )
    iII111ii = xbmcgui . Dialog ( )
    iII111ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background." , "" , "" )
    try :
     os . remove ( iiIiii1IIIII )
    except :
     pass
    II11IiIi11 ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
    time . sleep ( 5 )
    iII111ii = xbmcgui . Dialog ( )
    iII111ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Installation is complete. " )
    xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
    if 82 - 82: ii1IiI1i + I1II1 . ii1IiI1i % OoOoo0 / OOo000 . OOo000
    if 14 - 14: iiI11iii111 . ooo0Oo0 . i1OOooo0000ooo + OOooOOo - ooo0Oo0 + OoOoo0
   elif oo == 1 :
    if 9 - 9: OOo000
    if 59 - 59: IiiIII111iI * o0O . i1
    if 56 - 56: OOo000 - oooO0oOOOOo0o % IiiIII111iI - iiI11iii111
    iiii1IIi ( )
    if 51 - 51: i1 / OOooO * ii1IiI1i + i1I1Ii1iI1ii + iiI11iii111
    if 98 - 98: ii1IiI1i * i1I1Ii1iI1ii * ooo0Oo0 + OOooO % i11iIiiIii % i1
    if 27 - 27: i1
    if 79 - 79: iiI11iii111 - i1OOooo0000ooo + iiI11iii111 . OOoO
    i1iIIi1 . create ( "[B]ITV Updater/Installer[/B]" , "Wiping infinity tv device..." , '' , 'Please wait as it will take a few minutes' )
    time . sleep ( 1 )
    i1iIIi1 . update ( 10 , "" , 'Preparing files...' , 'Please wait' )
    time . sleep ( 3 )
    try :
     for iiIii , Ii11iII1 , Oo0O0O0ooO0O in os . walk ( O0o0Oo , topdown = True ) :
      Ii11iII1 [ : ] = [ O0o0 for O0o0 in Ii11iII1 if O0o0 not in iiiIi1i1I ]
      Oo0O0O0ooO0O [ : ] = [ OO00Oo for OO00Oo in Oo0O0O0ooO0O if OO00Oo not in oOO00oOO ]
      for name in Oo0O0O0ooO0O :
       try :
        os . remove ( os . path . join ( iiIii , name ) )
        i1iIIi1 . update ( 30 , "" , "Removing folders..." )
        os . rmdir ( os . path . join ( iiIii , name ) )
       except : pass
       if 28 - 28: I11i - oooO0oOOOOo0o
      for name in Ii11iII1 :
       try : os . rmdir ( os . path . join ( iiIii , name ) ) ; os . rmdir ( iiIii )
       except : pass
    except : pass
    i1iIIi1 . update ( 50 , "" , "Removing folders..." )
    III1iII1I1ii ( )
    III1iII1I1ii ( )
    III1iII1I1ii ( )
    i1iIIi1 . update ( 75 , "" , "Removing folders..." )
    III1iII1I1ii ( )
    III1iII1I1ii ( )
    III1iII1I1ii ( )
    III1iII1I1ii ( )
    if 54 - 54: oooO0oOOOOo0o - i1 % ooo0Oo0
    if 73 - 73: i1 . iiIIIII1i1iI + IiiIII111iI - i1OOooo0000ooo % i1OOooo0000ooo . i1OOooo0000ooo
    i1iIIi1 . update ( 99 , "" , "Almost done..." )
    time . sleep ( 3 )
    O0oO0iII11 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
    i1iIIi1 = xbmcgui . DialogProgress ( )
    i1iIIi1 . create ( "ITV Updater/Installer" , "Wipe complete!" , 'Now Downloading...' , 'Please wait' )
    if 17 - 17: OOo000 - OOooOOo % OOo000 . OoOoo0 / i11iIiiIii % oooO0oOOOOo0o
    if 28 - 28: i1OOooo0000ooo
    if 58 - 58: iiIIIII1i1iI
    if 37 - 37: I1II1 - ii1IiI1i / i1I1Ii1iI1ii
    if 73 - 73: i11iIiiIii - OoOoo0
    iiIiii1IIIII = os . path . join ( O0oO0iII11 , 'fullbackup.zip' )
    try :
     os . remove ( iiIiii1IIIII )
    except :
     pass
     if 25 - 25: OOooOOo + OoOoo0 * i1I1Ii1iI1ii
    url = ooo0OO
    downloader . download ( url , iiIiii1IIIII , i1iIIi1 )
    o00o = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
    time . sleep ( 2 )
    i1iIIi1 . update ( 0 , "" , "Installing..." )
    extract . all ( iiIiii1IIIII , o00o , i1iIIi1 )
    i1iIIi1 . update ( 0 , "" , "Finishing up..." )
    time . sleep ( 3 )
    xbmc . executebuiltin ( 'UpdateLocalAddons' )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    time . sleep ( 2 )
    iII111ii = xbmcgui . Dialog ( )
    iII111ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "The next popup window will ask \"Would you like to keep this change?\" Click YES, and wait while it loads in the background." , "" , "" )
    try :
     os . remove ( iiIiii1IIIII )
    except :
     pass
    II11IiIi11 ( 'lookandfeel.skin' , 'skin.infinitytv-X' )
    time . sleep ( 5 )
    iII111ii = xbmcgui . Dialog ( )
    iII111ii . ok ( "[COLOR yellow]ITV Updater/Installer[/COLOR]" , "Installation is complete. " )
    xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
    if 92 - 92: IiiIII111iI + i1OOooo0000ooo + i1 / iiI11iii111 + iIiiI1
    if 18 - 18: OOooO * iiIIIII1i1iI . oooO0oOOOOo0o / i1I1Ii1iI1ii / i11iIiiIii
def IIIIIo0ooOoO000oO ( ) :
 OOo = [ ]
 i1i11I1I1iii1 = xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.GetFavourites", "params": {"type": null, "properties": ["path", "thumbnail", "window", "windowparameter"]}, "id": 1}' )
 i1i11I1I1iii1 = unicode ( i1i11I1I1iii1 , 'utf-8' , errors = 'ignore' )
 i1i11I1I1iii1 = simplejson . loads ( i1i11I1I1iii1 )
 if i1i11I1I1iii1 [ "result" ] [ "limits" ] [ "total" ] > 0 :
  for I1iii11 in i1i11I1I1iii1 [ "result" ] [ "favourites" ] :
   O0oO0iII11 = ooo0OiII1iii ( I1iii11 )
   i11i1iiiII = { 'Label' : I1iii11 [ "title" ] ,
 'Thumb' : I1iii11 [ "thumbnail" ] ,
 'Type' : I1iii11 [ "type" ] ,
 'Builtin' : O0oO0iII11 ,
 'Path' : "plugin://script.extendedinfo/?info=action&&id=" + O0oO0iII11 }
   OOo . append ( i11i1iiiII )
 print "ITEMS ################################################"
 print OOo
 return OOo
 if 68 - 68: i11iIiiIii * iII1iII1i1iiI
def ooo0OiII1iii ( fav ) :
 if fav [ "type" ] == "media" :
  O0oO0iII11 = "PlayMedia(%s)" % ( fav [ "path" ] )
 elif fav [ "type" ] == "script" :
  O0oO0iII11 = "RunScript(%s)" % ( fav [ "path" ] )
 else :
  O0oO0iII11 = "ActivateWindow(%s,%s)" % (
 fav [ "window" ] , fav [ "windowparameter" ] )
 return O0oO0iII11
 if 46 - 46: iiIIIII1i1iI / ii1IiI1i % oooO0oOOOOo0o . ii1IiI1i * oooO0oOOOOo0o
def IIi1ii1Ii ( favtype ) :
 OoOoO = IIIIIo0ooOoO000oO ( )
 o0ii1i = [ ]
 for I1iii11 in OoOoO :
  if I1iii11 [ "Type" ] == favtype :
   o0ii1i . append ( I1iii11 )
 return o0ii1i
 if 62 - 62: iII1iII1i1iiI / i1I1Ii1iI1ii
def ii1 ( ) :
 from t0mm0 . common . net import Net
 import socket
 import time
 if 53 - 53: OOo000 % OOo000 * iiI11iii111 + iiIIIII1i1iI
 Oooo00 = Net ( )
 if 6 - 6: OOo000 - OOooO * ooo0Oo0 . oooO0oOOOOo0o / i1 * OOooO
 O0oO0iII11 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
 iiIiii1IIIII = os . path . join ( O0oO0iII11 , 'fullbackup.zip' )
 import zipfile
 if 22 - 22: I1II1 % oooO0oOOOOo0o * i1I1Ii1iI1ii / ooo0Oo0 % i11iIiiIii * i1OOooo0000ooo
 Oo00OoOo = zipfile . ZipFile ( iiIiii1IIIII , "r" )
 for ii1ii111 in Oo00OoOo . namelist ( ) :
  if 'favourites.xml' in ii1ii111 :
   i11111I1I = Oo00OoOo . read ( ii1ii111 )
   ii1Oo0000oOo = '<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
   if 31 - 31: i1OOooo0000ooo . iIiiI1 * OOooO + i11iIiiIii * OOoO
   Oo = re . compile ( ii1Oo0000oOo ) . findall ( i11111I1I )
   print Oo
   for OO0ooo0o0O0Oooooo , i11IIIiI1I , o0iiiI1I1iIIIi1 in Oo :
    if 17 - 17: ii1IiI1i . OOooOOo / i1OOooo0000ooo % o0O % I11i / i11iIiiIii
    i11IIIiI1I = i11IIIiI1I . replace ( 'thumb://None' , '/mnt/internal_sd/Android/data/org.xbmc.xbmc/files/.xbmc/addons/script.1channel.themepak/art/themes/Glossy_Black/favourites.png' )
    o0iiiI1I1iIIIi1 = o0iiiI1I1iIIIi1 . replace ( '&quot;' , '' ) . replace ( '&amp;' , '&' )
    json . loads ( xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % ( OO0ooo0o0O0Oooooo , o0iiiI1I1iIIIi1 , i11IIIiI1I ) ) )
    for OOO , Iiiiii1iI in enumerate ( fileinput . input ( oOOoO0 , inplace = 1 ) ) :
     sys . stdout . write ( Iiiiii1iI . replace ( 'RunScript(&quot;' , '' ) . replace ( '&quot;)' , '' ) )
  if 49 - 49: iiI11iii111 . OoOoo0 / iII1iII1i1iiI + o0O
  if 47 - 47: i1 / OOo000
  if 67 - 67: IiiIII111iI
  if 55 - 55: i1I1Ii1iI1ii - oooO0oOOOOo0o * iiI11iii111 + iiIIIII1i1iI * iiIIIII1i1iI * i1
  if 91 - 91: iIiiI1 - ooo0Oo0 % ii1IiI1i - OOooOOo % OOooO
  if 98 - 98: iII1iII1i1iiI . iII1iII1i1iiI * OOoO * o0O * iIiiI1
  if 92 - 92: I1II1
  if 40 - 40: iiIIIII1i1iI / OoOoo0
  if 79 - 79: iII1iII1i1iiI - ii1IiI1i + OOo000 - iIiiI1
  if 93 - 93: o0O . IiiIII111iI - I1II1 + iiIIIII1i1iI
  if 61 - 61: o0O
  if 15 - 15: i11iIiiIii % IiiIII111iI * i1OOooo0000ooo / iIiiI1
  if 90 - 90: oooO0oOOOOo0o
def i1i1i1I ( ) :
 from t0mm0 . common . net import Net
 import socket
 import time
 if 83 - 83: OOoO + OOooOOo
 if ( os . path . isfile ( O0OoO000O0OO ) ) :
  Oooo00 = Net ( )
  O0OO0O = ''
  OO00Oo = open ( oOOoO0 , mode = 'w' )
  OO00Oo . write ( O0OO0O )
  OO00Oo . close ( )
  if 22 - 22: OOo000 % oooO0oOOOOo0o * OOooOOo - iiI11iii111 / ii1IiI1i
  i11111I1I = open ( O0OoO000O0OO ) . read ( )
  ii1Oo0000oOo = '<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
  Oo = re . compile ( ii1Oo0000oOo ) . findall ( i11111I1I )
  for OoOO00 , IIiiIIi1 , o00 in Oo :
   json . loads ( xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % ( OoOO00 , o00 , IIiiIIi1 ) ) )
   for OOO , Iiiiii1iI in enumerate ( fileinput . input ( oOOoO0 , inplace = 1 ) ) :
    sys . stdout . write ( Iiiiii1iI . replace ( 'RunScript(&quot;' , '' ) . replace ( '&quot;)' , '' ) . replace ( '&amp;' , '&' ) )
    if 69 - 69: OOooOOo + i1I1Ii1iI1ii
  O0oO0iII11 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
  O0oOo00o0 = os . path . join ( O0oO0iII11 , 'favourites.xml' )
  downloader . download ( I1IiiI , O0oOo00o0 )
  time . sleep ( 2 )
  ii1ii111 = O0oOo00o0
  if 65 - 65: o0O . IiiIII111iI % OOoO * iII1iII1i1iiI
  ii1Oo0000oOo = '<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
  if 38 - 38: iiIIIII1i1iI / oooO0oOOOOo0o % I1II1
  I1IIIiii1 = re . compile ( ii1Oo0000oOo ) . findall ( i11111I1I )
  for OO0ooo0o0O0Oooooo , i11IIIiI1I , o0iiiI1I1iIIIi1 in I1IIIiii1 :
   i11111I1I = open ( oOOoO0 ) . read ( )
   if OO0ooo0o0O0Oooooo in i11111I1I : break
   if 65 - 65: i1OOooo0000ooo / o0O * OOo000 . oooO0oOOOOo0o * OOoO % ooo0Oo0
   if 69 - 69: OOooO - iII1iII1i1iiI / i11iIiiIii + i1I1Ii1iI1ii % OOooOOo
   if 73 - 73: OOo000 - iIiiI1
   i11IIIiI1I = i11IIIiI1I . replace ( 'thumb://None' , '/mnt/internal_sd/Android/data/org.xbmc.xbmc/files/.xbmc/addons/script.1channel.themepak/art/themes/Glossy_Black/favourites.png' )
   o0iiiI1I1iIIIi1 = o0iiiI1I1iIIIi1 . replace ( '&quot;' , '' )
   if 68 - 68: oooO0oOOOOo0o * OOooOOo * ii1IiI1i . o0O
   json . loads ( xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % ( OO0ooo0o0O0Oooooo , o0iiiI1I1iIIIi1 , i11IIIiI1I ) ) )
   for OOO , Iiiiii1iI in enumerate ( fileinput . input ( oOOoO0 , inplace = 1 ) ) :
    sys . stdout . write ( Iiiiii1iI . replace ( 'RunScript(&quot;' , '' ) . replace ( '&quot;)' , '' ) )
 else :
  pass
  if 81 - 81: ooo0Oo0 / i1 + i1OOooo0000ooo + OOo000 / IiiIII111iI
  if 27 - 27: iiIIIII1i1iI * OoOoo0
def O0Ooo0oo ( ) :
 if 41 - 41: iiIIIII1i1iI * i1OOooo0000ooo / iiIIIII1i1iI % OOoO
 import time
 if 18 - 18: o0O . OOooOOo % iiIIIII1i1iI % OOo000
 try :
  i1iIIi1 = xbmcgui . DialogProgress ( )
  i1iIIi1 . create ( "ITV Updater/Installer" , "Retrieving backup file... " , '' , 'Please wait' )
  iiIiii1IIIII = xbmc . translatePath ( os . path . join ( Oo00OOOOO , 'backup.zip' ) )
  o00o = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
  time . sleep ( 2 )
  i1iIIi1 . update ( 0 , "" , "Installing..." )
  extract . all ( iiIiii1IIIII , o00o , i1iIIi1 )
  i1iIIi1 . update ( 0 , "" , "Finishing up..." )
  time . sleep ( 5 )
  iII111ii = xbmcgui . Dialog ( )
  iII111ii . ok ( "ITV Updater/Installer" , "[COLOR yellow]Installation nearly complete but one important step remains. [/COLOR]" )
  iII111ii = xbmcgui . Dialog ( )
  iII111ii . ok ( "ITV Updater/Installer" , "[COLOR red]URGENT: Please unplug or power off your device immediately and then reboot to finish setup. [/COLOR]" )
  if 9 - 9: iII1iII1i1iiI - I1II1 * OOooOOo . I1II1
 except :
  iII111ii = xbmcgui . Dialog ( )
  iII111ii . ok ( 'ITV Updater/Installer' , 'You need to backup your build first.\nTo backup your box press backup on main menu.' , '' , '' )
  if 2 - 2: OOooOOo % ooo0Oo0
  if 63 - 63: IiiIII111iI % ii1IiI1i
  if 39 - 39: oooO0oOOOOo0o / o0O / i1I1Ii1iI1ii % IiiIII111iI
def i1II1 ( name , url , mode , iconimage , fanart , description ) :
 O0Oo00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 ii1IiIIi1i = True
 oOOo0OOOOo0Oo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 oOOo0OOOOo0Oo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 oOOo0OOOOo0Oo . setProperty ( "Fanart_Image" , fanart )
 ii1IiIIi1i = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0Oo00 , listitem = oOOo0OOOOo0Oo , isFolder = False )
 return ii1IiIIi1i
 if 67 - 67: OOoO / oooO0oOOOOo0o . i1OOooo0000ooo . ii1IiI1i
def ooOoO00 ( name , url , mode , iconimage , fanart , description ) :
 O0Oo00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 ii1IiIIi1i = True
 oOOo0OOOOo0Oo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 oOOo0OOOOo0Oo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 oOOo0OOOOo0Oo . setProperty ( "Fanart_Image" , fanart )
 ii1IiIIi1i = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0Oo00 , listitem = oOOo0OOOOo0Oo , isFolder = True )
 return ii1IiIIi1i
 if 12 - 12: OOooOOo
 if 20 - 20: I11i - i1OOooo0000ooo
 if 30 - 30: iiIIIII1i1iI
def Ii111 ( ) :
 oO0 = [ ]
 i1iIii = sys . argv [ 2 ]
 if len ( i1iIii ) >= 2 :
  oo0o0OoOOO = sys . argv [ 2 ]
  ooO0oO00O0o = oo0o0OoOOO . replace ( '?' , '' )
  if ( oo0o0OoOOO [ len ( oo0o0OoOOO ) - 1 ] == '/' ) :
   oo0o0OoOOO = oo0o0OoOOO [ 0 : len ( oo0o0OoOOO ) - 2 ]
  ooOO00oOOo000 = ooO0oO00O0o . split ( '&' )
  oO0 = { }
  for OOO in range ( len ( ooOO00oOOo000 ) ) :
   IIii11II11II1 = { }
   IIii11II11II1 = ooOO00oOOo000 [ OOO ] . split ( '=' )
   if ( len ( IIii11II11II1 ) ) == 2 :
    oO0 [ IIii11II11II1 [ 0 ] ] = IIii11II11II1 [ 1 ]
    if 10 - 10: IiiIII111iI / I1II1 % i1I1Ii1iI1ii * OOooO
 return oO0
 if 6 - 6: oooO0oOOOOo0o . OoOoo0 * iiIIIII1i1iI . I11i
 if 98 - 98: I11i
oo0o0OoOOO = Ii111 ( )
oO0O = None
OO0ooo0o0O0Oooooo = None
oOO = None
iiiIIiIi = None
OooOOO = None
Ii1iI11iI1 = None
if 5 - 5: ii1IiI1i
if 72 - 72: OOoO . iIiiI1 / iiIIIII1i1iI + i1OOooo0000ooo % ii1IiI1i
try :
 oO0O = urllib . unquote_plus ( oo0o0OoOOO [ "url" ] )
except :
 pass
try :
 OO0ooo0o0O0Oooooo = urllib . unquote_plus ( oo0o0OoOOO [ "name" ] )
except :
 pass
try :
 iiiIIiIi = urllib . unquote_plus ( oo0o0OoOOO [ "iconimage" ] )
except :
 pass
try :
 oOO = int ( oo0o0OoOOO [ "mode" ] )
except :
 pass
try :
 OooOOO = urllib . unquote_plus ( oo0o0OoOOO [ "fanart" ] )
except :
 pass
try :
 Ii1iI11iI1 = urllib . unquote_plus ( oo0o0OoOOO [ "description" ] )
except :
 pass
 if 42 - 42: i1I1Ii1iI1ii * iiIIIII1i1iI % OOooO - iiIIIII1i1iI . i11iIiiIii - iIiiI1
 if 84 - 84: iIiiI1 - i1I1Ii1iI1ii / i1OOooo0000ooo
print str ( IIIII ) + ': ' + str ( I11II1i )
print "Mode: " + str ( oOO )
print "URL: " + str ( oO0O )
print "Name: " + str ( OO0ooo0o0O0Oooooo )
print "IconImage: " + str ( iiiIIiIi )
if 13 - 13: OoOoo0 - I1II1 - OOooO
if 92 - 92: OOooO / iiIIIII1i1iI * iII1iII1i1iiI . i1OOooo0000ooo % o0O
def Ii1IIiI1i ( content , viewType ) :
 if 71 - 71: iIiiI1 % I11i - o0O - ooo0Oo0 + ooo0Oo0 * OOooO
 if content :
  xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , content )
 if iI1Ii11111iIi . getSetting ( 'auto-view' ) == 'true' :
  xbmc . executebuiltin ( "Container.SetViewMode(%s)" % iI1Ii11111iIi . getSetting ( viewType ) )
  if 51 - 51: ii1IiI1i / iiIIIII1i1iI + ooo0Oo0 - i1OOooo0000ooo + oooO0oOOOOo0o
  if 29 - 29: iiI11iii111 % ii1IiI1i . OOooOOo % OOooOOo % o0O / oooO0oOOOOo0o
if oOO == None or oO0O == None or len ( oO0O ) < 1 :
 O0oO0 ( )
 if 70 - 70: i11iIiiIii % oooO0oOOOOo0o
elif oOO == 1 :
 oOOo0 ( OO0ooo0o0O0Oooooo , oO0O , Ii1iI11iI1 )
 if 11 - 11: OoOoo0 % i1I1Ii1iI1ii % OOo000 / o0O % iIiiI1 - I1II1
elif oOO == 2 :
 IIi ( OO0ooo0o0O0Oooooo , oO0O , Ii1iI11iI1 )
 if 96 - 96: i1I1Ii1iI1ii / o0O . OOo000 - oooO0oOOOOo0o * i1OOooo0000ooo * OOoO
elif oOO == 3 :
 OoooO0oO ( )
 if 76 - 76: OOo000 - o0O * ooo0Oo0 / OOooOOo
elif oOO == 4 :
 O0Ooo0oo ( )
 if 18 - 18: iII1iII1i1iiI + ii1IiI1i - o0O - IiiIII111iI
elif oOO == 5 :
 oOo ( )
 if 71 - 71: OOooOOo
elif oOO == 6 :
 i11I1I1I ( OO0ooo0o0O0Oooooo , oO0O , Ii1iI11iI1 )
 if 33 - 33: iIiiI1
elif oOO == 7 :
 ii1I1IIIi ( )
 if 62 - 62: i1I1Ii1iI1ii + OOo000 + I11i / OOooOOo
elif oOO == 8 :
 iII111ii = xbmcgui . Dialog ( )
 iII111ii . ok ( "ITV Updater/Installer" , "[COLOR yellow]Important![/COLOR]" , "" , "Please POWER DOWN your Infinity TV, and then turn it back ON for the changes to take place." )
 try :
  os . remove ( lib )
 except :
  pass
 i1i1i1I ( )
 if 7 - 7: iiI11iii111 + I11i . IiiIII111iI / I1II1
 if 22 - 22: OOooO - OOooO % ooo0Oo0 . iIiiI1 + OOoO
 if 63 - 63: IiiIII111iI % iIiiI1 * iiI11iii111 + iIiiI1 / I1II1 % oooO0oOOOOo0o
 if 45 - 45: OoOoo0
 if 20 - 20: OOooOOo * iiI11iii111 * i1 . ooo0Oo0
 try :
  os . remove ( O0OoO000O0OO )
 except :
  pass
  if 78 - 78: ii1IiI1i + i1OOooo0000ooo - OOo000 * iIiiI1 - OOooOOo % iiIIIII1i1iI
elif oOO == 9 :
 i1iI ( OO0ooo0o0O0Oooooo , oO0O , Ii1iI11iI1 )
 if 34 - 34: i1
elif oOO == 10 :
 iI1i11II1i ( OO0ooo0o0O0Oooooo , oO0O , Ii1iI11iI1 )
 if 80 - 80: I11i - I1II1 / iII1iII1i1iiI - i11iIiiIii
elif oOO == 11 :
 IIIIiII1i ( OO0ooo0o0O0Oooooo , oO0O , Ii1iI11iI1 )
 if 68 - 68: OOoO - i1I1Ii1iI1ii % i1 % iIiiI1
elif oOO == 12 :
 iiI1IIIi ( OO0ooo0o0O0Oooooo , oO0O , Ii1iI11iI1 )
 if 11 - 11: i1 / iII1iII1i1iiI % ooo0Oo0 + iiI11iii111 + ii1IiI1i
elif oOO == 13 :
 o00Oo0oooooo ( OO0ooo0o0O0Oooooo , oO0O , Ii1iI11iI1 )
 if 40 - 40: OOooO - ooo0Oo0 . OOo000 * I1II1 % iIiiI1
elif oOO == 15 :
 I1II1oooO ( OO0ooo0o0O0Oooooo , oO0O , Ii1iI11iI1 )
 if 56 - 56: i11iIiiIii . iiI11iii111 - IiiIII111iI * i1OOooo0000ooo
 if 91 - 91: OOoO + OOooOOo - I11i
 if 84 - 84: OOo000 / OoOoo0
 if 86 - 86: iiIIIII1i1iI * o0O - i1 . iiIIIII1i1iI % ii1IiI1i / ooo0Oo0
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
if 11 - 11: IiiIII111iI * OOoO + i1I1Ii1iI1ii / i1I1Ii1iI1ii
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
